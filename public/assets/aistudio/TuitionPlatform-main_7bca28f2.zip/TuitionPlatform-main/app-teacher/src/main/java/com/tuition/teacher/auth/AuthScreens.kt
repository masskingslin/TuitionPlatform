package com.tuition.teacher.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val ScreenPadding = 24.dp

@Composable
private fun AuthScaffold(
    title: String,
    subtitle: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF4F6F8))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(ScreenPadding),
            verticalArrangement = Arrangement.Center
        ) {
            Icon(Icons.Default.School, contentDescription = null, tint = Color(0xFF00695C), modifier = Modifier.size(40.dp))
            Spacer(modifier = Modifier.height(12.dp))
            Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            Text(subtitle, fontSize = 13.sp, color = Color.Gray)
            Spacer(modifier = Modifier.height(24.dp))
            content()
        }
    }
}

/** Shown once (or whenever "Change server" is tapped) to point the app at a deployed backend. */
@Composable
fun ServerSetupScreen(initialUrl: String, onContinue: (String) -> Unit) {
    var url by remember { mutableStateOf(initialUrl) }
    var error by remember { mutableStateOf<String?>(null) }

    AuthScaffold(
        title = "Connect to Your School's Server",
        subtitle = "Enter the backend address your school deployed. Ask your admin if you're not sure."
    ) {
        OutlinedTextField(
            value = url,
            onValueChange = { url = it },
            label = { Text("Server address") },
            placeholder = { Text("https://api.yourschool.com") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
            modifier = Modifier.fillMaxWidth()
        )
        if (error != null) {
            Spacer(modifier = Modifier.height(10.dp))
            Text(error ?: "", color = Color(0xFFC62828), fontSize = 13.sp)
        }
        Spacer(modifier = Modifier.height(20.dp))
        Button(
            onClick = {
                error = if (url.isBlank()) "Please enter a server address." else null
                if (error == null) onContinue(url.trim())
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text("Continue")
        }
    }
}

@Composable
fun LoginScreen(
    initialEmail: String,
    isLoading: Boolean,
    error: String?,
    onLogin: (email: String, password: String) -> Unit,
    onGoToRegister: () -> Unit,
    onForgotPassword: () -> Unit,
    onChangeServer: () -> Unit
) {
    var email by remember { mutableStateOf(initialEmail) }
    var password by remember { mutableStateOf("") }

    AuthScaffold(title = "Teacher Login", subtitle = "Sign in to manage your classes.") {
        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(12.dp))
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth()
        )

        if (error != null) {
            Spacer(modifier = Modifier.height(10.dp))
            Text(error, color = Color(0xFFC62828), fontSize = 13.sp)
        }

        Spacer(modifier = Modifier.height(20.dp))
        Button(
            onClick = { onLogin(email.trim(), password) },
            enabled = !isLoading && email.isNotBlank() && password.isNotBlank(),
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp)
        ) {
            if (isLoading) {
                CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                Spacer(modifier = Modifier.width(8.dp))
            }
            Text(if (isLoading) "Signing in..." else "Log In")
        }

        Spacer(modifier = Modifier.height(16.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton(onClick = onGoToRegister) { Text("Create account") }
            TextButton(onClick = onForgotPassword) { Text("Forgot password?") }
        }
        TextButton(onClick = onChangeServer, modifier = Modifier.fillMaxWidth()) {
            Text("Change server address")
        }
    }
}

@Composable
private fun SchoolModeButton(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    if (selected) {
        Button(onClick = onClick, modifier = modifier, shape = RoundedCornerShape(8.dp)) { Text(label, fontSize = 13.sp) }
    } else {
        OutlinedButton(onClick = onClick, modifier = modifier, shape = RoundedCornerShape(8.dp)) { Text(label, fontSize = 13.sp) }
    }
}

/**
 * A teacher either joins an existing school with the teacher code its admin
 * shared, or starts a new school (and becomes its admin).
 *
 * [onRegister] receives `schoolCode` when joining, or `newSchoolName` when
 * starting a school — exactly one of the two is non-null.
 */
@Composable
fun RegisterScreen(
    isLoading: Boolean,
    error: String?,
    onRegister: (fullName: String, email: String, password: String, schoolCode: String?, newSchoolName: String?) -> Unit,
    onBackToLogin: () -> Unit
) {
    var fullName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var creatingSchool by remember { mutableStateOf(false) }
    var schoolCode by remember { mutableStateOf("") }
    var schoolName by remember { mutableStateOf("") }
    var localError by remember { mutableStateOf<String?>(null) }

    AuthScaffold(title = "Create Teacher Account", subtitle = "Set up your account on this school's server.") {
        OutlinedTextField(value = fullName, onValueChange = { fullName = it }, label = { Text("Full name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(modifier = Modifier.height(12.dp))
        OutlinedTextField(
            value = email, onValueChange = { email = it }, label = { Text("Email") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(12.dp))
        OutlinedTextField(
            value = password, onValueChange = { password = it }, label = { Text("Password") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(12.dp))
        OutlinedTextField(
            value = confirmPassword, onValueChange = { confirmPassword = it }, label = { Text("Confirm password") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(18.dp))
        Text("Your school", fontWeight = FontWeight.SemiBold)
        Spacer(modifier = Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            SchoolModeButton("Join a school", selected = !creatingSchool, modifier = Modifier.weight(1f)) { creatingSchool = false }
            SchoolModeButton("Start a new school", selected = creatingSchool, modifier = Modifier.weight(1f)) { creatingSchool = true }
        }
        Spacer(modifier = Modifier.height(10.dp))
        if (creatingSchool) {
            OutlinedTextField(
                value = schoolName, onValueChange = { schoolName = it }, label = { Text("School name") },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            Text(
                "You'll be the school's admin, and get codes to share with other teachers, students and parents.",
                fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(top = 4.dp)
            )
        } else {
            OutlinedTextField(
                value = schoolCode, onValueChange = { schoolCode = it.uppercase() }, label = { Text("Teacher join code") },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            Text(
                "Ask your school's admin for the teacher code (it starts with T).",
                fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(top = 4.dp)
            )
        }

        val shownError = localError ?: error
        if (shownError != null) {
            Spacer(modifier = Modifier.height(10.dp))
            Text(shownError, color = Color(0xFFC62828), fontSize = 13.sp)
        }

        Spacer(modifier = Modifier.height(20.dp))
        Button(
            onClick = {
                localError = when {
                    fullName.isBlank() -> "Please enter your name."
                    email.isBlank() -> "Please enter your email."
                    password.length < 6 -> "Password must be at least 6 characters."
                    password != confirmPassword -> "Passwords don't match."
                    creatingSchool && schoolName.isBlank() -> "Please enter a name for your school."
                    !creatingSchool && schoolCode.isBlank() -> "Please enter your school's teacher code."
                    else -> null
                }
                if (localError == null) {
                    onRegister(
                        fullName.trim(), email.trim(), password,
                        if (creatingSchool) null else schoolCode.trim(),
                        if (creatingSchool) schoolName.trim() else null
                    )
                }
            },
            enabled = !isLoading,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text(if (isLoading) "Creating account..." else "Create Account")
        }
        Spacer(modifier = Modifier.height(12.dp))
        TextButton(onClick = onBackToLogin, modifier = Modifier.fillMaxWidth()) { Text("Back to Login") }
    }
}

@Composable
fun ForgotPasswordScreen(
    isLoading: Boolean,
    error: String?,
    linkSent: Boolean,
    onSubmit: (email: String) -> Unit,
    onBack: () -> Unit
) {
    var email by remember { mutableStateOf("") }

    AuthScaffold(title = "Forgot Password", subtitle = "We'll email you a link to reset it.") {
        if (linkSent) {
            Text(
                "If an account exists for that email, we've sent a password reset link. " +
                    "Open it on this device or any browser to set a new password, then come back and log in.",
                fontSize = 14.sp,
                color = Color.DarkGray
            )
        } else {
            OutlinedTextField(
                value = email, onValueChange = { email = it }, label = { Text("Email") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), modifier = Modifier.fillMaxWidth()
            )

            if (error != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(error, color = Color(0xFFC62828), fontSize = 13.sp)
            }

            Spacer(modifier = Modifier.height(20.dp))
            Button(
                onClick = { onSubmit(email.trim()) },
                enabled = !isLoading && email.isNotBlank(),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(if (isLoading) "Sending..." else "Send Reset Link")
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
        TextButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Back to Login") }
    }
}
