package com.tuition.teacher

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.tuition.core.network.*
import com.tuition.teacher.auth.ForgotPasswordScreen
import com.tuition.teacher.auth.LoginScreen
import com.tuition.teacher.auth.RegisterScreen
import com.tuition.teacher.school.SchoolCard
import com.tuition.teacher.auth.ServerSetupScreen
import com.tuition.teacher.auth.SessionStore
import com.tuition.teacher.push.syncDeviceToken
import com.tuition.teacher.push.unregisterDeviceToken
import com.tuition.teacher.uploads.uriToMultipart
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* Push still works without this; the OS just won't display incoming notifications. */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sessionStore = SessionStore(applicationContext)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Color(0xFF00695C),
                    secondary = Color(0xFF0288D1),
                    background = Color(0xFFF4F6F8),
                    surface = Color.White
                )
            ) {
                TeacherAppEntryPoint(sessionStore)
            }
        }
    }
}

private enum class AuthStage { SERVER_SETUP, LOGIN, REGISTER, FORGOT_PASSWORD, AUTHENTICATED }

private data class LoadState<T>(
    val data: List<T> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null
)

@Composable
private fun TeacherAppEntryPoint(sessionStore: SessionStore) {
    var stage by remember {
        mutableStateOf(
            when {
                sessionStore.baseUrl.isBlank() -> AuthStage.SERVER_SETUP
                sessionStore.isLoggedIn -> AuthStage.AUTHENTICATED
                else -> AuthStage.LOGIN
            }
        )
    }
    var apiService by remember {
        mutableStateOf(if (sessionStore.baseUrl.isNotBlank()) TuitionApiClient.create(sessionStore.baseUrl) else null)
    }
    var isLoading by remember { mutableStateOf(false) }
    var authError by remember { mutableStateOf<String?>(null) }
    var resetLinkSent by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    when (stage) {
        AuthStage.SERVER_SETUP -> ServerSetupScreen(
            initialUrl = sessionStore.baseUrl,
            onContinue = { url ->
                sessionStore.baseUrl = url
                apiService = TuitionApiClient.create(url)
                stage = if (sessionStore.isLoggedIn) AuthStage.AUTHENTICATED else AuthStage.LOGIN
            }
        )

        AuthStage.LOGIN -> LoginScreen(
            initialEmail = sessionStore.email,
            isLoading = isLoading,
            error = authError,
            onLogin = { email, password ->
                apiService?.let { service ->
                    isLoading = true
                    authError = null
                    scope.launch {
                        try {
                            val response = service.login(LoginRequest(email, password))
                            if (response.role != UserRole.TEACHER) {
                                authError = "This app is for teachers. Please use the Student & Parent app."
                            } else {
                                sessionStore.saveSession(response)
                                stage = AuthStage.AUTHENTICATED
                            }
                        } catch (e: Exception) {
                            authError = "Couldn't sign in: ${e.toUserMessage("check your details and try again.")}"
                        } finally {
                            isLoading = false
                        }
                    }
                }
            },
            onGoToRegister = { authError = null; stage = AuthStage.REGISTER },
            onForgotPassword = { authError = null; resetLinkSent = false; stage = AuthStage.FORGOT_PASSWORD },
            onChangeServer = { stage = AuthStage.SERVER_SETUP }
        )

        AuthStage.REGISTER -> RegisterScreen(
            isLoading = isLoading,
            error = authError,
            onRegister = { fullName, email, password, schoolCode, newSchoolName ->
                apiService?.let { service ->
                    isLoading = true
                    authError = null
                    scope.launch {
                        try {
                            val response = service.register(
                                RegisterRequest(
                                    fullName = fullName,
                                    email = email,
                                    password = password,
                                    role = UserRole.TEACHER,
                                    schoolCode = schoolCode,
                                    createSchool = newSchoolName != null,
                                    schoolName = newSchoolName
                                )
                            )
                            sessionStore.saveSession(response)
                            stage = AuthStage.AUTHENTICATED
                        } catch (e: Exception) {
                            authError = "Couldn't create account: ${e.toUserMessage("please try again.")}"
                        } finally {
                            isLoading = false
                        }
                    }
                }
            },
            onBackToLogin = { authError = null; stage = AuthStage.LOGIN }
        )

        AuthStage.FORGOT_PASSWORD -> ForgotPasswordScreen(
            isLoading = isLoading,
            error = authError,
            linkSent = resetLinkSent,
            onSubmit = { email ->
                apiService?.let { service ->
                    isLoading = true
                    authError = null
                    scope.launch {
                        try {
                            service.forgotPassword(ForgotPasswordRequest(email))
                            resetLinkSent = true
                        } catch (e: Exception) {
                            authError = e.toUserMessage("Couldn't send a reset link. Please try again.")
                        } finally {
                            isLoading = false
                        }
                    }
                }
            },
            onBack = { authError = null; resetLinkSent = false; stage = AuthStage.LOGIN }
        )

        AuthStage.AUTHENTICATED -> {
            apiService?.let { service ->
                // A saved token from before an upgrade (or one that has expired) is rejected with
                // 401. Check once up front and go back to sign-in, rather than showing an error on
                // every screen. If the phone is simply offline, carry on — screens report their own errors.
                var sessionChecked by remember { mutableStateOf(false) }
                LaunchedEffect(service) {
                    try {
                        service.getMe("Bearer ${sessionStore.token}")
                    } catch (e: Exception) {
                        if (e.isUnauthorized()) {
                            sessionStore.clearSession()
                            authError = "Please sign in again to continue."
                            stage = AuthStage.LOGIN
                        }
                    }
                    sessionChecked = true
                }
                if (sessionChecked) {
                    TeacherAppRoot(
                        apiService = service,
                        sessionStore = sessionStore,
                        onLogout = {
                            scope.launch {
                                unregisterDeviceToken(service, sessionStore)
                                sessionStore.clearSession()
                                stage = AuthStage.LOGIN
                            }
                        }
                    )
                } else {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
            }
        }
    }
}

enum class TeacherNavScreen(val title: String, val icon: ImageVector) {
    BATCHES("Batches", Icons.Default.Class),
    ATTENDANCE("Attendance", Icons.Default.CheckCircle),
    HOMEWORK("Homework", Icons.Default.AddBox),
    FEE_TRACKER("Fees", Icons.Default.ReceiptLong),
    INSIGHTS("Insights", Icons.Default.Insights),
    ACCOUNT("Account", Icons.Default.Person)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeacherAppRoot(apiService: TuitionApiService, sessionStore: SessionStore, onLogout: () -> Unit) {
    var selectedScreen by remember { mutableStateOf(TeacherNavScreen.BATCHES) }
    var batchesState by remember { mutableStateOf(LoadState<CourseBatch>()) }
    var selectedBatchId by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val token = "Bearer ${sessionStore.token}"

    fun loadBatches() {
        scope.launch {
            batchesState = batchesState.copy(isLoading = true, error = null)
            try {
                val result = apiService.getMyBatches(token)
                batchesState = LoadState(data = result)
                if (selectedBatchId == null && result.isNotEmpty()) selectedBatchId = result.first().id
            } catch (e: Exception) {
                batchesState = LoadState(error = e.toUserMessage("Failed to load batches"))
            }
        }
    }

    LaunchedEffect(Unit) {
        loadBatches()
        syncDeviceToken(apiService, sessionStore)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(selectedScreen.title, fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
        },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                TeacherNavScreen.values().forEach { screen ->
                    NavigationBarItem(
                        selected = selectedScreen == screen,
                        onClick = { selectedScreen = screen },
                        icon = { Icon(screen.icon, contentDescription = screen.title) },
                        label = { Text(screen.title) }
                    )
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            when (selectedScreen) {
                TeacherNavScreen.BATCHES -> TeacherBatchesScreen(apiService, token, batchesState, onCreated = { loadBatches() })
                TeacherNavScreen.ATTENDANCE -> TeacherAttendanceScreen(apiService, token, batchesState.data, selectedBatchId) { selectedBatchId = it }
                TeacherNavScreen.HOMEWORK -> TeacherAssignmentsScreen(apiService, token, batchesState.data, selectedBatchId) { selectedBatchId = it }
                TeacherNavScreen.FEE_TRACKER -> TeacherFeeTrackerScreen(apiService, token)
                TeacherNavScreen.INSIGHTS -> TeacherInsightsScreen(apiService, token)
                TeacherNavScreen.ACCOUNT -> TeacherAccountScreen(apiService, token, sessionStore, onLogout)
            }
        }
    }
}

@Composable
private fun BatchPicker(batches: List<CourseBatch>, selectedBatchId: String?, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val selected = batches.find { it.id == selectedBatchId }

    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
        OutlinedTextField(
            value = selected?.title ?: "Select a batch",
            onValueChange = {},
            readOnly = true,
            label = { Text("Batch") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier
                .menuAnchor()
                .fillMaxWidth()
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            batches.forEach { batch ->
                DropdownMenuItem(text = { Text(batch.title) }, onClick = {
                    onSelect(batch.id)
                    expanded = false
                })
            }
        }
    }
}

@Composable
fun TeacherBatchesScreen(
    apiService: TuitionApiService,
    token: String,
    batchesState: LoadState<CourseBatch>,
    onCreated: () -> Unit
) {
    var showForm by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }
    var subject by remember { mutableStateOf("") }
    var scheduleTime by remember { mutableStateOf("") }
    var room by remember { mutableStateOf("") }
    var isSubmitting by remember { mutableStateOf(false) }
    var formError by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Teacher Console", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("${batchesState.data.size} Active Batches", color = Color.White.copy(alpha = 0.9f))
                }
            }
        }

        if (batchesState.isLoading) {
            item { LinearProgressIndicator(modifier = Modifier.fillMaxWidth()) }
        }
        if (batchesState.error != null) {
            item { Text(batchesState.error, color = Color(0xFFC62828), fontSize = 13.sp) }
        }

        item {
            if (!showForm) {
                OutlinedButton(onClick = { showForm = true }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("New Batch")
                }
            } else {
                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Title") }, modifier = Modifier.fillMaxWidth())
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(value = subject, onValueChange = { subject = it }, label = { Text("Subject") }, modifier = Modifier.fillMaxWidth())
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(value = scheduleTime, onValueChange = { scheduleTime = it }, label = { Text("Schedule (e.g. 5:00 PM - 6:30 PM)") }, modifier = Modifier.fillMaxWidth())
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(value = room, onValueChange = { room = it }, label = { Text("Room / Meeting Link") }, modifier = Modifier.fillMaxWidth())
                        if (formError != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(formError ?: "", color = Color(0xFFC62828), fontSize = 12.sp)
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {
                                    formError = if (title.isBlank() || subject.isBlank() || scheduleTime.isBlank()) {
                                        "Title, subject, and schedule are required."
                                    } else null
                                    if (formError == null) {
                                        isSubmitting = true
                                        scope.launch {
                                            try {
                                                apiService.createBatch(
                                                    token,
                                                    CreateBatchRequest(title.trim(), subject.trim(), scheduleTime.trim(), room.trim())
                                                )
                                                title = ""; subject = ""; scheduleTime = ""; room = ""
                                                showForm = false
                                                onCreated()
                                            } catch (e: Exception) {
                                                formError = e.toUserMessage("Failed to create batch")
                                            } finally {
                                                isSubmitting = false
                                            }
                                        }
                                    }
                                },
                                enabled = !isSubmitting
                            ) { Text(if (isSubmitting) "Saving..." else "Save") }
                            TextButton(onClick = { showForm = false }) { Text("Cancel") }
                        }
                    }
                }
            }
        }

        if (batchesState.data.isEmpty() && !batchesState.isLoading) {
            item { Text("No batches yet. Create your first one above.", color = Color.Gray) }
        }

        items(batchesState.data) { batch ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(batch.title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Badge { Text("${batch.activeStudentCount} Students") }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Timing: ${batch.scheduleTime}", color = Color.DarkGray, fontSize = 13.sp)
                    Text("Location/Link: ${batch.roomOrMeetingLink}", color = Color.Gray, fontSize = 13.sp)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeacherAttendanceScreen(
    apiService: TuitionApiService,
    token: String,
    batches: List<CourseBatch>,
    selectedBatchId: String?,
    onSelectBatch: (String) -> Unit
) {
    var students by remember { mutableStateOf<List<StudentSummary>>(emptyList()) }
    var statuses by remember { mutableStateOf<Map<String, AttendanceStatus>>(emptyMap()) }
    var isLoading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var isSubmitting by remember { mutableStateOf(false) }
    val date = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(selectedBatchId) {
        val batchId = selectedBatchId ?: return@LaunchedEffect
        isLoading = true
        error = null
        try {
            val roster = apiService.getBatchStudents(token, batchId)
            students = roster
            statuses = roster.associate { it.id to AttendanceStatus.PRESENT }
        } catch (e: Exception) {
            error = e.toUserMessage("Failed to load students")
        } finally {
            isLoading = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        BatchPicker(batches, selectedBatchId, onSelectBatch)
        Spacer(modifier = Modifier.height(12.dp))
        Text("Date: $date", fontSize = 13.sp, color = Color.Gray)
        Spacer(modifier = Modifier.height(12.dp))

        if (isLoading) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        if (error != null) Text(error ?: "", color = Color(0xFFC62828), fontSize = 13.sp)

        when {
            selectedBatchId == null -> Text("Create or select a batch to mark attendance.", color = Color.Gray)
            students.isEmpty() && !isLoading -> Text("No students enrolled in this batch yet.", color = Color.Gray)
            else -> {
                LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(students) { student ->
                        val status = statuses[student.id] ?: AttendanceStatus.PRESENT
                        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(student.fullName, fontWeight = FontWeight.Medium)
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    FilterChip(selected = status == AttendanceStatus.PRESENT, onClick = { statuses = statuses + (student.id to AttendanceStatus.PRESENT) }, label = { Text("P") })
                                    FilterChip(selected = status == AttendanceStatus.ABSENT, onClick = { statuses = statuses + (student.id to AttendanceStatus.ABSENT) }, label = { Text("A") })
                                    FilterChip(selected = status == AttendanceStatus.LATE, onClick = { statuses = statuses + (student.id to AttendanceStatus.LATE) }, label = { Text("L") })
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = {
                        val batchId = selectedBatchId ?: return@Button
                        isSubmitting = true
                        scope.launch {
                            try {
                                val records = students.map {
                                    AttendanceRecord(
                                        id = "",
                                        batchId = batchId,
                                        studentId = it.id,
                                        studentName = it.fullName,
                                        date = date,
                                        status = statuses[it.id] ?: AttendanceStatus.PRESENT
                                    )
                                }
                                apiService.submitAttendance(token, batchId, MarkAttendanceRequest(batchId, date, records))
                            } catch (e: Exception) {
                                error = e.toUserMessage("Failed to save attendance")
                            } finally {
                                isSubmitting = false
                            }
                        }
                    },
                    enabled = !isSubmitting,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(if (isSubmitting) "Saving..." else "Save Attendance")
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeacherAssignmentsScreen(
    apiService: TuitionApiService,
    token: String,
    batches: List<CourseBatch>,
    selectedBatchId: String?,
    onSelectBatch: (String) -> Unit
) {
    var assignments by remember { mutableStateOf<List<Assignment>>(emptyList()) }
    var isLoading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var dueDate by remember { mutableStateOf("") }
    var isSubmitting by remember { mutableStateOf(false) }
    var expandedAssignmentId by remember { mutableStateOf<String?>(null) }
    var attachingAssignmentId by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    suspend fun loadAssignments(batchId: String) {
        isLoading = true
        error = null
        try {
            assignments = apiService.getAssignments(token, batchId)
        } catch (e: Exception) {
            error = e.toUserMessage("Failed to load assignments")
        } finally {
            isLoading = false
        }
    }

    LaunchedEffect(selectedBatchId) {
        selectedBatchId?.let { loadAssignments(it) }
    }

    var pendingAttachmentAssignmentId by remember { mutableStateOf<String?>(null) }
    val attachmentPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val assignmentId = pendingAttachmentAssignmentId
        val batchId = selectedBatchId
        if (uri == null || assignmentId == null || batchId == null) return@rememberLauncherForActivityResult
        attachingAssignmentId = assignmentId
        scope.launch {
            try {
                val part = uriToMultipart(context, uri, "file")
                if (part != null) {
                    apiService.uploadAssignmentAttachment(token, batchId, assignmentId, part)
                    loadAssignments(batchId)
                } else {
                    error = "Couldn't read that file."
                }
            } catch (e: Exception) {
                error = e.toUserMessage("Failed to attach file")
            } finally {
                attachingAssignmentId = null
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        BatchPicker(batches, selectedBatchId, onSelectBatch)

        Text("Create New Homework / Task", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Assignment Title") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Instructions & Problems") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
        OutlinedTextField(value = dueDate, onValueChange = { dueDate = it }, label = { Text("Due Date (e.g. 2026-09-05)") }, modifier = Modifier.fillMaxWidth())

        if (error != null) Text(error ?: "", color = Color(0xFFC62828), fontSize = 13.sp)

        Button(
            onClick = {
                val batchId = selectedBatchId
                if (batchId == null) {
                    error = "Select a batch first."
                    return@Button
                }
                if (title.isBlank() || dueDate.isBlank()) {
                    error = "Title and due date are required."
                    return@Button
                }
                isSubmitting = true
                scope.launch {
                    try {
                        apiService.createAssignment(token, batchId, CreateAssignmentRequest(title.trim(), description.trim(), dueDate.trim()))
                        title = ""; description = ""; dueDate = ""
                        loadAssignments(batchId)
                    } catch (e: Exception) {
                        error = e.toUserMessage("Failed to publish assignment")
                    } finally {
                        isSubmitting = false
                    }
                }
            },
            enabled = !isSubmitting,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp)
        ) {
            Icon(Icons.Default.Upload, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(if (isSubmitting) "Publishing..." else "Publish to Batch")
        }

        if (isLoading) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())

        LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (assignments.isEmpty() && !isLoading) {
                item { Text("No assignments published yet.", color = Color.Gray) }
            }
            items(assignments) { item ->
                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(8.dp)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(item.title, fontWeight = FontWeight.Bold)
                        if (item.description.isNotBlank()) {
                            Text(item.description, fontSize = 13.sp, color = Color.DarkGray)
                        }
                        Text("Due: ${item.dueDate}", fontSize = 12.sp, color = Color.Gray)
                        if (item.attachmentUrl != null) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "📎 ${item.attachmentName ?: "Attachment"}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.clickable {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(item.attachmentUrl)))
                                }
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row {
                            TextButton(onClick = {
                                expandedAssignmentId = if (expandedAssignmentId == item.id) null else item.id
                            }) {
                                Text(if (expandedAssignmentId == item.id) "Hide Grading" else "Grade Submissions")
                            }
                            TextButton(
                                onClick = {
                                    pendingAttachmentAssignmentId = item.id
                                    attachmentPicker.launch("*/*")
                                },
                                enabled = attachingAssignmentId != item.id
                            ) {
                                Text(if (attachingAssignmentId == item.id) "Attaching..." else "Attach File")
                            }
                        }
                        if (expandedAssignmentId == item.id && selectedBatchId != null) {
                            GradingRoster(apiService, token, selectedBatchId, item.id, item.maxScore)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GradingRoster(
    apiService: TuitionApiService,
    token: String,
    batchId: String,
    assignmentId: String,
    maxScore: Int
) {
    var submissions by remember { mutableStateOf<List<AssignmentSubmissionSummary>>(emptyList()) }
    var scoreInputs by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var isLoading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var savingStudentId by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    LaunchedEffect(assignmentId) {
        isLoading = true
        error = null
        try {
            val result = apiService.getAssignmentSubmissions(token, batchId, assignmentId)
            submissions = result
            scoreInputs = result.associate { it.studentId to (it.scoreEarned?.toString() ?: "") }
        } catch (e: Exception) {
            error = e.toUserMessage("Failed to load submissions")
        } finally {
            isLoading = false
        }
    }

    Column(modifier = Modifier.padding(top = 8.dp)) {
        if (isLoading) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        if (error != null) Text(error ?: "", color = Color(0xFFC62828), fontSize = 12.sp)

        submissions.forEach { submission ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(submission.studentName, fontSize = 13.sp)
                    Text(if (submission.isSubmitted) "Submitted" else "Not submitted", fontSize = 11.sp, color = Color.Gray)
                    if (submission.attachmentUrl != null) {
                        Text(
                            "📎 ${submission.attachmentName ?: "View file"}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.clickable {
                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(submission.attachmentUrl)))
                            }
                        )
                    }
                }
                OutlinedTextField(
                    value = scoreInputs[submission.studentId] ?: "",
                    onValueChange = { scoreInputs = scoreInputs + (submission.studentId to it) },
                    label = { Text("/ $maxScore") },
                    modifier = Modifier.width(90.dp),
                    singleLine = true
                )
                Spacer(modifier = Modifier.width(6.dp))
                TextButton(
                    onClick = {
                        val score = scoreInputs[submission.studentId]?.toIntOrNull()
                        if (score != null) {
                            savingStudentId = submission.studentId
                            scope.launch {
                                try {
                                    apiService.gradeAssignment(token, batchId, assignmentId, GradeAssignmentRequest(submission.studentId, score))
                                } catch (e: Exception) {
                                    error = e.toUserMessage("Failed to save grade")
                                } finally {
                                    savingStudentId = null
                                }
                            }
                        }
                    },
                    enabled = savingStudentId != submission.studentId
                ) {
                    Text(if (savingStudentId == submission.studentId) "..." else "Save")
                }
            }
        }
    }
}

@Composable
fun TeacherFeeTrackerScreen(apiService: TuitionApiService, token: String) {
    var feesState by remember { mutableStateOf(LoadState<FeeRecord>()) }
    var students by remember { mutableStateOf<List<StudentSummary>>(emptyList()) }
    var showForm by remember { mutableStateOf(false) }
    var selectedStudentId by remember { mutableStateOf<String?>(null) }
    var monthYear by remember { mutableStateOf("") }
    var amountDue by remember { mutableStateOf("") }
    var dueDate by remember { mutableStateOf("") }
    var formError by remember { mutableStateOf<String?>(null) }
    var isSubmitting by remember { mutableStateOf(false) }
    var markingPaidId by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    fun loadFees() {
        scope.launch {
            feesState = feesState.copy(isLoading = true, error = null)
            try {
                feesState = LoadState(data = apiService.getFeeOverview(token))
            } catch (e: Exception) {
                feesState = LoadState(error = e.toUserMessage("Failed to load fee records"))
            }
        }
    }

    LaunchedEffect(Unit) {
        loadFees()
        try {
            students = apiService.getFeeEligibleStudents(token)
        } catch (e: Exception) {
            // Non-fatal: the "new fee" form just won't have a student list yet.
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        if (feesState.isLoading) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        if (feesState.error != null) {
            Text(feesState.error, color = Color(0xFFC62828), modifier = Modifier.padding(16.dp))
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                if (!showForm) {
                    OutlinedButton(onClick = { showForm = true }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("New Fee Record")
                    }
                } else {
                    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            if (students.isEmpty()) {
                                Text("No students enrolled yet — add a fee record once someone joins a batch.", color = Color.Gray, fontSize = 13.sp)
                            } else {
                                FeeStudentPicker(students, selectedStudentId) { selectedStudentId = it }
                                Spacer(modifier = Modifier.height(8.dp))
                                OutlinedTextField(value = monthYear, onValueChange = { monthYear = it }, label = { Text("Month (e.g. September 2026)") }, modifier = Modifier.fillMaxWidth())
                                Spacer(modifier = Modifier.height(8.dp))
                                OutlinedTextField(value = amountDue, onValueChange = { amountDue = it }, label = { Text("Amount Due") }, modifier = Modifier.fillMaxWidth())
                                Spacer(modifier = Modifier.height(8.dp))
                                OutlinedTextField(value = dueDate, onValueChange = { dueDate = it }, label = { Text("Due Date (e.g. 2026-09-15)") }, modifier = Modifier.fillMaxWidth())
                                if (formError != null) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(formError ?: "", color = Color(0xFFC62828), fontSize = 12.sp)
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(
                                        onClick = {
                                            val studentId = selectedStudentId
                                            val amount = amountDue.toDoubleOrNull()
                                            formError = when {
                                                studentId == null -> "Select a student."
                                                monthYear.isBlank() -> "Enter a month."
                                                amount == null -> "Enter a valid amount."
                                                dueDate.isBlank() -> "Enter a due date."
                                                else -> null
                                            }
                                            if (formError == null && studentId != null && amount != null) {
                                                isSubmitting = true
                                                scope.launch {
                                                    try {
                                                        apiService.createFeeRecord(token, CreateFeeRecordRequest(studentId, monthYear.trim(), amount, dueDate.trim()))
                                                        monthYear = ""; amountDue = ""; dueDate = ""; selectedStudentId = null
                                                        showForm = false
                                                        loadFees()
                                                    } catch (e: Exception) {
                                                        formError = e.toUserMessage("Failed to create fee record")
                                                    } finally {
                                                        isSubmitting = false
                                                    }
                                                }
                                            }
                                        },
                                        enabled = !isSubmitting
                                    ) { Text(if (isSubmitting) "Saving..." else "Save") }
                                    TextButton(onClick = { showForm = false }) { Text("Cancel") }
                                }
                            }
                        }
                    }
                }
            }

            if (feesState.data.isEmpty() && !feesState.isLoading && feesState.error == null) {
                item { Text("No fee records yet.", color = Color.Gray) }
            }
            items(feesState.data) { fee ->
                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(8.dp)) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(fee.studentName, fontWeight = FontWeight.Bold)
                                Text("${fee.monthYear} • ₹${fee.amountDue}", fontSize = 13.sp, color = Color.Gray)
                            }
                            Text(
                                fee.status.name,
                                fontWeight = FontWeight.Bold,
                                color = when (fee.status) {
                                    FeePaymentStatus.PAID -> Color(0xFF2E7D32)
                                    FeePaymentStatus.PENDING -> Color(0xFFEF6C00)
                                    FeePaymentStatus.OVERDUE -> Color(0xFFC62828)
                                }
                            )
                        }
                        if (fee.status != FeePaymentStatus.PAID) {
                            Spacer(modifier = Modifier.height(8.dp))
                            TextButton(
                                onClick = {
                                    markingPaidId = fee.invoiceId
                                    scope.launch {
                                        try {
                                            apiService.markFeePaid(token, fee.invoiceId)
                                            loadFees()
                                        } catch (e: Exception) {
                                            feesState = feesState.copy(error = e.toUserMessage("Failed to update fee record"))
                                        } finally {
                                            markingPaidId = null
                                        }
                                    }
                                },
                                enabled = markingPaidId != fee.invoiceId
                            ) {
                                Text(if (markingPaidId == fee.invoiceId) "Updating..." else "Mark Paid")
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FeeStudentPicker(students: List<StudentSummary>, selectedStudentId: String?, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val selected = students.find { it.id == selectedStudentId }

    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
        OutlinedTextField(
            value = selected?.fullName ?: "Select a student",
            onValueChange = {},
            readOnly = true,
            label = { Text("Student") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier
                .menuAnchor()
                .fillMaxWidth()
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            students.forEach { student ->
                DropdownMenuItem(text = { Text(student.fullName) }, onClick = {
                    onSelect(student.id)
                    expanded = false
                })
            }
        }
    }
}

@Composable
fun TeacherInsightsScreen(apiService: TuitionApiService, token: String) {
    var overview by remember { mutableStateOf<AnalyticsOverview?>(null) }
    var batchPerformance by remember { mutableStateOf<List<BatchPerformance>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        isLoading = true
        error = null
        try {
            overview = apiService.getAnalyticsOverview(token)
            batchPerformance = apiService.getBatchPerformance(token)
        } catch (e: Exception) {
            error = e.toUserMessage("Failed to load insights")
        } finally {
            isLoading = false
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        if (isLoading) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        if (error != null) {
            Text(error, color = Color(0xFFC62828), modifier = Modifier.padding(16.dp))
        }

        val data = overview
        if (data == null) {
            if (!isLoading && error == null) {
                Text("No data yet.", color = Color.Gray, modifier = Modifier.padding(16.dp))
            }
            return
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    InsightStatCard("Batches", data.totalBatches.toString(), Modifier.weight(1f))
                    InsightStatCard("Students", data.totalStudents.toString(), Modifier.weight(1f))
                    InsightStatCard("Homework", data.totalAssignments.toString(), Modifier.weight(1f))
                }
            }

            item {
                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(10.dp)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Attendance (last 30 days)", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(modifier = Modifier.height(10.dp))
                        val rate = data.attendance.presentRate
                        if (rate == null) {
                            Text("No attendance marked yet.", color = Color.Gray, fontSize = 13.sp)
                        } else {
                            RatioBar(rate, Color(0xFF2E7D32))
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                "${(rate * 100).toInt()}% present • ${data.attendance.presentCount} present, " +
                                    "${data.attendance.absentCount} absent, ${data.attendance.lateCount} late",
                                fontSize = 12.sp, color = Color.Gray
                            )
                        }
                    }
                }
            }

            item {
                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(10.dp)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Fee Collection", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(modifier = Modifier.height(10.dp))
                        val collectionRate = if (data.fees.totalDue > 0) data.fees.totalCollected / data.fees.totalDue else null
                        if (collectionRate == null) {
                            Text("No fee records yet.", color = Color.Gray, fontSize = 13.sp)
                        } else {
                            RatioBar(collectionRate, Color(0xFF1E88E5))
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                "₹${data.fees.totalCollected.toInt()} collected of ₹${data.fees.totalDue.toInt()} " +
                                    "(₹${data.fees.totalPending.toInt()} pending)",
                                fontSize = 12.sp, color = Color.Gray
                            )
                        }
                    }
                }
            }

            item { Text("Batch Performance", fontWeight = FontWeight.Bold, fontSize = 16.sp) }

            if (batchPerformance.isEmpty() && !isLoading) {
                item { Text("No batches yet.", color = Color.Gray, fontSize = 13.sp) }
            }

            items(batchPerformance) { batch ->
                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(10.dp)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(batch.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Homework completion", fontSize = 11.sp, color = Color.Gray)
                        Spacer(modifier = Modifier.height(2.dp))
                        if (batch.submissionRate == null) {
                            Text("No homework yet", fontSize = 12.sp, color = Color.Gray)
                        } else {
                            RatioBar(batch.submissionRate, Color(0xFF6A1B9A))
                            Text("${(batch.submissionRate * 100).toInt()}%", fontSize = 11.sp, color = Color.Gray)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Attendance rate", fontSize = 11.sp, color = Color.Gray)
                        Spacer(modifier = Modifier.height(2.dp))
                        if (batch.attendanceRate == null) {
                            Text("No attendance yet", fontSize = 12.sp, color = Color.Gray)
                        } else {
                            RatioBar(batch.attendanceRate, Color(0xFF2E7D32))
                            Text("${(batch.attendanceRate * 100).toInt()}%", fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun InsightStatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(10.dp)) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(value, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Text(label, fontSize = 11.sp, color = Color.Gray)
        }
    }
}

/** A simple horizontal fill bar for a 0..1 ratio — no charting dependency needed. */
@Composable
private fun RatioBar(ratio: Double, color: Color) {
    val clamped = ratio.coerceIn(0.0, 1.0).toFloat()
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(8.dp)
            .background(Color(0xFFEEEEEE), RoundedCornerShape(4.dp))
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(clamped)
                .height(8.dp)
                .background(color, RoundedCornerShape(4.dp))
        )
    }
}

@Composable
fun TeacherAccountScreen(apiService: TuitionApiService, token: String, sessionStore: SessionStore, onLogout: () -> Unit) {
    var avatarUrl by remember { mutableStateOf<String?>(null) }
    var isUploadingPhoto by remember { mutableStateOf(false) }
    var photoError by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    fun refreshProfile() {
        scope.launch {
            try {
                avatarUrl = apiService.getMe(token).avatarUrl
            } catch (e: Exception) {
                // Non-fatal — the account screen still works without a fresh avatar fetch.
            }
        }
    }

    LaunchedEffect(Unit) { refreshProfile() }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        isUploadingPhoto = true
        photoError = null
        scope.launch {
            try {
                val part = uriToMultipart(context, uri, "photo")
                if (part == null) {
                    photoError = "Couldn't read that file."
                } else {
                    apiService.uploadProfilePhoto(token, part)
                    refreshProfile()
                }
            } catch (e: Exception) {
                photoError = e.toUserMessage("Failed to upload photo")
            } finally {
                isUploadingPhoto = false
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(10.dp)) {
            Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier
                        .size(84.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFE0E0E0))
                        .clickable(enabled = !isUploadingPhoto) { photoPicker.launch("image/*") },
                    contentAlignment = Alignment.Center
                ) {
                    if (avatarUrl != null) {
                        AsyncImage(
                            model = avatarUrl,
                            contentDescription = "Profile photo",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Icon(Icons.Default.Person, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(40.dp))
                    }
                    if (isUploadingPhoto) {
                        CircularProgressIndicator(modifier = Modifier.size(28.dp), strokeWidth = 2.dp)
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    "Tap to change photo",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                if (photoError != null) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(photoError ?: "", color = Color(0xFFC62828), fontSize = 11.sp)
                }
                Spacer(modifier = Modifier.height(14.dp))
                Text(sessionStore.fullName, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(sessionStore.email, color = Color.Gray, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(10.dp))
                Text("Server: ${sessionStore.baseUrl}", fontSize = 12.sp, color = Color.Gray)
            }
        }
        SchoolCard(apiService = apiService, token = token)
        Button(onClick = onLogout, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(8.dp)) {
            Text("Log Out")
        }
    }
}
