package com.tuition.teacher.auth

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.tuition.core.network.AuthResponse

/**
 * Persists the backend server address and the signed-in session (JWT +
 * profile) on-device, encrypted at rest. Logging out clears the session
 * but keeps the server address, since that rarely changes.
 */
class SessionStore(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "teacher_session_secure",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    var baseUrl: String
        get() = prefs.getString(KEY_BASE_URL, "") ?: ""
        set(value) = prefs.edit().putString(KEY_BASE_URL, value).apply()

    var token: String?
        get() = prefs.getString(KEY_TOKEN, null)
        private set(value) = prefs.edit().putString(KEY_TOKEN, value).apply()

    var fullName: String
        get() = prefs.getString(KEY_FULL_NAME, "") ?: ""
        private set(value) = prefs.edit().putString(KEY_FULL_NAME, value).apply()

    var email: String
        get() = prefs.getString(KEY_EMAIL, "") ?: ""
        private set(value) = prefs.edit().putString(KEY_EMAIL, value).apply()

    /** The most recent FCM token this device has, whether or not it's been sent to the backend yet. */
    var deviceToken: String?
        get() = prefs.getString(KEY_DEVICE_TOKEN, null)
        set(value) = prefs.edit().putString(KEY_DEVICE_TOKEN, value).apply()

    val isLoggedIn: Boolean get() = !token.isNullOrBlank()

    fun saveSession(auth: AuthResponse) {
        token = auth.token
        fullName = auth.fullName
        email = auth.email
    }

    fun clearSession() {
        prefs.edit().remove(KEY_TOKEN).remove(KEY_FULL_NAME).remove(KEY_EMAIL).apply()
    }

    companion object {
        private const val KEY_BASE_URL = "base_url"
        private const val KEY_TOKEN = "token"
        private const val KEY_FULL_NAME = "full_name"
        private const val KEY_EMAIL = "email"
        private const val KEY_DEVICE_TOKEN = "device_token"
    }
}
