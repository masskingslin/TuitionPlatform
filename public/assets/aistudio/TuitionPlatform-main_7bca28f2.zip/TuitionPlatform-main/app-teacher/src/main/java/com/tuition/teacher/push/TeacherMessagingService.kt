package com.tuition.teacher.push

import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.tuition.teacher.auth.SessionStore

class TeacherMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        // Persisted here; MainActivity registers it with the backend next time
        // the app is opened while signed in (see registerDeviceTokenIfNeeded).
        SessionStore(applicationContext).deviceToken = token
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        val title = message.notification?.title ?: message.data["title"] ?: "Tuition Platform"
        val body = message.notification?.body ?: message.data["body"] ?: "You have a new update."
        showPushNotification(applicationContext, title, body)
    }
}
