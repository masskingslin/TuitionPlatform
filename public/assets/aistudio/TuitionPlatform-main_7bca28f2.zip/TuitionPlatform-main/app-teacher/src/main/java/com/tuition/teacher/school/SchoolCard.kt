package com.tuition.teacher.school

import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tuition.core.network.RegenerateCodesRequest
import com.tuition.core.network.SchoolInfo
import com.tuition.core.network.TuitionApiService
import com.tuition.core.network.toUserMessage
import kotlinx.coroutines.launch

/**
 * Shows which school the teacher belongs to. The school admin also sees the
 * two join codes — one for students/parents, one for teachers — and can share
 * or rotate them (rotating invalidates the old code straight away, which is
 * what you want if a code leaks).
 */
@Composable
fun SchoolCard(apiService: TuitionApiService, token: String) {
    var school by remember { mutableStateOf<SchoolInfo?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var confirmRotate by remember { mutableStateOf<String?>(null) } // "student" or "teacher"
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    fun load() {
        scope.launch {
            try {
                school = apiService.getSchool(token)
                error = null
            } catch (e: Exception) {
                error = e.toUserMessage("Couldn't load school details.")
            }
        }
    }

    fun rotate(which: String) {
        scope.launch {
            busy = true
            try {
                apiService.regenerateSchoolCodes(token, RegenerateCodesRequest(which = which))
                load()
            } catch (e: Exception) {
                error = e.toUserMessage("Couldn't create a new code.")
            } finally {
                busy = false
            }
        }
    }

    fun share(schoolName: String, who: String, code: String) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, "Join $schoolName on the Tuition app as $who. School code: $code")
        }
        context.startActivity(Intent.createChooser(send, "Share code"))
    }

    LaunchedEffect(Unit) { load() }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(10.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            val info = school
            if (info == null) {
                Text(error ?: "Loading school...", color = if (error != null) Color(0xFFC62828) else Color.Gray, fontSize = 13.sp)
                return@Column
            }

            Text(info.name, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(
                "${info.teacherCount} teachers · ${info.studentCount} students · ${info.parentCount} parents",
                color = Color.Gray, fontSize = 13.sp
            )

            if (info.isSchoolAdmin) {
                Spacer(modifier = Modifier.height(4.dp))
                Text("You are this school's admin", fontSize = 12.sp, color = Color(0xFF2E7D32))
                info.studentCode?.let { code ->
                    CodeRow("Student & parent code", code, busy,
                        onShare = { share(info.name, "a student or parent", code) },
                        onRotate = { confirmRotate = "student" })
                }
                info.teacherCode?.let { code ->
                    CodeRow("Teacher code", code, busy,
                        onShare = { share(info.name, "a teacher", code) },
                        onRotate = { confirmRotate = "teacher" })
                }
            }

            error?.let {
                Spacer(modifier = Modifier.height(8.dp))
                Text(it, color = Color(0xFFC62828), fontSize = 12.sp)
            }
        }
    }

    confirmRotate?.let { which ->
        AlertDialog(
            onDismissRequest = { confirmRotate = null },
            title = { Text("Create a new code?") },
            text = { Text("The current ${if (which == "student") "student & parent" else "teacher"} code will stop working immediately. People already signed up are not affected.") },
            confirmButton = { TextButton(onClick = { confirmRotate = null; rotate(which) }) { Text("Create new code") } },
            dismissButton = { TextButton(onClick = { confirmRotate = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun CodeRow(label: String, code: String, busy: Boolean, onShare: () -> Unit, onRotate: () -> Unit) {
    Spacer(modifier = Modifier.height(12.dp))
    Text(label, fontSize = 12.sp, color = Color.Gray)
    Text(code, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 22.sp)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 4.dp)) {
        OutlinedButton(onClick = onShare, enabled = !busy, shape = RoundedCornerShape(8.dp)) { Text("Share", fontSize = 13.sp) }
        OutlinedButton(onClick = onRotate, enabled = !busy, shape = RoundedCornerShape(8.dp)) { Text("New code", fontSize = 13.sp) }
    }
}
