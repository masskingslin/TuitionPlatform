package com.tuition.core.network

import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

/**
 * Talks to the hosted Tuition Platform backend (see /backend in this repo).
 * The base URL is whatever address the school has deployed the backend to,
 * configured once per app install and stored locally — see SessionStore
 * in each app.
 */
interface TuitionApiService {

    // --- Auth: no token required ---

    @POST("api/auth/register")
    suspend fun register(@Body request: RegisterRequest): AuthResponse

    @POST("api/auth/login")
    suspend fun login(@Body request: LoginRequest): AuthResponse

    @POST("api/auth/forgot-password")
    suspend fun forgotPassword(@Body request: ForgotPasswordRequest): SimpleSuccessResponse

    @GET("api/auth/me")
    suspend fun getMe(@Header("Authorization") token: String): UserProfile

    // --- Batches: requires "Authorization: Bearer <token>" ---

    @GET("api/batches")
    suspend fun getMyBatches(@Header("Authorization") token: String): List<CourseBatch>

    @GET("api/batches/browse")
    suspend fun browseBatches(@Header("Authorization") token: String): List<CourseBatch>

    @POST("api/batches")
    suspend fun createBatch(
        @Header("Authorization") token: String,
        @Body batch: CreateBatchRequest
    ): CourseBatch

    @POST("api/batches/{batchId}/enroll")
    suspend fun enrollInBatch(
        @Header("Authorization") token: String,
        @Path("batchId") batchId: String
    ): SimpleSuccessResponse

    @GET("api/batches/{batchId}/students")
    suspend fun getBatchStudents(
        @Header("Authorization") token: String,
        @Path("batchId") batchId: String
    ): List<StudentSummary>

    // --- Assignments ---

    @GET("api/batches/{batchId}/assignments")
    suspend fun getAssignments(
        @Header("Authorization") token: String,
        @Path("batchId") batchId: String
    ): List<Assignment>

    @POST("api/batches/{batchId}/assignments")
    suspend fun createAssignment(
        @Header("Authorization") token: String,
        @Path("batchId") batchId: String,
        @Body request: CreateAssignmentRequest
    ): Assignment

    @POST("api/batches/{batchId}/assignments/{assignmentId}/submit")
    suspend fun submitAssignment(
        @Header("Authorization") token: String,
        @Path("batchId") batchId: String,
        @Path("assignmentId") assignmentId: String
    ): SimpleSuccessResponse

    @GET("api/batches/{batchId}/assignments/{assignmentId}/submissions")
    suspend fun getAssignmentSubmissions(
        @Header("Authorization") token: String,
        @Path("batchId") batchId: String,
        @Path("assignmentId") assignmentId: String
    ): List<AssignmentSubmissionSummary>

    @POST("api/batches/{batchId}/assignments/{assignmentId}/grade")
    suspend fun gradeAssignment(
        @Header("Authorization") token: String,
        @Path("batchId") batchId: String,
        @Path("assignmentId") assignmentId: String,
        @Body request: GradeAssignmentRequest
    ): SimpleSuccessResponse

    @Multipart
    @POST("api/batches/{batchId}/assignments/{assignmentId}/attachment")
    suspend fun uploadAssignmentAttachment(
        @Header("Authorization") token: String,
        @Path("batchId") batchId: String,
        @Path("assignmentId") assignmentId: String,
        @Part file: MultipartBody.Part
    ): UploadResponse

    @Multipart
    @POST("api/batches/{batchId}/assignments/{assignmentId}/submission-attachment")
    suspend fun uploadSubmissionAttachment(
        @Header("Authorization") token: String,
        @Path("batchId") batchId: String,
        @Path("assignmentId") assignmentId: String,
        @Part file: MultipartBody.Part
    ): UploadResponse

    // --- Attendance ---

    @GET("api/batches/{batchId}/attendance")
    suspend fun getAttendance(
        @Header("Authorization") token: String,
        @Path("batchId") batchId: String
    ): List<AttendanceRecord>

    @POST("api/batches/{batchId}/attendance")
    suspend fun submitAttendance(
        @Header("Authorization") token: String,
        @Path("batchId") batchId: String,
        @Body request: MarkAttendanceRequest
    ): SimpleSuccessResponse

    // --- Fees ---

    @GET("api/fees")
    suspend fun getFeeOverview(@Header("Authorization") token: String): List<FeeRecord>

    @GET("api/fees/students")
    suspend fun getFeeEligibleStudents(@Header("Authorization") token: String): List<StudentSummary>

    @POST("api/fees")
    suspend fun createFeeRecord(
        @Header("Authorization") token: String,
        @Body request: CreateFeeRecordRequest
    ): FeeRecord

    @POST("api/fees/{feeId}/mark-paid")
    suspend fun markFeePaid(
        @Header("Authorization") token: String,
        @Path("feeId") feeId: String
    ): FeeRecord

    @POST("api/fees/{feeId}/checkout")
    suspend fun createFeeCheckout(
        @Header("Authorization") token: String,
        @Path("feeId") feeId: String
    ): CheckoutResponse

    // --- Push notification device registration ---

    @POST("api/devices/register")
    suspend fun registerDevice(
        @Header("Authorization") token: String,
        @Body request: RegisterDeviceRequest
    ): SimpleSuccessResponse

    @POST("api/devices/unregister")
    suspend fun unregisterDevice(
        @Header("Authorization") token: String,
        @Body request: UnregisterDeviceRequest
    ): SimpleSuccessResponse

    // --- Analytics (teacher only) ---

    @GET("api/analytics/overview")
    suspend fun getAnalyticsOverview(@Header("Authorization") token: String): AnalyticsOverview

    @GET("api/analytics/attendance-trend")
    suspend fun getAttendanceTrend(
        @Header("Authorization") token: String,
        @Query("days") days: Int = 30,
        @Query("batchId") batchId: String? = null
    ): List<AttendanceTrendPoint>

    @GET("api/analytics/revenue-trend")
    suspend fun getRevenueTrend(
        @Header("Authorization") token: String,
        @Query("months") months: Int = 6
    ): List<RevenueTrendPoint>

    @GET("api/analytics/batch-performance")
    suspend fun getBatchPerformance(@Header("Authorization") token: String): List<BatchPerformance>

    // --- School (join codes and members are admin-only) ---

    @GET("api/school")
    suspend fun getSchool(@Header("Authorization") token: String): SchoolInfo

    @PUT("api/school")
    suspend fun renameSchool(
        @Header("Authorization") token: String,
        @Body request: RenameSchoolRequest
    ): SimpleSuccessResponse

    @POST("api/school/regenerate-codes")
    suspend fun regenerateSchoolCodes(
        @Header("Authorization") token: String,
        @Body request: RegenerateCodesRequest
    ): SchoolCodes

    @GET("api/school/members")
    suspend fun getSchoolMembers(@Header("Authorization") token: String): List<SchoolMember>

    // --- Parents ---

    /** Student: generate a code to hand to a parent. */
    @POST("api/parents/link-code")
    suspend fun createParentLinkCode(@Header("Authorization") token: String): ParentLinkCode

    /** Student: who can currently see my data. */
    @GET("api/parents/my-parents")
    suspend fun getMyParents(@Header("Authorization") token: String): List<LinkedParent>

    /** Student: revoke a parent's access. */
    @DELETE("api/parents/my-parents/{parentId}")
    suspend fun revokeParent(
        @Header("Authorization") token: String,
        @Path("parentId") parentId: String
    ): SimpleSuccessResponse

    /** Parent: link to a child using the code the child generated. */
    @POST("api/parents/link")
    suspend fun linkChild(
        @Header("Authorization") token: String,
        @Body request: LinkChildRequest
    ): ChildProfile

    @GET("api/parents/children")
    suspend fun getChildren(@Header("Authorization") token: String): List<ChildProfile>

    @DELETE("api/parents/children/{studentId}")
    suspend fun unlinkChild(
        @Header("Authorization") token: String,
        @Path("studentId") studentId: String
    ): SimpleSuccessResponse

    @GET("api/parents/children/{studentId}/summary")
    suspend fun getChildSummary(
        @Header("Authorization") token: String,
        @Path("studentId") studentId: String
    ): ChildSummary

    @GET("api/parents/children/{studentId}/batches")
    suspend fun getChildBatches(
        @Header("Authorization") token: String,
        @Path("studentId") studentId: String
    ): List<CourseBatch>

    @GET("api/parents/children/{studentId}/attendance")
    suspend fun getChildAttendance(
        @Header("Authorization") token: String,
        @Path("studentId") studentId: String
    ): List<AttendanceRecord>

    @GET("api/parents/children/{studentId}/assignments")
    suspend fun getChildAssignments(
        @Header("Authorization") token: String,
        @Path("studentId") studentId: String
    ): List<Assignment>

    @GET("api/parents/children/{studentId}/fees")
    suspend fun getChildFees(
        @Header("Authorization") token: String,
        @Path("studentId") studentId: String
    ): List<FeeRecord>

    // --- File uploads ---

    @Multipart
    @POST("api/uploads/profile-photo")
    suspend fun uploadProfilePhoto(
        @Header("Authorization") token: String,
        @Part photo: MultipartBody.Part
    ): UploadResponse
}

/**
 * Builds a [TuitionApiService] pointed at a given base URL. The backend is
 * whatever address the school deployed (see /backend's README), so the
 * base URL is supplied at runtime rather than hardcoded.
 */
object TuitionApiClient {

    private val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
        encodeDefaults = true
    }

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        })
        .build()

    /** [baseUrl] should look like "https://api.yourschool.com/" (a trailing slash is added if missing). */
    fun create(baseUrl: String): TuitionApiService {
        val normalized = if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"
        return Retrofit.Builder()
            .baseUrl(normalized)
            .client(okHttpClient)
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()
            .create(TuitionApiService::class.java)
    }
}
