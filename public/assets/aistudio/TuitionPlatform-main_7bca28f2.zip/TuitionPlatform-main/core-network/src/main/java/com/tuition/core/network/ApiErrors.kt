package com.tuition.core.network

import kotlinx.serialization.json.Json
import retrofit2.HttpException
import java.io.IOException

private val errorJson = Json {
    ignoreUnknownKeys = true
    isLenient = true
}

/** Extracts the backend's `{"error": "..."}` message from a response body, or null if it isn't one. */
internal fun parseServerError(body: String?): String? {
    if (body.isNullOrBlank()) return null
    return runCatching { errorJson.decodeFromString<ApiErrorResponse>(body).error }
        .getOrNull()
        ?.takeIf { it.isNotBlank() }
}

/**
 * Turns any exception from an API call into something safe to show a person.
 *
 * Retrofit's own `HttpException.message` is just "HTTP 400", which hides the
 * backend's useful explanation ("That is a teacher code...", "Too many failed
 * sign-in attempts...") — so we read it from the response body instead.
 */
fun Throwable.toUserMessage(fallback: String = "Something went wrong. Please try again."): String = when (this) {
    is HttpException -> parseServerError(runCatching { response()?.errorBody()?.string() }.getOrNull())
        ?: when (code()) {
            401 -> "Your session has expired. Please sign in again."
            403 -> "You don't have permission to do that."
            404 -> "That couldn't be found."
            413 -> "That file or request is too large."
            429 -> "Too many attempts. Please wait a few minutes and try again."
            in 500..599 -> "The server had a problem. Please try again shortly."
            else -> fallback
        }
    is IOException -> "Couldn't reach the server. Check your internet connection and the server address."
    else -> message?.takeIf { it.isNotBlank() } ?: fallback
}

/** True when the backend rejected the session (expired token, or one issued before an upgrade). */
fun Throwable.isUnauthorized(): Boolean = this is HttpException && code() == 401
