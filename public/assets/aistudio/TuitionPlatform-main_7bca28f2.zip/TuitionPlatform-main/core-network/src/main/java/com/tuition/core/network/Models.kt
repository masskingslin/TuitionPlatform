package com.tuition.core.network

import kotlinx.serialization.Serializable

@Serializable
enum class UserRole {
    STUDENT,
    TEACHER,
    ADMIN,
    PARENT
}

@Serializable
enum class AttendanceStatus {
    PRESENT,
    ABSENT,
    LATE,
    EXCUSED
}

@Serializable
enum class FeePaymentStatus {
    PAID,
    PENDING,
    OVERDUE
}

@Serializable
data class CourseBatch(
    val id: String,
    val title: String,
    val subject: String,
    val teacherName: String,
    val scheduleTime: String,
    val activeStudentCount: Int,
    val roomOrMeetingLink: String
)

@Serializable
data class AttendanceRecord(
    val id: String,
    val batchId: String,
    val studentId: String,
    val studentName: String,
    val date: String,
    val status: AttendanceStatus,
    val notes: String = "",
    /** Only filled in by the parent endpoints, which span several batches. */
    val batchTitle: String? = null
)

@Serializable
data class MarkAttendanceRequest(
    val batchId: String,
    val date: String,
    val records: List<AttendanceRecord>
)

@Serializable
data class Assignment(
    val id: String,
    val batchId: String,
    val title: String,
    val description: String,
    val dueDate: String,
    val maxScore: Int,
    val isSubmitted: Boolean = false,
    val scoreEarned: Int? = null,
    val attachmentUrl: String? = null,
    val attachmentName: String? = null,
    val submissionAttachmentUrl: String? = null,
    val submissionAttachmentName: String? = null,
    /** Only filled in by the parent endpoints, which span several batches. */
    val batchTitle: String? = null
)

@Serializable
data class FeeRecord(
    val invoiceId: String,
    val studentId: String,
    val studentName: String,
    val monthYear: String,
    val amountDue: Double,
    val amountPaid: Double,
    val status: FeePaymentStatus,
    val dueDate: String
)

@Serializable
data class Announcement(
    val id: String,
    val title: String,
    val message: String,
    val authorName: String,
    val timestamp: String,
    val priority: String = "NORMAL"
)

@Serializable
data class StudentSummary(
    val id: String,
    val fullName: String
)

// ---------------------------------------------------------------------
// Hosted-backend auth contract (see /backend). Real per-user accounts —
// email + password — instead of a single shared local login.
// ---------------------------------------------------------------------

@Serializable
data class RegisterRequest(
    val fullName: String,
    val email: String,
    val password: String,
    val role: UserRole,
    /** Join an existing school: students/parents use its student code, teachers its teacher code. */
    val schoolCode: String? = null,
    /** Teachers only: start a brand-new school (and become its admin) instead of joining one. */
    val createSchool: Boolean = false,
    val schoolName: String? = null
)

@Serializable
data class LoginRequest(val email: String, val password: String)

@Serializable
data class AuthResponse(
    val token: String,
    val userId: String,
    val fullName: String,
    val email: String,
    val role: UserRole,
    val avatarUrl: String? = null,
    val schoolId: String? = null,
    val schoolName: String? = null,
    val isSchoolAdmin: Boolean = false
)

@Serializable
data class ForgotPasswordRequest(val email: String)

@Serializable
data class ApiErrorResponse(val error: String)

@Serializable
data class SimpleSuccessResponse(val success: Boolean)

@Serializable
data class UserProfile(
    val userId: String,
    val fullName: String,
    val email: String,
    val role: UserRole,
    val avatarUrl: String? = null,
    val schoolId: String? = null,
    val schoolName: String? = null,
    val isSchoolAdmin: Boolean = false
)

// ---------------------------------------------------------------------
// File uploads
// ---------------------------------------------------------------------

@Serializable
data class UploadResponse(val url: String, val filename: String)

// ---------------------------------------------------------------------
// Lightweight "create" request bodies (server fills in id/teacherName/etc.)
// ---------------------------------------------------------------------

@Serializable
data class CreateBatchRequest(
    val title: String,
    val subject: String,
    val scheduleTime: String,
    val roomOrMeetingLink: String = ""
)

@Serializable
data class CreateAssignmentRequest(
    val title: String,
    val description: String,
    val dueDate: String,
    val maxScore: Int = 100
)

@Serializable
data class GradeAssignmentRequest(val studentId: String, val scoreEarned: Int)

@Serializable
data class AssignmentSubmissionSummary(
    val studentId: String,
    val studentName: String,
    val isSubmitted: Boolean,
    val scoreEarned: Int? = null,
    val attachmentUrl: String? = null,
    val attachmentName: String? = null
)

@Serializable
data class CreateFeeRecordRequest(
    val studentId: String,
    val monthYear: String,
    val amountDue: Double,
    val dueDate: String
)

// ---------------------------------------------------------------------
// Push notifications
// ---------------------------------------------------------------------

@Serializable
data class RegisterDeviceRequest(val fcmToken: String, val platform: String = "android")

@Serializable
data class UnregisterDeviceRequest(val fcmToken: String)

// ---------------------------------------------------------------------
// Online payments
// ---------------------------------------------------------------------

@Serializable
data class CheckoutResponse(val checkoutUrl: String)

// ---------------------------------------------------------------------
// Analytics
// ---------------------------------------------------------------------

@Serializable
data class AttendanceOverview(
    val presentCount: Int,
    val absentCount: Int,
    val lateCount: Int,
    val excusedCount: Int,
    val presentRate: Double? = null
)

@Serializable
data class FeesOverview(
    val totalDue: Double,
    val totalCollected: Double,
    val totalPending: Double,
    val paidInvoices: Int,
    val pendingInvoices: Int,
    val overdueInvoices: Int
)

@Serializable
data class AnalyticsOverview(
    val totalBatches: Int,
    val totalStudents: Int,
    val totalAssignments: Int,
    val attendance: AttendanceOverview,
    val fees: FeesOverview
)

@Serializable
data class AttendanceTrendPoint(
    val date: String,
    val present: Int,
    val absent: Int,
    val late: Int
)

@Serializable
data class RevenueTrendPoint(
    val monthYear: String,
    val collected: Double,
    val pending: Double
)

@Serializable
data class BatchPerformance(
    val batchId: String,
    val title: String,
    val studentCount: Int,
    val assignmentCount: Int,
    val submissionRate: Double? = null,
    val attendanceRate: Double? = null
)

// ---------------------------------------------------------------------
// School management
// ---------------------------------------------------------------------

/** Join codes are only present when the caller is the school admin. */
@Serializable
data class SchoolInfo(
    val id: String,
    val name: String,
    val isSchoolAdmin: Boolean = false,
    val teacherCount: Int = 0,
    val studentCount: Int = 0,
    val parentCount: Int = 0,
    val studentCode: String? = null,
    val teacherCode: String? = null
)

@Serializable
data class RenameSchoolRequest(val name: String)

@Serializable
data class RegenerateCodesRequest(
    /** "student", "teacher" or "both" */
    val which: String = "both"
)

@Serializable
data class SchoolCodes(val studentCode: String, val teacherCode: String)

@Serializable
data class SchoolMember(
    val id: String,
    val fullName: String,
    val email: String,
    val role: UserRole,
    val isSchoolAdmin: Boolean = false,
    val avatarUrl: String? = null,
    val joinedAt: String = ""
)

// ---------------------------------------------------------------------
// Parent accounts
// ---------------------------------------------------------------------

/** A short-lived code a student gives to a parent so the parent can link to them. */
@Serializable
data class ParentLinkCode(val code: String, val expiresAt: String)

@Serializable
data class LinkChildRequest(val code: String)

@Serializable
data class ChildProfile(
    val id: String,
    val fullName: String,
    val avatarUrl: String? = null
)

/** A parent who can see a student's data (shown to the student, who can revoke it). */
@Serializable
data class LinkedParent(val id: String, val fullName: String, val email: String)

@Serializable
data class ChildAttendanceSummary(
    val presentCount: Int = 0,
    val absentCount: Int = 0,
    val lateCount: Int = 0,
    val excusedCount: Int = 0,
    /** 0.0–1.0 over the last 30 days, or null when nothing has been marked yet. */
    val presentRate: Double? = null
)

@Serializable
data class ChildFeeSummary(
    val totalDue: Double = 0.0,
    val totalPaid: Double = 0.0,
    val totalPending: Double = 0.0,
    val overdueInvoices: Int = 0
)

@Serializable
data class ChildAssignmentSummary(
    val total: Int = 0,
    val submitted: Int = 0,
    val graded: Int = 0,
    /** 0.0–1.0, or null when nothing has been graded yet. */
    val averageScoreRate: Double? = null
)

@Serializable
data class ChildSummary(
    val child: ChildProfile,
    val attendance: ChildAttendanceSummary,
    val fees: ChildFeeSummary,
    val assignments: ChildAssignmentSummary
)
