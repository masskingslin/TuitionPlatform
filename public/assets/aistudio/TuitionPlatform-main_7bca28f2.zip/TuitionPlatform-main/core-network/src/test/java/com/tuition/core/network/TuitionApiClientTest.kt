package com.tuition.core.network

import org.junit.Assert.assertNotNull
import org.junit.Test

/**
 * TuitionApiClient.create() only builds a Retrofit client locally — it
 * doesn't make any network call — so this is safe to test without a real
 * server.
 */
class TuitionApiClientTest {

    @Test
    fun `create accepts a URL without a trailing slash`() {
        val service = TuitionApiClient.create("https://api.example.com")
        assertNotNull(service)
    }

    @Test
    fun `create accepts a URL with a trailing slash`() {
        val service = TuitionApiClient.create("https://api.example.com/")
        assertNotNull(service)
    }

    @Test
    fun `create accepts a local http URL for self-hosted testing`() {
        val service = TuitionApiClient.create("http://10.0.2.2:4000")
        assertNotNull(service)
    }
}
