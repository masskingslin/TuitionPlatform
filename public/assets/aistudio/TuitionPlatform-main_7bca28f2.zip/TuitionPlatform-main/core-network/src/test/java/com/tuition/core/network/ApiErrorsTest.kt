package com.tuition.core.network

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.ResponseBody.Companion.toResponseBody
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import retrofit2.HttpException
import retrofit2.Response
import java.io.IOException

class ApiErrorsTest {

    private fun httpError(code: Int, body: String): HttpException =
        HttpException(Response.error<Any>(code, body.toResponseBody("application/json".toMediaType())))

    @Test
    fun `parseServerError reads the backend error field`() {
        assertEquals("That is a teacher code.", parseServerError("""{"error":"That is a teacher code."}"""))
    }

    @Test
    fun `parseServerError returns null for blank, non-JSON or unrelated bodies`() {
        assertNull(parseServerError(null))
        assertNull(parseServerError(""))
        assertNull(parseServerError("<html>502 Bad Gateway</html>"))
        assertNull(parseServerError("""{"message":"nope"}"""))
        assertNull(parseServerError("""{"error":""}"""))
    }

    @Test
    fun `HTTP errors surface the server's own explanation`() {
        val message = httpError(400, """{"error":"That school code was not recognised"}""").toUserMessage()
        assertEquals("That school code was not recognised", message)
    }

    @Test
    fun `rate limiting surfaces the server message`() {
        val message = httpError(429, """{"error":"Too many failed sign-in attempts for this account."}""").toUserMessage()
        assertTrue(message.startsWith("Too many failed sign-in attempts"))
    }

    @Test
    fun `HTTP errors without a JSON body fall back to a friendly message by status`() {
        assertTrue(httpError(401, "").toUserMessage().contains("sign in again"))
        assertTrue(httpError(403, "").toUserMessage().contains("permission"))
        assertTrue(httpError(429, "").toUserMessage().contains("Too many"))
        assertTrue(httpError(503, "<html/>").toUserMessage().contains("server had a problem"))
        assertEquals("custom fallback", httpError(418, "").toUserMessage("custom fallback"))
    }

    @Test
    fun `network failures say the server could not be reached`() {
        assertTrue(IOException("timeout").toUserMessage().contains("reach the server"))
    }

    @Test
    fun `other exceptions keep their own message, or use the fallback when they have none`() {
        assertEquals("boom", IllegalStateException("boom").toUserMessage())
        assertEquals("fallback", IllegalStateException().toUserMessage("fallback"))
    }

    @Test
    fun `isUnauthorized is true only for HTTP 401`() {
        assertTrue(httpError(401, "").isUnauthorized())
        assertEquals(false, httpError(403, "").isUnauthorized())
        assertEquals(false, IOException("x").isUnauthorized())
    }
}
