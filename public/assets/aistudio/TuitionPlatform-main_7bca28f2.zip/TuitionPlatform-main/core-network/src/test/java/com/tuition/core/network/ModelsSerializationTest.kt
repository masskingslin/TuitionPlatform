package com.tuition.core.network

import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * These tests exist to catch a specific, easy-to-make mistake: renaming or
 * reordering a field in one of these data classes without updating the
 * Node backend (or vice versa). Since neither side uses a schema
 * validator, a silent field-name mismatch would only surface at runtime as
 * a confusing null/missing-field bug. Asserting the exact JSON text keeps
 * that contract honest.
 */
class ModelsSerializationTest {

    private val json = Json { encodeDefaults = true }

    @Test
    fun `LoginRequest serializes with expected field names`() {
        val request = LoginRequest(email = "a@b.com", password = "secret")
        val text = json.encodeToString(request)

        assertTrue(text.contains("\"email\":\"a@b.com\""))
        assertTrue(text.contains("\"password\":\"secret\""))
    }

    @Test
    fun `RegisterRequest round-trips through JSON`() {
        val original = RegisterRequest(
            fullName = "Ada Lovelace",
            email = "ada@example.com",
            password = "hunter22",
            role = UserRole.TEACHER
        )
        val text = json.encodeToString(original)
        val decoded = json.decodeFromString<RegisterRequest>(text)

        assertEquals(original, decoded)
        assertTrue(text.contains("\"role\":\"TEACHER\""))
    }

    @Test
    fun `AuthResponse round-trips and matches backend field names`() {
        val original = AuthResponse(
            token = "jwt-token-value",
            userId = "user-123",
            fullName = "Ada Lovelace",
            email = "ada@example.com",
            role = UserRole.STUDENT
        )
        val text = json.encodeToString(original)

        // These exact keys must match backend/src/routes/auth.routes.js's toAuthResponse()
        assertTrue(text.contains("\"token\":"))
        assertTrue(text.contains("\"userId\":"))
        assertTrue(text.contains("\"fullName\":"))
        assertTrue(text.contains("\"email\":"))
        assertTrue(text.contains("\"role\":"))

        assertEquals(original, json.decodeFromString<AuthResponse>(text))
    }

    @Test
    fun `CourseBatch decodes a typical backend response`() {
        val serverJson = """
            {
              "id": "batch-1",
              "title": "Grade 10 Math",
              "subject": "Math",
              "teacherName": "Ms. Lee",
              "scheduleTime": "5:00 PM - 6:30 PM",
              "activeStudentCount": 12,
              "roomOrMeetingLink": "Room 101"
            }
        """.trimIndent()

        val batch = json.decodeFromString<CourseBatch>(serverJson)

        assertEquals("batch-1", batch.id)
        assertEquals(12, batch.activeStudentCount)
        assertEquals("Ms. Lee", batch.teacherName)
    }

    @Test
    fun `Assignment defaults isSubmitted to false and scoreEarned to null when absent`() {
        val serverJson = """
            {
              "id": "a1",
              "batchId": "b1",
              "title": "Homework 1",
              "description": "Chapter 3 problems",
              "dueDate": "2026-09-20",
              "maxScore": 100
            }
        """.trimIndent()

        val assignment = json.decodeFromString<Assignment>(serverJson)

        assertEquals(false, assignment.isSubmitted)
        assertEquals(null, assignment.scoreEarned)
    }

    @Test
    fun `Assignment decodes attachment fields when the server includes them`() {
        val serverJson = """
            {
              "id": "a1",
              "batchId": "b1",
              "title": "Worksheet 2",
              "description": "",
              "dueDate": "2026-09-25",
              "maxScore": 50,
              "attachmentUrl": "https://api.example.com/uploads/assignments/abc.pdf",
              "attachmentName": "worksheet2.pdf",
              "submissionAttachmentUrl": null,
              "submissionAttachmentName": null
            }
        """.trimIndent()

        val assignment = json.decodeFromString<Assignment>(serverJson)

        assertEquals("worksheet2.pdf", assignment.attachmentName)
        assertEquals("https://api.example.com/uploads/assignments/abc.pdf", assignment.attachmentUrl)
        assertEquals(null, assignment.submissionAttachmentUrl)
    }

    @Test
    fun `AuthResponse avatarUrl is optional and defaults to null`() {
        val withoutAvatar = """
            {"token":"t","userId":"u","fullName":"A","email":"a@b.com","role":"STUDENT"}
        """.trimIndent()
        val withAvatar = """
            {"token":"t","userId":"u","fullName":"A","email":"a@b.com","role":"STUDENT","avatarUrl":"https://x.test/a.png"}
        """.trimIndent()

        assertEquals(null, json.decodeFromString<AuthResponse>(withoutAvatar).avatarUrl)
        assertEquals("https://x.test/a.png", json.decodeFromString<AuthResponse>(withAvatar).avatarUrl)
    }

    @Test
    fun `UploadResponse decodes url and filename`() {
        val upload = json.decodeFromString<UploadResponse>("""{"url":"https://x.test/f.png","filename":"f.png"}""")
        assertEquals("https://x.test/f.png", upload.url)
        assertEquals("f.png", upload.filename)
    }

    @Test
    fun `MarkAttendanceRequest carries a nested list of AttendanceRecord`() {
        val request = MarkAttendanceRequest(
            batchId = "b1",
            date = "2026-09-08",
            records = listOf(
                AttendanceRecord(
                    id = "", batchId = "b1", studentId = "s1", studentName = "Alice",
                    date = "2026-09-08", status = AttendanceStatus.PRESENT
                ),
                AttendanceRecord(
                    id = "", batchId = "b1", studentId = "s2", studentName = "Bob",
                    date = "2026-09-08", status = AttendanceStatus.ABSENT, notes = "Sick"
                )
            )
        )

        val text = json.encodeToString(request)
        val decoded = json.decodeFromString<MarkAttendanceRequest>(text)

        assertEquals(2, decoded.records.size)
        assertEquals(AttendanceStatus.ABSENT, decoded.records[1].status)
        assertEquals("Sick", decoded.records[1].notes)
    }

    @Test
    fun `FeeRecord amounts survive JSON as numbers not strings`() {
        val record = FeeRecord(
            invoiceId = "f1", studentId = "s1", studentName = "Alice", monthYear = "September 2026",
            amountDue = 1500.0, amountPaid = 750.5, status = FeePaymentStatus.PENDING, dueDate = "2026-09-15"
        )
        val text = json.encodeToString(record)

        // Numbers must not be quoted — a common bug when hand-building JSON server-side
        assertTrue(text.contains("\"amountDue\":1500.0"))
        assertTrue(text.contains("\"amountPaid\":750.5"))
    }

    @Test
    fun `CreateBatchRequest defaults roomOrMeetingLink to empty string`() {
        val request = CreateBatchRequest(title = "Physics", subject = "Science", scheduleTime = "6pm")
        assertEquals("", request.roomOrMeetingLink)
    }

    @Test
    fun `AnalyticsOverview nests attendance and fees correctly`() {
        val overview = AnalyticsOverview(
            totalBatches = 3,
            totalStudents = 25,
            totalAssignments = 8,
            attendance = AttendanceOverview(presentCount = 20, absentCount = 3, lateCount = 2, excusedCount = 0, presentRate = 0.8),
            fees = FeesOverview(totalDue = 5000.0, totalCollected = 3000.0, totalPending = 2000.0, paidInvoices = 6, pendingInvoices = 4, overdueInvoices = 1)
        )

        val text = json.encodeToString(overview)
        val decoded = json.decodeFromString<AnalyticsOverview>(text)

        assertEquals(overview, decoded)
        assertEquals(0.8, decoded.attendance.presentRate)
    }

    // --- Multi-school registration ---

    @Test
    fun `RegisterRequest for joining a school sends schoolCode with the expected field names`() {
        val text = json.encodeToString(
            RegisterRequest(
                fullName = "Sam", email = "sam@example.com", password = "pw123456",
                role = UserRole.STUDENT, schoolCode = "SABC1234"
            )
        )
        assertTrue(text.contains("\"schoolCode\":\"SABC1234\""))
        assertTrue(text.contains("\"role\":\"STUDENT\""))
        assertTrue(text.contains("\"createSchool\":false"))
    }

    @Test
    fun `RegisterRequest for creating a school sends createSchool and schoolName`() {
        val text = json.encodeToString(
            RegisterRequest(
                fullName = "Ada", email = "ada@example.com", password = "pw123456",
                role = UserRole.TEACHER, createSchool = true, schoolName = "Oak School"
            )
        )
        assertTrue(text.contains("\"createSchool\":true"))
        assertTrue(text.contains("\"schoolName\":\"Oak School\""))
    }

    @Test
    fun `UserRole includes PARENT and serializes by name`() {
        assertEquals("\"PARENT\"", json.encodeToString(UserRole.PARENT))
        assertEquals(UserRole.PARENT, json.decodeFromString<UserRole>("\"PARENT\""))
    }

    @Test
    fun `AuthResponse decodes the school fields the backend returns`() {
        val lenient = Json { ignoreUnknownKeys = true }
        val body = """
            {"token":"t","userId":"u1","fullName":"Ada","email":"a@b.com","role":"TEACHER",
             "avatarUrl":null,"schoolId":"s1","schoolName":"Oak School","isSchoolAdmin":true}
        """.trimIndent()
        val decoded = lenient.decodeFromString<AuthResponse>(body)

        assertEquals("s1", decoded.schoolId)
        assertEquals("Oak School", decoded.schoolName)
        assertTrue(decoded.isSchoolAdmin)
    }

    @Test
    fun `AuthResponse still decodes when the school fields are absent`() {
        val lenient = Json { ignoreUnknownKeys = true }
        val decoded = lenient.decodeFromString<AuthResponse>(
            """{"token":"t","userId":"u1","fullName":"A","email":"a@b.com","role":"STUDENT"}"""
        )
        assertEquals(null, decoded.schoolId)
        assertEquals(false, decoded.isSchoolAdmin)
    }

    @Test
    fun `SchoolInfo decodes null join codes for non-admins`() {
        val lenient = Json { ignoreUnknownKeys = true }
        val decoded = lenient.decodeFromString<SchoolInfo>(
            """{"id":"s1","name":"Oak","isSchoolAdmin":false,"teacherCount":2,"studentCount":10,
                "parentCount":0,"studentCode":null,"teacherCode":null}"""
        )
        assertEquals(null, decoded.studentCode)
        assertEquals(10, decoded.studentCount)
    }

    @Test
    fun `RegenerateCodesRequest and RenameSchoolRequest use the expected field names`() {
        assertTrue(json.encodeToString(RegenerateCodesRequest(which = "student")).contains("\"which\":\"student\""))
        assertTrue(json.encodeToString(RenameSchoolRequest(name = "New")).contains("\"name\":\"New\""))
    }

    // --- Parent accounts ---

    @Test
    fun `LinkChildRequest uses the code field`() {
        assertTrue(json.encodeToString(LinkChildRequest(code = "ABCD2345")).contains("\"code\":\"ABCD2345\""))
    }

    @Test
    fun `ParentLinkCode decodes the backend response`() {
        val lenient = Json { ignoreUnknownKeys = true }
        val decoded = lenient.decodeFromString<ParentLinkCode>("""{"code":"ABCD2345","expiresAt":"2026-10-17T10:00:00.000Z"}""")
        assertEquals("ABCD2345", decoded.code)
        assertEquals("2026-10-17T10:00:00.000Z", decoded.expiresAt)
    }

    @Test
    fun `ChildSummary decodes exactly what the backend summary endpoint sends`() {
        val lenient = Json { ignoreUnknownKeys = true }
        val body = """
            {"child":{"id":"c1","fullName":"Alice","avatarUrl":null},
             "attendance":{"presentCount":8,"absentCount":1,"lateCount":1,"excusedCount":0,"presentRate":0.8},
             "fees":{"totalDue":3000,"totalPaid":1000,"totalPending":2000,"overdueInvoices":1},
             "assignments":{"total":5,"submitted":4,"graded":3,"averageScoreRate":0.85}}
        """.trimIndent()
        val decoded = lenient.decodeFromString<ChildSummary>(body)

        assertEquals("Alice", decoded.child.fullName)
        assertEquals(0.8, decoded.attendance.presentRate)
        assertEquals(2000.0, decoded.fees.totalPending, 0.0)
        assertEquals(1, decoded.fees.overdueInvoices)
        assertEquals(0.85, decoded.assignments.averageScoreRate)
    }

    @Test
    fun `ChildSummary accepts null rates when nothing has been marked or graded`() {
        val lenient = Json { ignoreUnknownKeys = true }
        val body = """
            {"child":{"id":"c1","fullName":"Alice"},
             "attendance":{"presentCount":0,"absentCount":0,"lateCount":0,"excusedCount":0,"presentRate":null},
             "fees":{"totalDue":0,"totalPaid":0,"totalPending":0,"overdueInvoices":0},
             "assignments":{"total":0,"submitted":0,"graded":0,"averageScoreRate":null}}
        """.trimIndent()
        val decoded = lenient.decodeFromString<ChildSummary>(body)
        assertEquals(null, decoded.attendance.presentRate)
        assertEquals(null, decoded.assignments.averageScoreRate)
    }

    @Test
    fun `parent attendance and assignment lists decode the extra batchTitle field`() {
        val lenient = Json { ignoreUnknownKeys = true }
        val record = lenient.decodeFromString<AttendanceRecord>(
            """{"id":"r1","batchId":"b1","batchTitle":"Math","studentId":"s1","studentName":"Al","date":"2026-09-08","status":"ABSENT","notes":""}"""
        )
        assertEquals("Math", record.batchTitle)
        assertEquals(AttendanceStatus.ABSENT, record.status)

        val assignment = lenient.decodeFromString<Assignment>(
            """{"id":"a1","batchId":"b1","batchTitle":"Math","title":"HW","description":"","dueDate":"2026-09-20","maxScore":50,"isSubmitted":true,"scoreEarned":45}"""
        )
        assertEquals("Math", assignment.batchTitle)
        assertEquals(45, assignment.scoreEarned)
    }

    @Test
    fun `SchoolMember decodes the members endpoint shape`() {
        val lenient = Json { ignoreUnknownKeys = true }
        val decoded = lenient.decodeFromString<SchoolMember>(
            """{"id":"u1","fullName":"Pat","email":"p@x.com","role":"PARENT","isSchoolAdmin":false,"avatarUrl":null,"joinedAt":"2026-01-02T03:04:05.000Z"}"""
        )
        assertEquals(UserRole.PARENT, decoded.role)
        assertEquals("2026-01-02T03:04:05.000Z", decoded.joinedAt)
    }
}
