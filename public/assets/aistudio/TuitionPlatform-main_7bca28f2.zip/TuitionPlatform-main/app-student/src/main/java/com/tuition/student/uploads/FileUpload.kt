package com.tuition.student.uploads

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File

/**
 * Copies a picked content:// URI into a temp file (Retrofit's multipart
 * body needs a concrete length/stream, which content URIs don't reliably
 * expose otherwise) and wraps it as a multipart part ready to upload.
 */
fun uriToMultipart(context: Context, uri: Uri, partName: String): MultipartBody.Part? {
    val contentResolver = context.contentResolver
    val mimeType = contentResolver.getType(uri) ?: "application/octet-stream"
    val displayName = queryDisplayName(context, uri) ?: "upload"

    val tempFile = File.createTempFile("upload_", "_$displayName", context.cacheDir)
    contentResolver.openInputStream(uri)?.use { input ->
        tempFile.outputStream().use { output -> input.copyTo(output) }
    } ?: return null

    val requestBody = tempFile.asRequestBody(mimeType.toMediaTypeOrNull())
    return MultipartBody.Part.createFormData(partName, displayName, requestBody)
}

private fun queryDisplayName(context: Context, uri: Uri): String? {
    if (uri.scheme != "content") return uri.lastPathSegment
    return context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
        val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (nameIndex >= 0 && cursor.moveToFirst()) cursor.getString(nameIndex) else null
    }
}
