package com.tuition.student.parent

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardOptions
import com.tuition.core.network.AttendanceRecord
import com.tuition.core.network.AttendanceStatus
import com.tuition.core.network.Assignment
import com.tuition.core.network.ChildProfile
import com.tuition.core.network.ChildSummary
import com.tuition.core.network.FeePaymentStatus
import com.tuition.core.network.FeeRecord
import com.tuition.core.network.LinkChildRequest
import com.tuition.core.network.TuitionApiService
import com.tuition.core.network.toUserMessage
import com.tuition.student.auth.SessionStore
import com.tuition.student.push.syncDeviceToken
import kotlinx.coroutines.launch

private enum class ParentTab(val title: String, val icon: ImageVector) {
    OVERVIEW("Overview", Icons.Default.Dashboard),
    ATTENDANCE("Attendance", Icons.Default.FactCheck),
    HOMEWORK("Homework", Icons.Default.Assignment),
    FEES("Fees", Icons.Default.Payment),
    ACCOUNT("Account", Icons.Default.Person)
}

private val Green = Color(0xFF2E7D32)
private val Red = Color(0xFFC62828)
private val Orange = Color(0xFFEF6C00)

/**
 * The parent's home screen: pick a child (a parent can link several), then
 * browse their attendance, homework and fees — read-only, plus paying fees.
 * Parents link to a child with a short-lived code the child creates in their
 * own app (Account → Parent access).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ParentAppRoot(apiService: TuitionApiService, sessionStore: SessionStore, onLogout: () -> Unit) {
    val token = "Bearer ${sessionStore.token}"
    val scope = rememberCoroutineScope()

    var tab by remember { mutableStateOf(ParentTab.OVERVIEW) }
    var children by remember { mutableStateOf<List<ChildProfile>>(emptyList()) }
    var childrenLoaded by remember { mutableStateOf(false) }
    var childrenError by remember { mutableStateOf<String?>(null) }
    var selectedChildId by remember { mutableStateOf<String?>(null) }
    var showLinkDialog by remember { mutableStateOf(false) }
    var childMenuOpen by remember { mutableStateOf(false) }

    fun loadChildren(select: String? = null) {
        scope.launch {
            try {
                val result = apiService.getChildren(token)
                children = result
                selectedChildId = select
                    ?: selectedChildId?.takeIf { id -> result.any { it.id == id } }
                    ?: result.firstOrNull()?.id
                childrenError = null
            } catch (e: Exception) {
                childrenError = e.toUserMessage("Couldn't load your children.")
            } finally {
                childrenLoaded = true
            }
        }
    }

    LaunchedEffect(Unit) {
        loadChildren()
        syncDeviceToken(apiService, sessionStore)
    }

    val selectedChild = children.firstOrNull { it.id == selectedChildId }

    if (showLinkDialog) {
        LinkChildDialog(
            apiService = apiService,
            token = token,
            onDismiss = { showLinkDialog = false },
            onLinked = { child ->
                showLinkDialog = false
                loadChildren(select = child.id)
            }
        )
    }

    // Nothing to show until a child is linked.
    if (childrenLoaded && children.isEmpty()) {
        LinkChildPrompt(
            error = childrenError,
            onLink = { showLinkDialog = true },
            onLogout = onLogout
        )
    } else Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Box {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable(enabled = children.size > 1) { childMenuOpen = true }
                        ) {
                            Text(selectedChild?.fullName ?: "Parent", fontWeight = FontWeight.Bold)
                            if (children.size > 1) Icon(Icons.Default.ArrowDropDown, contentDescription = "Switch child")
                        }
                        DropdownMenu(expanded = childMenuOpen, onDismissRequest = { childMenuOpen = false }) {
                            children.forEach { child ->
                                DropdownMenuItem(
                                    text = { Text(child.fullName) },
                                    onClick = { selectedChildId = child.id; childMenuOpen = false }
                                )
                            }
                        }
                    }
                },
                actions = {
                    IconButton(onClick = { showLinkDialog = true }) {
                        Icon(Icons.Default.PersonAdd, contentDescription = "Link another child")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
        },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                ParentTab.values().forEach { screen ->
                    NavigationBarItem(
                        selected = tab == screen,
                        onClick = { tab = screen },
                        icon = { Icon(screen.icon, contentDescription = screen.title) },
                        label = { Text(screen.title) }
                    )
                }
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize()) {
            val childId = selectedChildId
            when {
                !childrenLoaded -> CenteredLoader()
                childId == null -> ErrorMessage(childrenError ?: "No child selected.") { loadChildren() }
                tab == ParentTab.ACCOUNT -> ParentAccountTab(
                    sessionStore = sessionStore,
                    children = children,
                    onLinkChild = { showLinkDialog = true },
                    onUnlink = { child ->
                        scope.launch {
                            try {
                                apiService.unlinkChild(token, child.id)
                                loadChildren()
                            } catch (e: Exception) {
                                childrenError = e.toUserMessage("Couldn't remove that child.")
                            }
                        }
                    },
                    error = childrenError,
                    onLogout = onLogout
                )
                tab == ParentTab.OVERVIEW -> OverviewTab(apiService, token, childId)
                tab == ParentTab.ATTENDANCE -> AttendanceTab(apiService, token, childId)
                tab == ParentTab.HOMEWORK -> HomeworkTab(apiService, token, childId)
                tab == ParentTab.FEES -> FeesTab(apiService, token, childId)
            }
        }
    }
}

// ---------------------------------------------------------------------
// Shared bits
// ---------------------------------------------------------------------

@Composable
private fun CenteredLoader() {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
}

@Composable
private fun ErrorMessage(message: String, onRetry: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(message, color = Red, fontSize = 14.sp)
        Spacer(modifier = Modifier.height(12.dp))
        OutlinedButton(onClick = onRetry) { Text("Try again") }
    }
}

/**
 * Loads data whenever [key] (e.g. the selected child) changes, shows a spinner
 * or an error with retry, and hands the data to [content] along with a
 * `reload` function. Stale data stays on screen during a reload.
 */
@Composable
private fun <T> Loader(
    key: Any,
    errorFallback: String,
    load: suspend () -> T,
    content: @Composable (data: T, reload: () -> Unit) -> Unit
) {
    var data by remember(key) { mutableStateOf<T?>(null) }
    var error by remember(key) { mutableStateOf<String?>(null) }
    var reloadCounter by remember(key) { mutableStateOf(0) }

    LaunchedEffect(key, reloadCounter) {
        error = null
        try {
            data = load()
        } catch (e: Exception) {
            error = e.toUserMessage(errorFallback)
        }
    }

    val current = data
    when {
        current != null -> content(current) { reloadCounter++ }
        error != null -> ErrorMessage(error ?: errorFallback) { reloadCounter++ }
        else -> CenteredLoader()
    }
}

@Composable
private fun CardColumn(content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(10.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), content = content)
    }
}

private fun percent(rate: Double): String = "${Math.round(rate * 100)}%"
private fun money(amount: Double): String = String.format("%.2f", amount)

// ---------------------------------------------------------------------
// Linking a child
// ---------------------------------------------------------------------

@Composable
private fun LinkChildDialog(
    apiService: TuitionApiService,
    token: String,
    onDismiss: () -> Unit,
    onLinked: (ChildProfile) -> Unit
) {
    var code by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("Link your child") },
        text = {
            Column {
                Text(
                    "Ask your child to open this app, go to Account and tap \"Create parent code\". Enter that code here.",
                    fontSize = 13.sp, color = Color.Gray
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = code,
                    onValueChange = { code = it.uppercase().filter { ch -> !ch.isWhitespace() } },
                    label = { Text("Parent code") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii),
                    modifier = Modifier.fillMaxWidth()
                )
                error?.let {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(it, color = Red, fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = !busy && code.isNotBlank(),
                onClick = {
                    busy = true
                    error = null
                    scope.launch {
                        try {
                            onLinked(apiService.linkChild(token, LinkChildRequest(code)))
                        } catch (e: Exception) {
                            error = e.toUserMessage("Couldn't link that code.")
                        } finally {
                            busy = false
                        }
                    }
                }
            ) { Text(if (busy) "Linking..." else "Link") }
        },
        dismissButton = { TextButton(enabled = !busy, onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun LinkChildPrompt(error: String?, onLink: () -> Unit, onLogout: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Default.FamilyRestroom, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(56.dp))
        Spacer(modifier = Modifier.height(16.dp))
        Text("Link your child to get started", fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            "Ask your child to open this app, go to Account, and tap \"Create parent code\". Then enter the code here to see their attendance, homework and fees.",
            fontSize = 14.sp, color = Color.Gray
        )
        error?.let {
            Spacer(modifier = Modifier.height(10.dp))
            Text(it, color = Red, fontSize = 13.sp)
        }
        Spacer(modifier = Modifier.height(24.dp))
        Button(onClick = onLink, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(8.dp)) { Text("Enter parent code") }
        TextButton(onClick = onLogout) { Text("Log out") }
    }
}

// ---------------------------------------------------------------------
// Tabs
// ---------------------------------------------------------------------

@Composable
private fun OverviewTab(apiService: TuitionApiService, token: String, childId: String) {
    Loader(
        key = childId,
        errorFallback = "Couldn't load the overview.",
        load = { apiService.getChildSummary(token, childId) }
    ) { summary: ChildSummary, reload ->
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            val attendance = summary.attendance
            CardColumn {
                Text("Attendance — last 30 days", fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                val rate = attendance.presentRate
                if (rate == null) {
                    Text("No attendance has been marked yet.", color = Color.Gray, fontSize = 13.sp)
                } else {
                    Text(percent(rate), fontWeight = FontWeight.Bold, fontSize = 30.sp, color = if (rate >= 0.8) Green else Orange)
                    LinearProgressIndicator(progress = rate.toFloat().coerceIn(0f, 1f), modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
                    Text(
                        "Present ${attendance.presentCount} · Absent ${attendance.absentCount} · Late ${attendance.lateCount}",
                        fontSize = 13.sp, color = Color.Gray
                    )
                }
            }

            val fees = summary.fees
            CardColumn {
                Text("Fees", fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    if (fees.totalPending > 0) "${money(fees.totalPending)} outstanding" else "All paid up",
                    fontWeight = FontWeight.Bold, fontSize = 22.sp, color = if (fees.totalPending > 0) Orange else Green
                )
                Text("Paid ${money(fees.totalPaid)} of ${money(fees.totalDue)}", fontSize = 13.sp, color = Color.Gray)
                if (fees.overdueInvoices > 0) {
                    Text("${fees.overdueInvoices} overdue", fontSize = 13.sp, color = Red, fontWeight = FontWeight.SemiBold)
                }
            }

            val homework = summary.assignments
            CardColumn {
                Text("Homework", fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                if (homework.total == 0) {
                    Text("No assignments yet.", color = Color.Gray, fontSize = 13.sp)
                } else {
                    Text("${homework.submitted} of ${homework.total} submitted", fontWeight = FontWeight.Bold, fontSize = 22.sp)
                    LinearProgressIndicator(
                        progress = (homework.submitted.toFloat() / homework.total).coerceIn(0f, 1f),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
                    )
                    val average = homework.averageScoreRate
                    Text(
                        if (average != null) "${homework.graded} graded · average ${percent(average)}" else "Nothing graded yet",
                        fontSize = 13.sp, color = Color.Gray
                    )
                }
            }

            TextButton(onClick = reload, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("Refresh") }
        }
    }
}

@Composable
private fun AttendanceTab(apiService: TuitionApiService, token: String, childId: String) {
    Loader(
        key = childId,
        errorFallback = "Couldn't load attendance.",
        load = { apiService.getChildAttendance(token, childId) }
    ) { records: List<AttendanceRecord>, reload ->
        if (records.isEmpty()) {
            EmptyState("No attendance has been marked yet.", reload)
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(records, key = { it.id }) { record ->
                    CardColumn {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(record.batchTitle ?: "Class", fontWeight = FontWeight.SemiBold)
                                Text(record.date, fontSize = 12.sp, color = Color.Gray)
                                if (record.notes.isNotBlank()) Text(record.notes, fontSize = 12.sp, color = Color.Gray)
                            }
                            Text(
                                record.status.name.lowercase().replaceFirstChar { it.uppercase() },
                                color = when (record.status) {
                                    AttendanceStatus.PRESENT -> Green
                                    AttendanceStatus.ABSENT -> Red
                                    AttendanceStatus.LATE -> Orange
                                    else -> Color.Gray
                                },
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeworkTab(apiService: TuitionApiService, token: String, childId: String) {
    Loader(
        key = childId,
        errorFallback = "Couldn't load homework.",
        load = { apiService.getChildAssignments(token, childId) }
    ) { assignments: List<Assignment>, reload ->
        if (assignments.isEmpty()) {
            EmptyState("No homework has been set yet.", reload)
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(assignments, key = { it.id }) { item ->
                    CardColumn {
                        Text(item.title, fontWeight = FontWeight.SemiBold)
                        Text("${item.batchTitle ?: "Class"} · due ${item.dueDate}", fontSize = 12.sp, color = Color.Gray)
                        Spacer(modifier = Modifier.height(6.dp))
                        val score = item.scoreEarned
                        when {
                            score != null -> Text("Graded: $score / ${item.maxScore}", color = Green, fontWeight = FontWeight.Bold)
                            item.isSubmitted -> Text("Submitted — waiting for a grade", color = Orange)
                            else -> Text("Not submitted yet", color = Red)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FeesTab(apiService: TuitionApiService, token: String, childId: String) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var payingInvoiceId by remember { mutableStateOf<String?>(null) }
    var payError by remember { mutableStateOf<String?>(null) }

    Loader(
        key = childId,
        errorFallback = "Couldn't load fees.",
        load = { apiService.getChildFees(token, childId) }
    ) { fees: List<FeeRecord>, reload ->
        if (fees.isEmpty()) {
            EmptyState("No fees have been raised yet.", reload)
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                payError?.let { message ->
                    item { Text(message, color = Red, fontSize = 13.sp) }
                }
                items(fees, key = { it.invoiceId }) { fee ->
                    CardColumn {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(fee.monthYear, fontWeight = FontWeight.SemiBold)
                                Text("Due ${fee.dueDate}", fontSize = 12.sp, color = Color.Gray)
                                Text("Paid ${money(fee.amountPaid)} of ${money(fee.amountDue)}", fontSize = 12.sp, color = Color.Gray)
                            }
                            Text(
                                fee.status.name.lowercase().replaceFirstChar { it.uppercase() },
                                fontWeight = FontWeight.Bold,
                                color = when (fee.status) {
                                    FeePaymentStatus.PAID -> Green
                                    FeePaymentStatus.OVERDUE -> Red
                                    else -> Orange
                                }
                            )
                        }
                        if (fee.status != FeePaymentStatus.PAID) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = {
                                    payingInvoiceId = fee.invoiceId
                                    payError = null
                                    scope.launch {
                                        try {
                                            val checkout = apiService.createFeeCheckout(token, fee.invoiceId)
                                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(checkout.checkoutUrl)))
                                        } catch (e: Exception) {
                                            payError = e.toUserMessage("Payments aren't set up on this server yet.")
                                        } finally {
                                            payingInvoiceId = null
                                        }
                                    }
                                },
                                enabled = payingInvoiceId != fee.invoiceId,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(if (payingInvoiceId == fee.invoiceId) "Opening..." else "Pay Now")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyState(message: String, onRefresh: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(message, color = Color.Gray, fontSize = 14.sp)
        TextButton(onClick = onRefresh) { Text("Refresh") }
    }
}

@Composable
private fun ParentAccountTab(
    sessionStore: SessionStore,
    children: List<ChildProfile>,
    onLinkChild: () -> Unit,
    onUnlink: (ChildProfile) -> Unit,
    error: String?,
    onLogout: () -> Unit
) {
    var confirmUnlink by remember { mutableStateOf<ChildProfile?>(null) }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        CardColumn {
            Text(sessionStore.fullName, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(sessionStore.email, color = Color.Gray, fontSize = 13.sp)
            if (sessionStore.schoolName.isNotBlank()) {
                Text(sessionStore.schoolName, color = Color.Gray, fontSize = 13.sp)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text("Server: ${sessionStore.baseUrl}", fontSize = 12.sp, color = Color.Gray)
        }

        CardColumn {
            Text("Your children", fontWeight = FontWeight.Bold)
            children.forEach { child ->
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Text(child.fullName, modifier = Modifier.weight(1f))
                    TextButton(onClick = { confirmUnlink = child }) { Text("Remove", color = Red) }
                }
            }
            error?.let { Text(it, color = Red, fontSize = 12.sp) }
            OutlinedButton(onClick = onLinkChild, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(8.dp)) {
                Text("Link another child")
            }
        }

        Button(onClick = onLogout, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(8.dp)) { Text("Log Out") }
    }

    confirmUnlink?.let { child ->
        AlertDialog(
            onDismissRequest = { confirmUnlink = null },
            title = { Text("Remove ${child.fullName}?") },
            text = { Text("You'll stop seeing their attendance, homework and fees. They can create a new code if you want to link again.") },
            confirmButton = { TextButton(onClick = { confirmUnlink = null; onUnlink(child) }) { Text("Remove") } },
            dismissButton = { TextButton(onClick = { confirmUnlink = null }) { Text("Cancel") } }
        )
    }
}
