package com.tuition.student

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.tuition.core.network.*
import com.tuition.student.auth.ForgotPasswordScreen
import com.tuition.student.auth.LoginScreen
import com.tuition.student.auth.RegisterScreen
import com.tuition.student.auth.ServerSetupScreen
import com.tuition.student.auth.SessionStore
import com.tuition.student.parent.ParentAccessCard
import com.tuition.student.parent.ParentAppRoot
import com.tuition.student.push.syncDeviceToken
import com.tuition.student.push.unregisterDeviceToken
import com.tuition.student.uploads.uriToMultipart
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* Push still works without this; the OS just won't display incoming notifications. */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sessionStore = SessionStore(applicationContext)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Color(0xFF1E88E5),
                    secondary = Color(0xFF26A69A),
                    background = Color(0xFFF8F9FA),
                    surface = Color.White
                )
            ) {
                StudentAppEntryPoint(sessionStore)
            }
        }
    }
}

private enum class AuthStage { SERVER_SETUP, LOGIN, REGISTER, FORGOT_PASSWORD, AUTHENTICATED }

private data class LoadState<T>(
    val data: List<T> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null
)

@Composable
private fun StudentAppEntryPoint(sessionStore: SessionStore) {
    var stage by remember {
        mutableStateOf(
            when {
                sessionStore.baseUrl.isBlank() -> AuthStage.SERVER_SETUP
                sessionStore.isLoggedIn -> AuthStage.AUTHENTICATED
                else -> AuthStage.LOGIN
            }
        )
    }
    var apiService by remember {
        mutableStateOf(if (sessionStore.baseUrl.isNotBlank()) TuitionApiClient.create(sessionStore.baseUrl) else null)
    }
    var isLoading by remember { mutableStateOf(false) }
    var authError by remember { mutableStateOf<String?>(null) }
    var resetLinkSent by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    when (stage) {
        AuthStage.SERVER_SETUP -> ServerSetupScreen(
            initialUrl = sessionStore.baseUrl,
            onContinue = { url ->
                sessionStore.baseUrl = url
                apiService = TuitionApiClient.create(url)
                stage = if (sessionStore.isLoggedIn) AuthStage.AUTHENTICATED else AuthStage.LOGIN
            }
        )

        AuthStage.LOGIN -> LoginScreen(
            initialEmail = sessionStore.email,
            isLoading = isLoading,
            error = authError,
            onLogin = { email, password ->
                apiService?.let { service ->
                    isLoading = true
                    authError = null
                    scope.launch {
                        try {
                            val response = service.login(LoginRequest(email, password))
                            if (response.role == UserRole.TEACHER || response.role == UserRole.ADMIN) {
                                authError = "This app is for students and parents. Please use the Teacher app."
                            } else {
                                sessionStore.saveSession(response)
                                stage = AuthStage.AUTHENTICATED
                            }
                        } catch (e: Exception) {
                            authError = "Couldn't sign in: ${e.toUserMessage("check your details and try again.")}"
                        } finally {
                            isLoading = false
                        }
                    }
                }
            },
            onGoToRegister = { authError = null; stage = AuthStage.REGISTER },
            onForgotPassword = { authError = null; resetLinkSent = false; stage = AuthStage.FORGOT_PASSWORD },
            onChangeServer = { stage = AuthStage.SERVER_SETUP }
        )

        AuthStage.REGISTER -> RegisterScreen(
            isLoading = isLoading,
            error = authError,
            onRegister = { fullName, email, password, role, schoolCode ->
                apiService?.let { service ->
                    isLoading = true
                    authError = null
                    scope.launch {
                        try {
                            val response = service.register(
                                RegisterRequest(
                                    fullName = fullName,
                                    email = email,
                                    password = password,
                                    role = role,
                                    schoolCode = schoolCode
                                )
                            )
                            sessionStore.saveSession(response)
                            stage = AuthStage.AUTHENTICATED
                        } catch (e: Exception) {
                            authError = "Couldn't create account: ${e.toUserMessage("please try again.")}"
                        } finally {
                            isLoading = false
                        }
                    }
                }
            },
            onBackToLogin = { authError = null; stage = AuthStage.LOGIN }
        )

        AuthStage.FORGOT_PASSWORD -> ForgotPasswordScreen(
            isLoading = isLoading,
            error = authError,
            linkSent = resetLinkSent,
            onSubmit = { email ->
                apiService?.let { service ->
                    isLoading = true
                    authError = null
                    scope.launch {
                        try {
                            service.forgotPassword(ForgotPasswordRequest(email))
                            resetLinkSent = true
                        } catch (e: Exception) {
                            authError = e.toUserMessage("Couldn't send a reset link. Please try again.")
                        } finally {
                            isLoading = false
                        }
                    }
                }
            },
            onBack = { authError = null; resetLinkSent = false; stage = AuthStage.LOGIN }
        )

        AuthStage.AUTHENTICATED -> {
            apiService?.let { service ->
                // A saved token from before an upgrade (or one that has expired) is rejected with
                // 401. Check once up front and go back to sign-in, rather than showing an error on
                // every screen. If the phone is simply offline, carry on — screens report their own errors.
                var sessionChecked by remember { mutableStateOf(false) }
                LaunchedEffect(service) {
                    try {
                        service.getMe("Bearer ${sessionStore.token}")
                    } catch (e: Exception) {
                        if (e.isUnauthorized()) {
                            sessionStore.clearSession()
                            authError = "Please sign in again to continue."
                            stage = AuthStage.LOGIN
                        }
                    }
                    sessionChecked = true
                }

                val logout: () -> Unit = {
                    scope.launch {
                        unregisterDeviceToken(service, sessionStore)
                        sessionStore.clearSession()
                        stage = AuthStage.LOGIN
                    }
                }

                if (!sessionChecked) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                } else if (sessionStore.isParent) {
                    ParentAppRoot(apiService = service, sessionStore = sessionStore, onLogout = logout)
                } else {
                    StudentAppRoot(apiService = service, sessionStore = sessionStore, onLogout = logout)
                }
            }
        }
    }
}

enum class StudentNavScreen(val title: String, val icon: ImageVector) {
    DASHBOARD("Dashboard", Icons.Default.Dashboard),
    ATTENDANCE("Attendance", Icons.Default.FactCheck),
    ASSIGNMENTS("Assignments", Icons.Default.Assignment),
    FEES("Fees", Icons.Default.Payment),
    ACCOUNT("Account", Icons.Default.Person)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun StudentAppRoot(apiService: TuitionApiService, sessionStore: SessionStore, onLogout: () -> Unit) {
    var selectedScreen by remember { mutableStateOf(StudentNavScreen.DASHBOARD) }
    var batchesState by remember { mutableStateOf(LoadState<CourseBatch>()) }
    var selectedBatchId by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val token = "Bearer ${sessionStore.token}"

    fun loadBatches() {
        scope.launch {
            batchesState = batchesState.copy(isLoading = true, error = null)
            try {
                val result = apiService.getMyBatches(token)
                batchesState = LoadState(data = result)
                if (selectedBatchId == null && result.isNotEmpty()) selectedBatchId = result.first().id
            } catch (e: Exception) {
                batchesState = LoadState(error = e.toUserMessage("Failed to load your classes"))
            }
        }
    }

    LaunchedEffect(Unit) {
        loadBatches()
        syncDeviceToken(apiService, sessionStore)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(selectedScreen.title, fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
        },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                StudentNavScreen.values().forEach { screen ->
                    NavigationBarItem(
                        selected = selectedScreen == screen,
                        onClick = { selectedScreen = screen },
                        icon = { Icon(screen.icon, contentDescription = screen.title) },
                        label = { Text(screen.title) }
                    )
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            when (selectedScreen) {
                StudentNavScreen.DASHBOARD -> StudentDashboardScreen(
                    apiService = apiService,
                    token = token,
                    username = sessionStore.fullName,
                    batchesState = batchesState,
                    onEnrolled = { loadBatches() }
                )
                StudentNavScreen.ATTENDANCE -> StudentAttendanceScreen(apiService, token, batchesState.data, selectedBatchId) { selectedBatchId = it }
                StudentNavScreen.ASSIGNMENTS -> StudentAssignmentsScreen(apiService, token, batchesState.data, selectedBatchId) { selectedBatchId = it }
                StudentNavScreen.FEES -> StudentFeeScreen(apiService, token)
                StudentNavScreen.ACCOUNT -> StudentAccountScreen(apiService, token, sessionStore, onLogout)
            }
        }
    }
}

@Composable
private fun BatchPicker(batches: List<CourseBatch>, selectedBatchId: String?, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val selected = batches.find { it.id == selectedBatchId }

    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
        OutlinedTextField(
            value = selected?.title ?: "Select a class",
            onValueChange = {},
            readOnly = true,
            label = { Text("Class") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier
                .menuAnchor()
                .fillMaxWidth()
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            batches.forEach { batch ->
                DropdownMenuItem(text = { Text(batch.title) }, onClick = {
                    onSelect(batch.id)
                    expanded = false
                })
            }
        }
    }
}

@Composable
fun StudentDashboardScreen(
    apiService: TuitionApiService,
    token: String,
    username: String,
    batchesState: LoadState<CourseBatch>,
    onEnrolled: () -> Unit
) {
    var showBrowse by remember { mutableStateOf(false) }
    var browseState by remember { mutableStateOf(LoadState<CourseBatch>()) }
    var joiningBatchId by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    fun loadBrowse() {
        scope.launch {
            browseState = browseState.copy(isLoading = true, error = null)
            try {
                browseState = LoadState(data = apiService.browseBatches(token))
            } catch (e: Exception) {
                browseState = LoadState(error = e.toUserMessage("Failed to load available classes"))
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Welcome back, $username!", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("${batchesState.data.size} classes", color = Color.White.copy(alpha = 0.9f))
                }
            }
        }

        if (batchesState.isLoading) {
            item { LinearProgressIndicator(modifier = Modifier.fillMaxWidth()) }
        }
        if (batchesState.error != null) {
            item { Text(batchesState.error, color = Color(0xFFC62828), fontSize = 13.sp) }
        }

        item { Text("Your Scheduled Classes", fontSize = 18.sp, fontWeight = FontWeight.SemiBold) }

        if (batchesState.data.isEmpty() && !batchesState.isLoading) {
            item { Text("You're not enrolled in any classes yet — browse and join one below.", color = Color.Gray) }
        }

        items(batchesState.data) { batch ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(batch.title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("Instructor: ${batch.teacherName}", color = Color.Gray, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Time: ${batch.scheduleTime}", color = MaterialTheme.colorScheme.secondary, fontSize = 13.sp)
                }
            }
        }

        item {
            OutlinedButton(
                onClick = {
                    showBrowse = !showBrowse
                    if (showBrowse) loadBrowse()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Search, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text(if (showBrowse) "Hide Available Classes" else "Browse & Join a Class")
            }
        }

        if (showBrowse) {
            if (browseState.isLoading) {
                item { LinearProgressIndicator(modifier = Modifier.fillMaxWidth()) }
            }
            if (browseState.error != null) {
                item { Text(browseState.error, color = Color(0xFFC62828), fontSize = 13.sp) }
            }
            val alreadyEnrolledIds = batchesState.data.map { it.id }.toSet()
            val joinable = browseState.data.filter { it.id !in alreadyEnrolledIds }
            if (joinable.isEmpty() && !browseState.isLoading) {
                item { Text("No other classes available to join right now.", color = Color.Gray) }
            }
            items(joinable) { batch ->
                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F8E9)), shape = RoundedCornerShape(10.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(batch.title, fontWeight = FontWeight.Bold)
                            Text("${batch.subject} • ${batch.teacherName}", fontSize = 12.sp, color = Color.Gray)
                        }
                        Button(
                            onClick = {
                                joiningBatchId = batch.id
                                scope.launch {
                                    try {
                                        apiService.enrollInBatch(token, batch.id)
                                        onEnrolled()
                                        loadBrowse()
                                    } catch (e: Exception) {
                                        browseState = browseState.copy(error = e.toUserMessage("Failed to join"))
                                    } finally {
                                        joiningBatchId = null
                                    }
                                }
                            },
                            enabled = joiningBatchId != batch.id,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(if (joiningBatchId == batch.id) "Joining..." else "Join")
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentAttendanceScreen(
    apiService: TuitionApiService,
    token: String,
    batches: List<CourseBatch>,
    selectedBatchId: String?,
    onSelectBatch: (String) -> Unit
) {
    var records by remember { mutableStateOf<List<AttendanceRecord>>(emptyList()) }
    var isLoading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(selectedBatchId) {
        val batchId = selectedBatchId ?: return@LaunchedEffect
        isLoading = true
        error = null
        try {
            records = apiService.getAttendance(token, batchId)
        } catch (e: Exception) {
            error = e.toUserMessage("Failed to load attendance")
        } finally {
            isLoading = false
        }
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        BatchPicker(batches, selectedBatchId, onSelectBatch)
        Spacer(modifier = Modifier.height(12.dp))

        if (isLoading) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        if (error != null) Text(error ?: "", color = Color(0xFFC62828), fontSize = 13.sp)

        LazyColumn(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (selectedBatchId == null) {
                item { Text("Join a class to see attendance.", color = Color.Gray) }
            } else if (records.isEmpty() && !isLoading) {
                item { Text("No attendance records yet.", color = Color.Gray) }
            }

            items(records) { record ->
                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(8.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(record.date, fontWeight = FontWeight.Bold)
                            if (record.notes.isNotBlank()) {
                                Text(record.notes, fontSize = 12.sp, color = Color.Gray)
                            }
                        }
                        val statusColor = when (record.status) {
                            AttendanceStatus.PRESENT -> Color(0xFF2E7D32)
                            AttendanceStatus.ABSENT -> Color(0xFFC62828)
                            AttendanceStatus.LATE -> Color(0xFFEF6C00)
                            AttendanceStatus.EXCUSED -> Color(0xFF1565C0)
                        }
                        Text(record.status.name, color = statusColor, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentAssignmentsScreen(
    apiService: TuitionApiService,
    token: String,
    batches: List<CourseBatch>,
    selectedBatchId: String?,
    onSelectBatch: (String) -> Unit
) {
    var assignments by remember { mutableStateOf<List<Assignment>>(emptyList()) }
    var isLoading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var submittingId by remember { mutableStateOf<String?>(null) }
    var uploadingId by remember { mutableStateOf<String?>(null) }
    var pendingUploadAssignmentId by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    suspend fun loadAssignments(batchId: String) {
        isLoading = true
        error = null
        try {
            assignments = apiService.getAssignments(token, batchId)
        } catch (e: Exception) {
            error = e.toUserMessage("Failed to load assignments")
        } finally {
            isLoading = false
        }
    }

    LaunchedEffect(selectedBatchId) {
        selectedBatchId?.let { loadAssignments(it) }
    }

    val submissionPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val assignmentId = pendingUploadAssignmentId
        val batchId = selectedBatchId
        if (uri == null || assignmentId == null || batchId == null) return@rememberLauncherForActivityResult
        uploadingId = assignmentId
        scope.launch {
            try {
                val part = uriToMultipart(context, uri, "file")
                if (part != null) {
                    apiService.uploadSubmissionAttachment(token, batchId, assignmentId, part)
                    loadAssignments(batchId)
                } else {
                    error = "Couldn't read that file."
                }
            } catch (e: Exception) {
                error = e.toUserMessage("Failed to upload file")
            } finally {
                uploadingId = null
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        BatchPicker(batches, selectedBatchId, onSelectBatch)
        Spacer(modifier = Modifier.height(12.dp))

        if (isLoading) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        if (error != null) Text(error ?: "", color = Color(0xFFC62828), fontSize = 13.sp)

        LazyColumn(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (selectedBatchId == null) {
                item { Text("Join a class to see assignments.", color = Color.Gray) }
            } else if (assignments.isEmpty() && !isLoading) {
                item { Text("No assignments published yet.", color = Color.Gray) }
            }

            items(assignments) { item ->
                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(10.dp)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(item.title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text(
                                if (item.isSubmitted) "Submitted (${item.scoreEarned ?: "-"}/${item.maxScore})" else "Pending",
                                color = if (item.isSubmitted) Color(0xFF2E7D32) else Color(0xFFD32F2F),
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        if (item.description.isNotBlank()) {
                            Text(item.description, color = Color.DarkGray, fontSize = 14.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                        }
                        Text("Due: ${item.dueDate}", fontSize = 12.sp, color = Color.Gray)
                        if (item.attachmentUrl != null) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                "📎 ${item.attachmentName ?: "Teacher's attachment"}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.clickable {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(item.attachmentUrl)))
                                }
                            )
                        }
                        if (item.submissionAttachmentUrl != null) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "Your file: ${item.submissionAttachmentName ?: "View"}",
                                fontSize = 12.sp,
                                color = Color(0xFF2E7D32),
                                modifier = Modifier.clickable {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(item.submissionAttachmentUrl)))
                                }
                            )
                        }
                        if (!item.isSubmitted) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = {
                                        val batchId = selectedBatchId ?: return@Button
                                        submittingId = item.id
                                        scope.launch {
                                            try {
                                                apiService.submitAssignment(token, batchId, item.id)
                                                loadAssignments(batchId)
                                            } catch (e: Exception) {
                                                error = e.toUserMessage("Failed to submit")
                                            } finally {
                                                submittingId = null
                                            }
                                        }
                                    },
                                    enabled = submittingId != item.id && uploadingId != item.id,
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(if (submittingId == item.id) "Submitting..." else "Mark Submitted")
                                }
                                OutlinedButton(
                                    onClick = {
                                        pendingUploadAssignmentId = item.id
                                        submissionPicker.launch("*/*")
                                    },
                                    enabled = submittingId != item.id && uploadingId != item.id,
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(if (uploadingId == item.id) "Uploading..." else "Submit with File")
                                }
                            }
                        } else if (item.scoreEarned == null) {
                            // Submitted but not graded yet — allow replacing the uploaded file
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedButton(
                                onClick = {
                                    pendingUploadAssignmentId = item.id
                                    submissionPicker.launch("*/*")
                                },
                                enabled = uploadingId != item.id,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(if (uploadingId == item.id) "Uploading..." else "Replace File")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StudentFeeScreen(apiService: TuitionApiService, token: String) {
    var feesState by remember { mutableStateOf(LoadState<FeeRecord>()) }
    var payingInvoiceId by remember { mutableStateOf<String?>(null) }
    var payError by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    fun loadFees() {
        scope.launch {
            feesState = feesState.copy(isLoading = true, error = null)
            try {
                feesState = LoadState(data = apiService.getFeeOverview(token))
            } catch (e: Exception) {
                feesState = LoadState(error = e.toUserMessage("Failed to load fee records"))
            }
        }
    }

    LaunchedEffect(Unit) { loadFees() }

    Column(modifier = Modifier.fillMaxSize()) {
        if (feesState.isLoading) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        if (feesState.error != null) {
            Text(feesState.error, color = Color(0xFFC62828), modifier = Modifier.padding(16.dp))
        }
        if (payError != null) {
            Text(payError ?: "", color = Color(0xFFC62828), fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp))
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (feesState.data.isEmpty() && !feesState.isLoading && feesState.error == null) {
                item { Text("No fee records yet.", color = Color.Gray) }
            }

            items(feesState.data) { fee ->
                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(10.dp)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(fee.monthYear, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Text("Due Date: ${fee.dueDate}", color = Color.Gray, fontSize = 13.sp)
                                Text("Amount: ₹${fee.amountDue}", fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                            }
                            Text(
                                fee.status.name,
                                fontWeight = FontWeight.Bold,
                                color = if (fee.status == FeePaymentStatus.PAID) Color(0xFF2E7D32) else Color(0xFFEF6C00)
                            )
                        }
                        if (fee.status != FeePaymentStatus.PAID) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = {
                                    payingInvoiceId = fee.invoiceId
                                    payError = null
                                    scope.launch {
                                        try {
                                            val checkout = apiService.createFeeCheckout(token, fee.invoiceId)
                                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(checkout.checkoutUrl)))
                                        } catch (e: Exception) {
                                            payError = e.toUserMessage("Payments aren't set up on this server yet.")
                                        } finally {
                                            payingInvoiceId = null
                                        }
                                    }
                                },
                                enabled = payingInvoiceId != fee.invoiceId,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(if (payingInvoiceId == fee.invoiceId) "Opening..." else "Pay Now")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StudentAccountScreen(apiService: TuitionApiService, token: String, sessionStore: SessionStore, onLogout: () -> Unit) {
    var avatarUrl by remember { mutableStateOf<String?>(null) }
    var isUploadingPhoto by remember { mutableStateOf(false) }
    var photoError by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    fun refreshProfile() {
        scope.launch {
            try {
                avatarUrl = apiService.getMe(token).avatarUrl
            } catch (e: Exception) {
                // Non-fatal — the account screen still works without a fresh avatar fetch.
            }
        }
    }

    LaunchedEffect(Unit) { refreshProfile() }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        isUploadingPhoto = true
        photoError = null
        scope.launch {
            try {
                val part = uriToMultipart(context, uri, "photo")
                if (part == null) {
                    photoError = "Couldn't read that file."
                } else {
                    apiService.uploadProfilePhoto(token, part)
                    refreshProfile()
                }
            } catch (e: Exception) {
                photoError = e.toUserMessage("Failed to upload photo")
            } finally {
                isUploadingPhoto = false
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(10.dp)) {
            Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier
                        .size(84.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFE0E0E0))
                        .clickable(enabled = !isUploadingPhoto) { photoPicker.launch("image/*") },
                    contentAlignment = Alignment.Center
                ) {
                    if (avatarUrl != null) {
                        AsyncImage(
                            model = avatarUrl,
                            contentDescription = "Profile photo",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Icon(Icons.Default.Person, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(40.dp))
                    }
                    if (isUploadingPhoto) {
                        CircularProgressIndicator(modifier = Modifier.size(28.dp), strokeWidth = 2.dp)
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text("Tap to change photo", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                if (photoError != null) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(photoError ?: "", color = Color(0xFFC62828), fontSize = 11.sp)
                }
                Spacer(modifier = Modifier.height(14.dp))
                Text(sessionStore.fullName, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(sessionStore.email, color = Color.Gray, fontSize = 13.sp)
                if (sessionStore.schoolName.isNotBlank()) {
                    Text(sessionStore.schoolName, color = Color.Gray, fontSize = 13.sp)
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text("Server: ${sessionStore.baseUrl}", fontSize = 12.sp, color = Color.Gray)
            }
        }
        ParentAccessCard(apiService = apiService, token = token)
        Button(onClick = onLogout, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(8.dp)) {
            Text("Log Out")
        }
    }
}
