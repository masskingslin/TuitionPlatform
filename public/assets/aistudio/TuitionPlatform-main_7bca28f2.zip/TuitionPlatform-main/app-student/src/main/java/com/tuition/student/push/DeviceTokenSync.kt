package com.tuition.student.push

import com.google.firebase.messaging.FirebaseMessaging
import com.tuition.core.network.RegisterDeviceRequest
import com.tuition.core.network.TuitionApiService
import com.tuition.core.network.UnregisterDeviceRequest
import com.tuition.student.auth.SessionStore
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

suspend fun currentFcmToken(): String? = suspendCancellableCoroutine { cont ->
    FirebaseMessaging.getInstance().token
        .addOnCompleteListener { task ->
            cont.resume(if (task.isSuccessful) task.result else null)
        }
}

/** Fetches the current FCM token (if any) and makes sure the backend has it on file. */
suspend fun syncDeviceToken(apiService: TuitionApiService, sessionStore: SessionStore) {
    val authToken = sessionStore.token ?: return
    val fcmToken = currentFcmToken() ?: sessionStore.deviceToken ?: return
    try {
        apiService.registerDevice("Bearer $authToken", RegisterDeviceRequest(fcmToken))
        sessionStore.deviceToken = fcmToken
    } catch (e: Exception) {
        // Non-fatal — push notifications just won't arrive until the next successful sync.
    }
}

/** Best-effort: tells the backend to stop sending push notifications to this device. */
suspend fun unregisterDeviceToken(apiService: TuitionApiService, sessionStore: SessionStore) {
    val authToken = sessionStore.token ?: return
    val fcmToken = sessionStore.deviceToken ?: return
    try {
        apiService.unregisterDevice("Bearer $authToken", UnregisterDeviceRequest(fcmToken))
    } catch (e: Exception) {
        // Non-fatal
    }
}
