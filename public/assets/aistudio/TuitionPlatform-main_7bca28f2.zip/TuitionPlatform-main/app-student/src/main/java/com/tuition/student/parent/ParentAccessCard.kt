package com.tuition.student.parent

import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tuition.core.network.LinkedParent
import com.tuition.core.network.ParentLinkCode
import com.tuition.core.network.TuitionApiService
import com.tuition.core.network.toUserMessage
import kotlinx.coroutines.launch

/**
 * Lets a student give a parent read-only access: create a code (valid 48 hours),
 * hand it over, and later see — and remove — everyone who can view their data.
 */
@Composable
fun ParentAccessCard(apiService: TuitionApiService, token: String) {
    var parents by remember { mutableStateOf<List<LinkedParent>>(emptyList()) }
    var code by remember { mutableStateOf<ParentLinkCode?>(null) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var confirmRemove by remember { mutableStateOf<LinkedParent?>(null) }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    fun loadParents() {
        scope.launch {
            try {
                parents = apiService.getMyParents(token)
            } catch (e: Exception) {
                error = e.toUserMessage("Couldn't load linked parents.")
            }
        }
    }

    fun createCode() {
        scope.launch {
            busy = true
            error = null
            try {
                code = apiService.createParentLinkCode(token)
            } catch (e: Exception) {
                error = e.toUserMessage("Couldn't create a code.")
            } finally {
                busy = false
            }
        }
    }

    LaunchedEffect(Unit) { loadParents() }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(10.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Parent access", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(
                "Let a parent follow your attendance, homework and fees. Create a code and give it to them — it works for 48 hours. They can only view, not change anything.",
                fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))
            val current = code
            if (current != null) {
                Text("Your parent code", fontSize = 12.sp, color = Color.Gray)
                Text(current.code, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 26.sp)
                Text("Valid for 48 hours. Creating a new code replaces this one.", fontSize = 11.sp, color = Color.Gray)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
                    OutlinedButton(
                        onClick = {
                            val send = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, "Use this code in the Tuition app to see my school progress: ${current.code}")
                            }
                            context.startActivity(Intent.createChooser(send, "Share code"))
                        },
                        shape = RoundedCornerShape(8.dp)
                    ) { Text("Share", fontSize = 13.sp) }
                    OutlinedButton(onClick = { createCode() }, enabled = !busy, shape = RoundedCornerShape(8.dp)) {
                        Text("New code", fontSize = 13.sp)
                    }
                }
            } else {
                Button(onClick = { createCode() }, enabled = !busy, shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Text(if (busy) "Creating..." else "Create parent code")
                }
            }

            error?.let {
                Spacer(modifier = Modifier.height(8.dp))
                Text(it, color = Color(0xFFC62828), fontSize = 12.sp)
            }

            if (parents.isNotEmpty()) {
                Spacer(modifier = Modifier.height(14.dp))
                Text("Parents who can see your data", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                parents.forEach { parent ->
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(parent.fullName, fontSize = 14.sp)
                            Text(parent.email, fontSize = 11.sp, color = Color.Gray)
                        }
                        TextButton(onClick = { confirmRemove = parent }) { Text("Remove", color = Color(0xFFC62828)) }
                    }
                }
            }
        }
    }

    confirmRemove?.let { parent ->
        AlertDialog(
            onDismissRequest = { confirmRemove = null },
            title = { Text("Remove ${parent.fullName}?") },
            text = { Text("They will immediately lose access to your attendance, homework and fees.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmRemove = null
                    scope.launch {
                        try {
                            apiService.revokeParent(token, parent.id)
                            loadParents()
                        } catch (e: Exception) {
                            error = e.toUserMessage("Couldn't remove that parent.")
                        }
                    }
                }) { Text("Remove") }
            },
            dismissButton = { TextButton(onClick = { confirmRemove = null }) { Text("Cancel") } }
        )
    }
}
