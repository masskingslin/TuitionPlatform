# Tuition Platform Backend

A self-hosted REST API (Node.js/Express + PostgreSQL) that the Teacher and
Student apps talk to. Replaces the old "embedded server on the teacher's
phone" approach with a real backend that works over the internet, for
any number of teachers and students.

## Quick start (Docker — recommended)

```bash
cd backend
cp .env.example .env      # set JWT_SECRET and DEFAULT_ADMIN_PASSWORD first
docker compose up -d --build
```

`docker compose` refuses to start until `JWT_SECRET` and `DEFAULT_ADMIN_PASSWORD`
are set in `.env` (generate a secret with `openssl rand -hex 32`) — the API runs
with `NODE_ENV=production`, which also rejects placeholder secrets.

On first boot against an empty database the API applies its schema and creates
**one school plus a teacher account that administers it** (from
`DEFAULT_SCHOOL_NAME`, `DEFAULT_ADMIN_EMAIL`, `DEFAULT_ADMIN_PASSWORD`). The
school's two **join codes** are printed in the server log
(`docker compose logs api`) and are also shown to that teacher in the Teacher
app (Account tab) and at `/admin` (School tab). Hand the codes out — see
"Schools, roles and join codes" below.

Check it's alive:
```bash
curl http://localhost:4000/health
```

## Quick start (without Docker)

Requires Node.js 18+ and a running PostgreSQL instance.

```bash
cd backend
npm install
cp .env.example .env      # point DATABASE_URL at your Postgres instance
npm run migrate           # applies schema.sql (safe to re-run)
npm run seed               # creates the default teacher account
npm start
```

## Deploying it for real

Any host that can run a Node.js process plus Postgres works — Railway,
Render, Fly.io, a plain VPS with Docker, etc. In broad strokes:

1. Provision a PostgreSQL database (managed or self-hosted). If it requires
   TLS (most managed providers do), set `DATABASE_SSL=true`.
2. Set `DATABASE_URL`, a strong random `JWT_SECRET` (e.g. `openssl rand -hex 32`),
   and your `DEFAULT_ADMIN_*` values as environment variables on the host.
3. Deploy the `backend/` folder (the included `Dockerfile` works as-is on
   any Docker-based platform).
4. Point the DNS/URL you get at the apps — see below.

Once deployed, put that URL (e.g. `https://api.yourschool.com`) into the
"Server address" field on the Teacher and Student apps' first-run screen.
It's stored on-device, so this only needs to happen once per install.

## Auth model

- Real accounts: email + password, one account per teacher, student or
  parent, created via `/api/auth/register`. No single shared "admin" login.
- Password reset uses real emailed links: `POST /api/auth/forgot-password`
  generates a one-hour token and emails a link to `{APP_BASE_URL}/reset-password?token=...`.
  That link opens a small web page (served by this backend, not the apps)
  where the user sets a new password. Configure `SMTP_*` in `.env` to send
  real emails — with `SMTP_HOST` left blank, reset links are printed to the
  server console instead, which is convenient for local development.
- Tokens are JWTs (`JWT_EXPIRES_IN`, default 7 days) sent as
  `Authorization: Bearer <token>`. A token carries the user's school, so every
  request is automatically limited to that school. Tokens issued before
  multi-school support are rejected with "Session expired, please sign in
  again" (the apps handle this by returning to the sign-in screen).
- Unknown emails and wrong passwords return the same error, and take the same
  time, so sign-in can't be used to discover which emails have accounts.

## Schools, roles and join codes

One backend can host **many schools**; each is fully isolated (a teacher,
student or parent only ever sees data from their own school).

| Role | How they join |
|---|---|
| **Teacher** | Either starts a new school (`createSchool: true`, `schoolName`) and becomes its **school admin**, or joins one with the school's **teacher code** (starts with `T`). |
| **Student** | Joins with the school's **student/parent code** (starts with `S`). |
| **Parent** | Joins with the same **student/parent code**, then links to their child (below). |

The school admin (a teacher) can see both codes, **rotate** either one if it
leaks, rename the school, and list members — in the Teacher app's Account tab,
at `/admin` (School tab), or via `/api/school`. Rotating a code only affects
future sign-ups; existing members are untouched. Using the wrong kind of code
(e.g. a student trying the teacher code) is refused, so students can't make
themselves teachers.

Email addresses are unique across the whole server, so someone who belongs to
two schools needs two emails.

## Parent accounts

A parent gets **read-only** access to their child's attendance, homework,
grades and fees, and can pay fees online. Linking is controlled by the child:

1. The student taps *Account → Create parent code* in the Student & Parent app
   (`POST /api/parents/link-code`; 8 characters, valid 48 hours, a new code
   replaces the old one).
2. The parent registers as a *Parent* with the school's student/parent code,
   then enters the child's code (`POST /api/parents/link`). The child must be in
   the parent's school. A parent can link several children, and several
   parents can link the same child.
3. The student can see who has access and **remove** any parent at any time
   (`GET /api/parents/my-parents`, `DELETE /api/parents/my-parents/:parentId`).

Parents also receive push notifications for their child's new assignments,
grades, absences/lateness and fee payments. A parent asking for a child they
aren't linked to gets a 404, never a 403, so a student's existence can't be
probed.

## Security

- **Rate limiting** (per IP, in memory): failed sign-ins are limited per
  *account + IP* (default 10 per 15 minutes) so one account being attacked
  doesn't lock out classmates on the same school Wi-Fi; password-reset
  requests per account + IP (5); parent link-code guesses (20); a generous cap
  on all auth endpoints (300) and on the API overall (3000). Tune with the
  `*_RATE_LIMIT_MAX` variables in `.env.example`. **Behind a reverse proxy, set
  `TRUST_PROXY`** (usually `1`) or every client appears to share the proxy's IP.
  Limits live in process memory: with several API instances each keeps its own
  counters (use a shared store such as Redis if you scale out).
- **Security headers** via `helmet` (CSP, `nosniff`, no `X-Powered-By`,
  clickjacking protection). The admin dashboard needs inline script, so the CSP
  allows `'unsafe-inline'` — it never renders user-supplied HTML unescaped.
- **Input validation** on every route: IDs must be UUIDs (malformed ones get a
  400, not a database error), emails/lengths/ranges/dates are checked, scores
  can't exceed an assignment's maximum, request bodies are capped at 100 kB, and
  malformed JSON returns 400.
- **Uploads**: the stored file extension is derived from the validated MIME
  type, never from the client's filename, and `/uploads` is served with
  `nosniff` and a sandboxing CSP — so a file named `x.html` that claims to be a
  PNG can't be used for stored XSS.
- **Production guard rails**: with `NODE_ENV=production` the server refuses to
  start if `JWT_SECRET` is missing, short (<32 chars) or a known placeholder,
  and refuses to create the first admin with a weak `DEFAULT_ADMIN_PASSWORD`.
- **CORS** is permissive by default (the mobile apps are unaffected by it);
  set `CORS_ORIGINS` to restrict browsers to specific origins.

## API documentation

Interactive docs (Swagger UI) are served at **`/api/docs`**, and the raw
OpenAPI document at `/api/docs.json`. Click *Authorize* and paste the `token`
from `/api/auth/login` to try requests. Set `ENABLE_API_DOCS=false` to switch
them off. The spec is generated from the table at the top of
`src/docs/openapi.js` — add a line there when you add a route.

## API reference

| Method | Path | Auth | Description |
|---|---|---|---|
| POST | `/api/auth/register` | – | Create an account (`role`: `STUDENT`, `TEACHER` or `PARENT`) and join a school (`schoolCode`), or start one (`createSchool`, `schoolName` — teachers only) |
| POST | `/api/auth/login` | – | Log in, returns a JWT |
| POST | `/api/auth/forgot-password` | – | Email a password-reset link (always returns success) |
| GET/POST | `/reset-password` | – | Web page opened from the emailed link; sets the new password |
| GET | `/api/batches` | ✓ | "My batches" — teacher's own, or student's enrolled |
| GET | `/api/batches/browse` | ✓ | Every batch in your school (for students to discover) |
| POST | `/api/batches` | ✓ teacher | Create a batch |
| POST | `/api/batches/:batchId/enroll` | ✓ student | Join a batch |
| GET | `/api/batches/:batchId/students` | ✓ teacher | Roster for a batch (used for marking attendance) |
| GET | `/api/batches/:batchId/assignments` | ✓ | List assignments for a batch |
| POST | `/api/batches/:batchId/assignments` | ✓ teacher | Create an assignment |
| GET | `/api/batches/:batchId/attendance` | ✓ | Attendance records for a batch |
| POST | `/api/batches/:batchId/attendance` | ✓ teacher | Submit/update attendance for a date |
| GET | `/api/fees` | ✓ | Fee records (student's own, or for the teacher's students) |
| GET | `/api/fees/students` | ✓ teacher | Students eligible for a new fee record |
| POST | `/api/fees` | ✓ teacher | Create a fee record for a student |
| POST | `/api/fees/:feeId/mark-paid` | ✓ teacher | Mark a fee record fully paid |
| POST | `/api/batches/:batchId/assignments/:assignmentId/submit` | ✓ student | Mark your own work submitted |
| GET | `/api/batches/:batchId/assignments/:assignmentId/submissions` | ✓ teacher | Roster + scores for grading |
| POST | `/api/batches/:batchId/assignments/:assignmentId/grade` | ✓ teacher | Record a score for one student |
| POST | `/api/fees/:feeId/checkout` | ✓ student / parent | Create a Stripe Checkout session, returns `{ checkoutUrl }` (a parent can pay a linked child's fee) |
| POST | `/webhooks/stripe` | Stripe signature | Marks a fee paid when checkout completes |
| GET/POST | `/payment-result` | – | Web page shown after returning from Stripe Checkout |
| POST | `/api/devices/register` | ✓ | Register this device's FCM token for push notifications |
| POST | `/api/devices/unregister` | ✓ | Stop sending push to this device (called on logout) |
| GET | `/api/auth/me` | ✓ | Current profile, including `avatarUrl` |
| POST | `/api/uploads/profile-photo` | ✓ | Upload a profile photo (`multipart/form-data`, field `photo`, images only, 5MB max) |
| POST | `/api/batches/:batchId/assignments/:assignmentId/attachment` | ✓ teacher | Attach a file to an assignment (field `file`, 20MB max) |
| POST | `/api/batches/:batchId/assignments/:assignmentId/submission-attachment` | ✓ student | Upload your work for an assignment; also marks it submitted (field `file`, 20MB max) |
| GET | `/uploads/...` | – | Serves uploaded files (see "File uploads" below) |
| GET | `/api/analytics/overview` | ✓ teacher | Headline stats: batches, students, attendance rate, fee collection |
| GET | `/api/analytics/attendance-trend` | ✓ teacher | Daily present/absent/late counts (`?days=30&batchId=`) |
| GET | `/api/analytics/revenue-trend` | ✓ teacher | Collected vs. pending fees by month (`?months=6`) |
| GET | `/api/analytics/batch-performance` | ✓ teacher | Per-batch homework completion & attendance rates |
| GET | `/api/school` | ✓ | Your school's name and head-counts (join codes shown to the school admin only) |
| PUT | `/api/school` | ✓ school admin | Rename the school |
| POST | `/api/school/regenerate-codes` | ✓ school admin | Rotate the student/parent and/or teacher join code (`which`: `student`, `teacher`, `both`) |
| GET | `/api/school/members` | ✓ school admin | Everyone in the school |
| POST | `/api/parents/link-code` | ✓ student | Create a code (48h) for a parent to link with |
| POST | `/api/parents/link` | ✓ parent | Link to a child using their code |
| GET | `/api/parents/children` | ✓ parent | Linked children |
| DELETE | `/api/parents/children/:studentId` | ✓ parent | Unlink a child |
| GET | `/api/parents/my-parents` | ✓ student | Parents who can see my data |
| DELETE | `/api/parents/my-parents/:parentId` | ✓ student | Revoke a parent's access |
| GET | `/api/parents/children/:studentId/summary` | ✓ parent (linked) | Attendance rate, fee totals, homework progress |
| GET | `/api/parents/children/:studentId/{batches,attendance,assignments,fees}` | ✓ parent (linked) | Read-only lists for one child |
| GET | `/api/docs`, `/api/docs.json` | – | Interactive API docs / OpenAPI document |
| GET | `/admin` | – (logs in with a teacher account) | Server-rendered web dashboard |

## Admin/teacher web dashboard

`GET /admin` serves a self-contained dashboard (no build step, no separate
frontend project) covering everything a teacher can do from the mobile app —
batches, attendance, assignments/grading, fee records, and an **Analytics**
tab (attendance trend, revenue trend, and per-batch performance, rendered as
inline SVG charts — no charting library needed). It's a thin client over the
same JSON API above, so there's no separate backend surface to maintain.
Sign in with a TEACHER account; STUDENT accounts are rejected.

The Teacher Android app also has an "Insights" tab with the same headline
stats and per-batch performance bars, for a quick check without opening a
browser.

## Push notifications

Assignment creation, grading, attendance (absent/late), and successful
payments all trigger a push via Firebase Cloud Messaging. This requires a
Firebase project — see **PUSH_NOTIFICATIONS.md** at the repo root for the
full setup. Until that's done, everything still works; the backend just logs
what it would have sent instead of delivering it.

## Online fee payments

`POST /api/fees/:feeId/checkout` creates a Stripe Checkout session for the
outstanding balance and returns a URL. Since the apps don't embed the
Stripe SDK, they open this URL in the device's browser (hosted Checkout) —
simpler and lets Stripe handle all PCI compliance concerns for you. A
webhook (`/webhooks/stripe`) marks the fee record paid once the payment
completes; point a Stripe webhook endpoint at
`{APP_BASE_URL}/webhooks/stripe` listening for `checkout.session.completed`,
and set `STRIPE_SECRET_KEY` + `STRIPE_WEBHOOK_SECRET` from your Stripe
dashboard. Without `STRIPE_SECRET_KEY` set, the checkout endpoint returns a
clear "not configured" error instead of crashing.

## File uploads

Profile photos, assignment materials (teacher attachments), and student
submissions are stored on the backend's local disk under `backend/uploads/`
(`avatars/`, `assignments/`, `submissions/`), with randomly generated UUID
filenames. With the included `docker-compose.yml`, that folder is a named
Docker volume (`uploads_data`), so files survive container rebuilds.

Allowed types: images (JPEG/PNG/WebP/GIF) for profile photos; images, PDF,
Word documents, and plain text for assignment/submission files. Anything else
is rejected with a 400.

**Security tradeoff to be aware of:** uploaded files are served publicly at
`{APP_BASE_URL}/uploads/...` with no per-request authentication. The random
UUID filenames make them effectively unguessable, but anyone who has a URL
can open it. That keeps the mobile apps simple (plain image/file links, no
auth headers needed for downloads), and is reasonable for a small school.
If you need stricter control (e.g. only the enrolled students and teacher
may view a submission), replace the `express.static` mount in `index.js`
with an authenticated route that checks the caller's access before
streaming the file.

**Scaling note:** local disk storage doesn't work if you run multiple
backend instances behind a load balancer (each would only see its own
files). If you outgrow a single instance, swap `utils/uploads.js` for an
S3-compatible storage engine (`multer-s3`) — the route handlers only depend
on `publicUrlFor()` and the multer instances it exports.

## Running tests

```bash
cd backend
npm install
npm test
```

The test suite (Jest + Supertest) is fully offline — no real Postgres,
SMTP, Firebase, or Stripe connection is needed. Routes are tested against a
mocked database (`jest.mock('../../src/db', ...)`), and `test/env.setup.js`
deliberately leaves SMTP/Firebase/Stripe unconfigured so those utilities
take their documented no-op code path instead of attempting any real
network call.

Coverage: every route file (`auth`, `school`, `parents`, `batches`,
`assignments`, `attendance`, `fees`, uploads) plus the JWT/role middleware,
input validation, production-config checks, the OpenAPI spec, and
`security.test.js`, which boots the real app (`createApp()`) to check security
headers, body limits, rate limiting, API docs and the upload headers. The upload
tests really do write small files into `backend/uploads/` (it's gitignored).

Shared fixtures live in `test/ids.js` (valid UUIDs and ready-made teacher /
student / parent tokens) — route and body IDs are validated as UUIDs, so tests
need real-looking ones, not `"b1"`.

## Known limitations / natural next steps

- **The reset-password and payment-result pages are unstyled/basic** —
  plain server-rendered HTML, not branded to match your school. Feel free
  to restyle `web-pages.routes.js`'s `pageShell()`.
- **The admin dashboard is the teacher view plus a School tab** — a teacher
  sees only their own batches/students; the school admin additionally manages
  join codes and sees members. There is no school-wide analytics view yet.
- **Removing a member isn't supported** — there's no endpoint to delete a user
  or move them between schools.
- **Rate limits are per process** (in memory) — see "Security".
- **Fee amounts are entered manually per record** — there's no recurring
  invoice generation (e.g. auto-creating next month's fee for every
  enrolled student).
- **Stripe is the only payment provider wired up** — swap `utils/payments.js`
  for a different provider's SDK if you need one (Razorpay, PayPal, etc.).

## Upgrading from an older deployment

If you deployed an earlier version of this backend that used security
questions for password recovery, `schema.sql` now drops those columns
(`security_question`, `security_answer_hash`) automatically on next boot —
no manual migration needed. Existing user accounts and passwords are
unaffected. The new `device_tokens` table and `fee_records.stripe_session_id`
/ `fee_records.paid_at` columns are also created/added automatically.

### Upgrading to multi-school + parents + hardening

All schema changes are applied automatically (and are safe to re-run) on the
next boot:

- Everything that already exists is moved into a **"Default School"**, and its
  earliest teacher becomes the school admin. Find the join codes in the Teacher
  app (Account tab), at `/admin`, or `SELECT name, student_code, teacher_code FROM schools;`.
- **Everyone is asked to sign in again once** (old tokens carry no school). The
  apps do this automatically.
- The `user_role` enum gains `PARENT`.
- **Seeding changed**: the default admin is now created only on a completely
  empty database (previously it was re-created whenever its email was missing).
- **`docker-compose.yml` now sets `NODE_ENV=production`** and refuses to start
  without `JWT_SECRET` and `DEFAULT_ADMIN_PASSWORD` in `.env`. If you run without
  Docker and want the same protection, set `NODE_ENV=production` yourself.
- New env vars (all optional): `DEFAULT_SCHOOL_NAME`, `TRUST_PROXY`,
  `CORS_ORIGINS`, `ENABLE_API_DOCS` and the `*_RATE_LIMIT_MAX` limits — see
  `.env.example`.
- Files uploaded before this version may have the extension the client chose;
  new uploads always get one derived from the file type. `/uploads` now carries
  `nosniff` + a sandboxing CSP.
- Validation is stricter: IDs must be UUIDs, fee/attendance dates must be
  `YYYY-MM-DD`, and scores can't exceed the assignment maximum.
