require('dotenv').config();

const { assertSecureConfig } = require('./config');
const { migrate } = require('./migrate');
const { seed } = require('./seed');
const { createApp } = require('./app');

const port = process.env.PORT || 4000;

async function start() {
  // Throws in production if secrets are placeholders; just warns elsewhere.
  const warnings = assertSecureConfig();
  warnings.forEach((w) => console.warn(`[config warning] ${w}`));

  await migrate();
  await seed();

  createApp().listen(port, () => {
    console.log(`Tuition Platform API listening on port ${port}`);
  });
}

start().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
