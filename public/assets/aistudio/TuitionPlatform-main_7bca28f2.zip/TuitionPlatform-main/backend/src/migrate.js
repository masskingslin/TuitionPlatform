const fs = require('fs');
const path = require('path');
const { pool } = require('./db');

async function migrate() {
  const sql = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
  await pool.query(sql);

  // Databases created before parent accounts existed have a user_role enum
  // without PARENT. ALTER TYPE ... ADD VALUE is restricted inside a
  // multi-statement transaction, so it runs as its own statement (a no-op
  // when the value is already there, e.g. on a fresh database).
  await pool.query("ALTER TYPE user_role ADD VALUE IF NOT EXISTS 'PARENT'");
}

module.exports = { migrate };

if (require.main === module) {
  migrate()
    .then(() => {
      console.log('Schema applied.');
      process.exit(0);
    })
    .catch((err) => {
      console.error('Migration failed:', err);
      process.exit(1);
    });
}
