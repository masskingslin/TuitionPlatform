CREATE EXTENSION IF NOT EXISTS pgcrypto;

DO $$ BEGIN
  CREATE TYPE user_role AS ENUM ('STUDENT', 'TEACHER', 'ADMIN', 'PARENT');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE attendance_status AS ENUM ('PRESENT', 'ABSENT', 'LATE', 'EXCUSED');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE fee_status AS ENUM ('PAID', 'PENDING', 'OVERDUE');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS schools (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  -- Join codes. Students and parents join with student_code, teachers with
  -- teacher_code. Prefixed S / T so a wrong-kind code can be explained.
  student_code TEXT NOT NULL UNIQUE,
  teacher_code TEXT NOT NULL UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role user_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS password_reset_tokens (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  expires_at TIMESTAMPTZ NOT NULL,
  used_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS device_tokens (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  fcm_token TEXT NOT NULL UNIQUE,
  platform TEXT NOT NULL DEFAULT 'android',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS batches (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  subject TEXT NOT NULL,
  teacher_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  schedule_time TEXT NOT NULL,
  room_or_meeting_link TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS enrollments (
  batch_id UUID NOT NULL REFERENCES batches(id) ON DELETE CASCADE,
  student_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (batch_id, student_id)
);

CREATE TABLE IF NOT EXISTS assignments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  batch_id UUID NOT NULL REFERENCES batches(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  due_date TEXT NOT NULL,
  max_score INT NOT NULL DEFAULT 100,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS assignment_submissions (
  assignment_id UUID NOT NULL REFERENCES assignments(id) ON DELETE CASCADE,
  student_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  is_submitted BOOLEAN NOT NULL DEFAULT false,
  score_earned INT,
  PRIMARY KEY (assignment_id, student_id)
);

CREATE TABLE IF NOT EXISTS attendance_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  batch_id UUID NOT NULL REFERENCES batches(id) ON DELETE CASCADE,
  student_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  date DATE NOT NULL,
  status attendance_status NOT NULL,
  notes TEXT NOT NULL DEFAULT '',
  UNIQUE (batch_id, student_id, date)
);

CREATE TABLE IF NOT EXISTS fee_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  month_year TEXT NOT NULL,
  amount_due NUMERIC(10, 2) NOT NULL,
  amount_paid NUMERIC(10, 2) NOT NULL DEFAULT 0,
  status fee_status NOT NULL DEFAULT 'PENDING',
  due_date DATE NOT NULL
);

-- ---------------------------------------------------------------------
-- Column additions for later features. These all use ADD/DROP COLUMN IF
-- (NOT) EXISTS, and are placed after every CREATE TABLE above so this
-- file is safe to re-run against an existing database in any order.
-- ---------------------------------------------------------------------

-- Upgrading from an older deployment that used security questions for
-- password recovery: those columns are no longer written to or read from.
ALTER TABLE users DROP COLUMN IF EXISTS security_question;
ALTER TABLE users DROP COLUMN IF EXISTS security_answer_hash;

ALTER TABLE users ADD COLUMN IF NOT EXISTS avatar_url TEXT;

ALTER TABLE fee_records ADD COLUMN IF NOT EXISTS stripe_session_id TEXT;
ALTER TABLE fee_records ADD COLUMN IF NOT EXISTS paid_at TIMESTAMPTZ;

ALTER TABLE assignments ADD COLUMN IF NOT EXISTS attachment_url TEXT;
ALTER TABLE assignments ADD COLUMN IF NOT EXISTS attachment_name TEXT;

ALTER TABLE assignment_submissions ADD COLUMN IF NOT EXISTS attachment_url TEXT;
ALTER TABLE assignment_submissions ADD COLUMN IF NOT EXISTS attachment_name TEXT;


-- ---------------------------------------------------------------------
-- Multi-school support
-- ---------------------------------------------------------------------
ALTER TABLE users ADD COLUMN IF NOT EXISTS school_id UUID REFERENCES schools(id) ON DELETE CASCADE;
ALTER TABLE users ADD COLUMN IF NOT EXISTS is_school_admin BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE batches ADD COLUMN IF NOT EXISTS school_id UUID REFERENCES schools(id) ON DELETE CASCADE;

-- Upgrading a deployment that predates multi-school support: everything that
-- exists moves into one "Default School", and its earliest teacher becomes
-- the school admin. All of this is a no-op once data has been migrated.
INSERT INTO schools (name, student_code, teacher_code)
SELECT 'Default School',
       'S' || upper(substr(md5(random()::text), 1, 7)),
       'T' || upper(substr(md5(random()::text || 'teacher'), 1, 7))
WHERE NOT EXISTS (SELECT 1 FROM schools)
  AND EXISTS (SELECT 1 FROM users WHERE school_id IS NULL);

UPDATE users
SET school_id = (SELECT id FROM schools ORDER BY created_at LIMIT 1)
WHERE school_id IS NULL AND EXISTS (SELECT 1 FROM schools);

UPDATE batches b
SET school_id = u.school_id
FROM users u
WHERE b.teacher_id = u.id AND b.school_id IS NULL;

UPDATE users u
SET is_school_admin = true
WHERE u.role = 'TEACHER'
  AND u.id IN (
    SELECT DISTINCT ON (school_id) id FROM users
    WHERE role = 'TEACHER' AND school_id IS NOT NULL
    ORDER BY school_id, created_at
  )
  AND NOT EXISTS (SELECT 1 FROM users x WHERE x.school_id = u.school_id AND x.is_school_admin);

-- ---------------------------------------------------------------------
-- Parent accounts
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS parent_students (
  parent_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  student_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (parent_id, student_id)
);

-- Short-lived codes a student generates in their app and hands to a parent.
CREATE TABLE IF NOT EXISTS parent_link_codes (
  code TEXT PRIMARY KEY,
  student_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_batches_teacher ON batches(teacher_id);
CREATE INDEX IF NOT EXISTS idx_assignments_batch ON assignments(batch_id);
CREATE INDEX IF NOT EXISTS idx_attendance_batch ON attendance_records(batch_id);
CREATE INDEX IF NOT EXISTS idx_fees_student ON fee_records(student_id);
CREATE INDEX IF NOT EXISTS idx_reset_tokens_user ON password_reset_tokens(user_id);
CREATE INDEX IF NOT EXISTS idx_device_tokens_user ON device_tokens(user_id);
CREATE INDEX IF NOT EXISTS idx_users_school ON users(school_id);
CREATE INDEX IF NOT EXISTS idx_batches_school ON batches(school_id);
CREATE INDEX IF NOT EXISTS idx_parent_students_student ON parent_students(student_id);
CREATE INDEX IF NOT EXISTS idx_parent_link_codes_student ON parent_link_codes(student_id);
