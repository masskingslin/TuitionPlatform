const WEAK_JWT_SECRETS = [
  'change-this-to-a-long-random-string',
  'secret',
  'changeme',
  'test-secret-do-not-use-in-production'
];
const WEAK_ADMIN_PASSWORDS = ['admin123', 'change-me-now', 'password', 'admin'];

/**
 * Checks secrets at startup. In production an unsafe JWT secret is fatal
 * (anyone could forge tokens); elsewhere it is only a warning, so local
 * development stays easy. Returns a list of warnings.
 */
function assertSecureConfig(env = process.env) {
  const problems = [];
  const secret = env.JWT_SECRET || '';

  if (!secret) problems.push('JWT_SECRET is not set.');
  else if (secret.length < 32) problems.push('JWT_SECRET should be at least 32 characters (try: openssl rand -hex 32).');
  else if (WEAK_JWT_SECRETS.includes(secret)) problems.push('JWT_SECRET is still a placeholder value.');

  if (env.NODE_ENV === 'production') {
    if (problems.length > 0) {
      throw new Error(`Unsafe production configuration:\n - ${problems.join('\n - ')}`);
    }
    if (env.APP_BASE_URL && env.APP_BASE_URL.startsWith('http://') && !env.APP_BASE_URL.includes('localhost')) {
      return ['APP_BASE_URL uses plain http:// — put the API behind HTTPS (e.g. a reverse proxy) for real deployments.'];
    }
    return [];
  }
  return problems;
}

/**
 * Called only when the default admin is about to be created (first boot on an
 * empty database): in production, refuse a guessable password.
 */
function assertSafeAdminPassword(password, env = process.env) {
  if (env.NODE_ENV === 'production' && (!password || WEAK_ADMIN_PASSWORDS.includes(password) || password.length < 8)) {
    throw new Error('DEFAULT_ADMIN_PASSWORD must be a strong, non-default value (8+ characters) before the first production boot.');
  }
}

module.exports = { assertSecureConfig, assertSafeAdminPassword, WEAK_ADMIN_PASSWORDS };
