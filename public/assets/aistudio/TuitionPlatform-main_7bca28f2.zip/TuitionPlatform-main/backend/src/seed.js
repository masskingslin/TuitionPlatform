require('dotenv').config();
const bcrypt = require('bcryptjs');
const { pool } = require('./db');
const { newStudentCode, newTeacherCode } = require('./utils/codes');
const { assertSafeAdminPassword } = require('./config');

/**
 * First-boot bootstrap: on a completely empty database, creates one school
 * and a teacher account that administers it, so there is always a way in.
 * It deliberately does nothing once any user exists — otherwise deleting the
 * default admin would make every restart quietly recreate it.
 */
async function seed() {
  const existing = await pool.query('SELECT 1 FROM users LIMIT 1');
  if (existing.rows.length > 0) return;

  const adminName = process.env.DEFAULT_ADMIN_NAME || 'Admin Teacher';
  const email = (process.env.DEFAULT_ADMIN_EMAIL || 'admin@example.com').toLowerCase();
  const password = process.env.DEFAULT_ADMIN_PASSWORD || 'admin123';
  const schoolName = process.env.DEFAULT_SCHOOL_NAME || 'My School';
  assertSafeAdminPassword(password);

  const studentCode = newStudentCode();
  const teacherCode = newTeacherCode();
  const school = await pool.query(
    'INSERT INTO schools (name, student_code, teacher_code) VALUES ($1, $2, $3) RETURNING id',
    [schoolName, studentCode, teacherCode]
  );

  const passwordHash = await bcrypt.hash(password, 10);
  await pool.query(
    `INSERT INTO users (full_name, email, password_hash, role, school_id, is_school_admin)
     VALUES ($1, $2, $3, 'TEACHER', $4, true)`,
    [adminName, email, passwordHash, school.rows[0].id]
  );

  console.log(`Created school "${schoolName}" and admin teacher ${email}`);
  console.log(`  Student/parent join code: ${studentCode}`);
  console.log(`  Teacher join code:        ${teacherCode}`);
}

module.exports = { seed };

if (require.main === module) {
  seed()
    .then(() => process.exit(0))
    .catch((err) => {
      console.error('Seeding failed:', err);
      process.exit(1);
    });
}
