const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

function isUuid(value) {
  return typeof value === 'string' && UUID_RE.test(value);
}

function isEmail(value) {
  return typeof value === 'string' && value.length <= 254 && EMAIL_RE.test(value);
}

/** True for a non-empty string no longer than `max` characters. */
function isText(value, max) {
  return typeof value === 'string' && value.trim().length > 0 && value.length <= max;
}

/** For router.param(): rejects malformed IDs with 400 instead of letting Postgres throw a 500. */
function uuidParam(name) {
  return (req, res, next, value) => {
    if (!isUuid(value)) {
      return res.status(400).json({ error: `Invalid ${name}` });
    }
    next();
  };
}

module.exports = { isUuid, isEmail, isText, uuidParam };
