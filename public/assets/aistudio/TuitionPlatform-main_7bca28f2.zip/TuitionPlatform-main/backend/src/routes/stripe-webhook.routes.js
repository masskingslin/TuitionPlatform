const express = require('express');
const { pool } = require('../db');
const { getStripeClient } = require('../utils/payments');
const { sendPushToStudentsAndParents, notifyInBackground } = require('../utils/push');

const router = express.Router();

// POST /webhooks/stripe -> Stripe calls this when a checkout session completes.
// Mounted with express.raw() in index.js (must run BEFORE express.json()) so
// the raw body is available for signature verification.
router.post('/', async (req, res) => {
  const stripe = getStripeClient();
  if (!stripe) {
    return res.status(503).send('Payments not configured');
  }

  const signature = req.headers['stripe-signature'];
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, signature, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('Stripe webhook signature verification failed:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const feeId = session.metadata?.feeId;
    const studentId = session.metadata?.studentId;

    if (feeId) {
      try {
        const result = await pool.query(
          `UPDATE fee_records
           SET amount_paid = amount_due, status = 'PAID', paid_at = now()
           WHERE id = $1 AND stripe_session_id = $2
           RETURNING month_year`,
          [feeId, session.id]
        );
        if (result.rows.length > 0 && studentId) {
          const monthYear = result.rows[0].month_year;
          notifyInBackground(() => sendPushToStudentsAndParents(
            [studentId], 'Payment received', `Payment for ${monthYear} was received. Thank you!`,
            { type: 'FEE_PAID', feeId }
          ));
        }
      } catch (err) {
        console.error('Failed to mark fee record paid from webhook:', err.message);
      }
    }
  }

  res.json({ received: true });
});

module.exports = router;
