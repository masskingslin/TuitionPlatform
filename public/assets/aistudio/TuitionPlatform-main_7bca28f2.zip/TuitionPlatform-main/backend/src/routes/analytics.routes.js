const express = require('express');
const { pool } = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');
const { isUuid } = require('../middleware/validate');

const router = express.Router();
router.use(requireAuth);
router.use(requireRole('TEACHER'));

// GET /api/analytics/overview -> headline stats for the signed-in teacher
router.get('/overview', async (req, res, next) => {
  try {
    const teacherId = req.user.id;

    const [batches, students, assignments, attendance, fees] = await Promise.all([
      pool.query('SELECT COUNT(*)::int AS count FROM batches WHERE teacher_id = $1', [teacherId]),
      pool.query(
        `SELECT COUNT(DISTINCT e.student_id)::int AS count
         FROM enrollments e JOIN batches b ON b.id = e.batch_id
         WHERE b.teacher_id = $1`,
        [teacherId]
      ),
      pool.query(
        `SELECT COUNT(*)::int AS count
         FROM assignments a JOIN batches b ON b.id = a.batch_id
         WHERE b.teacher_id = $1`,
        [teacherId]
      ),
      pool.query(
        `SELECT ar.status, COUNT(*)::int AS count
         FROM attendance_records ar JOIN batches b ON b.id = ar.batch_id
         WHERE b.teacher_id = $1 AND ar.date >= (CURRENT_DATE - INTERVAL '30 days')
         GROUP BY ar.status`,
        [teacherId]
      ),
      pool.query(
        `SELECT f.status,
                COALESCE(SUM(f.amount_due), 0)::float AS amount_due,
                COALESCE(SUM(f.amount_paid), 0)::float AS amount_paid,
                COUNT(*)::int AS count
         FROM fee_records f
         WHERE f.student_id IN (
           SELECT DISTINCT e.student_id FROM enrollments e JOIN batches b ON b.id = e.batch_id WHERE b.teacher_id = $1
         )
         GROUP BY f.status`,
        [teacherId]
      )
    ]);

    const attendanceByStatus = { PRESENT: 0, ABSENT: 0, LATE: 0, EXCUSED: 0 };
    attendance.rows.forEach((row) => { attendanceByStatus[row.status] = row.count; });
    const totalMarked = Object.values(attendanceByStatus).reduce((sum, n) => sum + n, 0);

    let totalDue = 0;
    let totalCollected = 0;
    const feesByStatus = { PAID: 0, PENDING: 0, OVERDUE: 0 };
    fees.rows.forEach((row) => {
      totalDue += row.amount_due;
      totalCollected += row.amount_paid;
      feesByStatus[row.status] = row.count;
    });

    res.json({
      totalBatches: batches.rows[0].count,
      totalStudents: students.rows[0].count,
      totalAssignments: assignments.rows[0].count,
      attendance: {
        presentCount: attendanceByStatus.PRESENT,
        absentCount: attendanceByStatus.ABSENT,
        lateCount: attendanceByStatus.LATE,
        excusedCount: attendanceByStatus.EXCUSED,
        presentRate: totalMarked > 0 ? attendanceByStatus.PRESENT / totalMarked : null
      },
      fees: {
        totalDue,
        totalCollected,
        totalPending: totalDue - totalCollected,
        paidInvoices: feesByStatus.PAID,
        pendingInvoices: feesByStatus.PENDING,
        overdueInvoices: feesByStatus.OVERDUE
      }
    });
  } catch (err) {
    next(err);
  }
});

// GET /api/analytics/attendance-trend?days=30&batchId=optional
router.get('/attendance-trend', async (req, res, next) => {
  try {
    const teacherId = req.user.id;
    const days = Math.min(Math.max(parseInt(req.query.days, 10) || 30, 1), 180);
    const batchId = req.query.batchId || null;
    if (batchId !== null && !isUuid(batchId)) {
      return res.status(400).json({ error: 'Invalid batchId' });
    }

    const result = await pool.query(
      `SELECT ar.date::text AS date,
              COUNT(*) FILTER (WHERE ar.status = 'PRESENT')::int AS present,
              COUNT(*) FILTER (WHERE ar.status = 'ABSENT')::int AS absent,
              COUNT(*) FILTER (WHERE ar.status = 'LATE')::int AS late
       FROM attendance_records ar
       JOIN batches b ON b.id = ar.batch_id
       WHERE b.teacher_id = $1
         AND ar.date >= (CURRENT_DATE - ($2::int) * INTERVAL '1 day')
         AND ($3::uuid IS NULL OR ar.batch_id = $3)
       GROUP BY ar.date
       ORDER BY ar.date ASC`,
      [teacherId, days, batchId]
    );

    res.json(result.rows);
  } catch (err) {
    next(err);
  }
});

// GET /api/analytics/revenue-trend?months=6
router.get('/revenue-trend', async (req, res, next) => {
  try {
    const teacherId = req.user.id;
    const months = Math.min(Math.max(parseInt(req.query.months, 10) || 6, 1), 24);

    const result = await pool.query(
      `SELECT f.month_year,
              COALESCE(SUM(f.amount_paid), 0)::float AS collected,
              COALESCE(SUM(f.amount_due - f.amount_paid), 0)::float AS pending,
              MIN(f.due_date) AS sort_key
       FROM fee_records f
       WHERE f.student_id IN (
         SELECT DISTINCT e.student_id FROM enrollments e JOIN batches b ON b.id = e.batch_id WHERE b.teacher_id = $1
       )
       GROUP BY f.month_year
       ORDER BY sort_key ASC`,
      [teacherId]
    );

    const rows = result.rows.map((r) => ({ monthYear: r.month_year, collected: r.collected, pending: r.pending }));
    res.json(rows.slice(-months));
  } catch (err) {
    next(err);
  }
});

// GET /api/analytics/batch-performance -> per-batch submission and attendance rates
router.get('/batch-performance', async (req, res, next) => {
  try {
    const teacherId = req.user.id;

    const result = await pool.query(
      `SELECT b.id, b.title,
              (SELECT COUNT(*) FROM enrollments e WHERE e.batch_id = b.id)::int AS student_count,
              (SELECT COUNT(*) FROM assignments a WHERE a.batch_id = b.id)::int AS assignment_count,
              (SELECT COUNT(*) FROM assignment_submissions s
                 JOIN assignments a ON a.id = s.assignment_id
                 WHERE a.batch_id = b.id AND s.is_submitted)::int AS submitted_count,
              (SELECT COUNT(*) FROM attendance_records ar WHERE ar.batch_id = b.id AND ar.status = 'PRESENT')::int AS present_count,
              (SELECT COUNT(*) FROM attendance_records ar WHERE ar.batch_id = b.id)::int AS total_attendance_marks
       FROM batches b
       WHERE b.teacher_id = $1
       ORDER BY b.title`,
      [teacherId]
    );

    const rows = result.rows.map((row) => {
      const possibleSubmissions = row.student_count * row.assignment_count;
      return {
        batchId: row.id,
        title: row.title,
        studentCount: row.student_count,
        assignmentCount: row.assignment_count,
        submissionRate: possibleSubmissions > 0 ? row.submitted_count / possibleSubmissions : null,
        attendanceRate: row.total_attendance_marks > 0 ? row.present_count / row.total_attendance_marks : null
      };
    });

    res.json(rows);
  } catch (err) {
    next(err);
  }
});

module.exports = router;
