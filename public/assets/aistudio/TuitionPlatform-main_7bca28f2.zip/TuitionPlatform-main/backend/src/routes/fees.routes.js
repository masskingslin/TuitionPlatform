const express = require('express');
const { pool } = require('../db');
const { requireAuth } = require('../middleware/auth');
const { getStripeClient } = require('../utils/payments');
const { isText, isUuid, uuidParam } = require('../middleware/validate');

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
function isRealDate(value) {
  if (typeof value !== 'string' || !DATE_RE.test(value)) return false;
  const d = new Date(`${value}T00:00:00Z`);
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === value;
}

const router = express.Router();
router.use(requireAuth);
router.param('feeId', uuidParam('feeId'));

function toFeeRecord(row) {
  return {
    invoiceId: row.invoice_id,
    studentId: row.student_id,
    studentName: row.student_name,
    monthYear: row.month_year,
    amountDue: Number(row.amount_due),
    amountPaid: Number(row.amount_paid),
    status: row.status,
    dueDate: row.due_date instanceof Date ? row.due_date.toISOString().slice(0, 10) : row.due_date
  };
}

// GET /api/fees -> student: their own fee records; teacher: fees for students enrolled in their batches
router.get('/', async (req, res, next) => {
  try {
    let result;
    if (req.user.role === 'STUDENT') {
      result = await pool.query(
        `SELECT f.id AS invoice_id, f.student_id, u.full_name AS student_name, f.month_year,
                f.amount_due, f.amount_paid, f.status, f.due_date
         FROM fee_records f
         JOIN users u ON u.id = f.student_id
         WHERE f.student_id = $1
         ORDER BY f.due_date DESC`,
        [req.user.id]
      );
    } else if (req.user.role === 'TEACHER') {
      result = await pool.query(
        `SELECT DISTINCT f.id AS invoice_id, f.student_id, u.full_name AS student_name, f.month_year,
                f.amount_due, f.amount_paid, f.status, f.due_date
         FROM fee_records f
         JOIN users u ON u.id = f.student_id
         JOIN enrollments e ON e.student_id = f.student_id
         JOIN batches b ON b.id = e.batch_id
         WHERE b.teacher_id = $1
         ORDER BY f.due_date DESC`,
        [req.user.id]
      );
    } else {
      return res.status(403).json({ error: 'Parents can view fees per child under /api/parents/children/:studentId/fees' });
    }

    res.json(result.rows.map(toFeeRecord));
  } catch (err) {
    next(err);
  }
});

// GET /api/fees/students -> teacher only: students enrolled in any of the teacher's batches (for the "new fee" form)
router.get('/students', async (req, res, next) => {
  try {
    if (req.user.role !== 'TEACHER') {
      return res.status(403).json({ error: 'Not permitted for this role' });
    }
    const result = await pool.query(
      `SELECT DISTINCT u.id, u.full_name
       FROM enrollments e
       JOIN batches b ON b.id = e.batch_id
       JOIN users u ON u.id = e.student_id
       WHERE b.teacher_id = $1
       ORDER BY u.full_name`,
      [req.user.id]
    );
    res.json(result.rows.map((row) => ({ id: row.id, fullName: row.full_name })));
  } catch (err) {
    next(err);
  }
});

// POST /api/fees -> teacher creates a fee record for one of their students
router.post('/', async (req, res, next) => {
  try {
    if (req.user.role !== 'TEACHER') {
      return res.status(403).json({ error: 'Not permitted for this role' });
    }

    const { studentId, monthYear, amountDue, dueDate } = req.body || {};
    if (!isUuid(studentId) || !isText(monthYear, 40) || !isRealDate(dueDate)) {
      return res.status(400).json({ error: 'A valid studentId, monthYear, and dueDate (YYYY-MM-DD) are required' });
    }
    if (typeof amountDue !== 'number' || !Number.isFinite(amountDue) || amountDue <= 0 || amountDue > 10000000) {
      return res.status(400).json({ error: 'amountDue must be a positive number (max 10,000,000)' });
    }

    const owns = await pool.query(
      `SELECT 1 FROM enrollments e
       JOIN batches b ON b.id = e.batch_id
       WHERE e.student_id = $1 AND b.teacher_id = $2
       LIMIT 1`,
      [studentId, req.user.id]
    );
    if (owns.rows.length === 0) {
      return res.status(403).json({ error: 'That student is not enrolled in any of your batches' });
    }

    const result = await pool.query(
      `INSERT INTO fee_records (student_id, month_year, amount_due, due_date)
       VALUES ($1, $2, $3, $4)
       RETURNING id AS invoice_id, student_id, month_year, amount_due, amount_paid, status, due_date`,
      [studentId, monthYear.trim(), amountDue, dueDate]
    );

    const studentRow = await pool.query('SELECT full_name FROM users WHERE id = $1', [studentId]);
    res.status(201).json(toFeeRecord({
      ...result.rows[0],
      student_name: studentRow.rows[0]?.full_name || ''
    }));
  } catch (err) {
    next(err);
  }
});

// POST /api/fees/:feeId/mark-paid -> teacher marks a fee record fully paid
router.post('/:feeId/mark-paid', async (req, res, next) => {
  try {
    if (req.user.role !== 'TEACHER') {
      return res.status(403).json({ error: 'Not permitted for this role' });
    }

    const { feeId } = req.params;
    const owns = await pool.query(
      `SELECT f.id FROM fee_records f
       JOIN enrollments e ON e.student_id = f.student_id
       JOIN batches b ON b.id = e.batch_id
       WHERE f.id = $1 AND b.teacher_id = $2
       LIMIT 1`,
      [feeId, req.user.id]
    );
    if (owns.rows.length === 0) {
      return res.status(404).json({ error: 'Fee record not found' });
    }

    const result = await pool.query(
      `UPDATE fee_records
       SET amount_paid = amount_due, status = 'PAID'
       WHERE id = $1
       RETURNING id AS invoice_id, student_id, month_year, amount_due, amount_paid, status, due_date`,
      [feeId]
    );

    const studentRow = await pool.query('SELECT full_name FROM users WHERE id = $1', [result.rows[0].student_id]);
    res.json(toFeeRecord({
      ...result.rows[0],
      student_name: studentRow.rows[0]?.full_name || ''
    }));
  } catch (err) {
    next(err);
  }
});

// POST /api/fees/:feeId/checkout -> student starts an online payment for a fee record
router.post('/:feeId/checkout', async (req, res, next) => {
  try {
    if (req.user.role !== 'STUDENT' && req.user.role !== 'PARENT') {
      return res.status(403).json({ error: 'Not permitted for this role' });
    }

    const stripe = getStripeClient();
    if (!stripe) {
      return res.status(503).json({ error: 'Online payments are not configured on this server yet' });
    }

    const { feeId } = req.params;
    const result = await pool.query(
      `SELECT f.id, f.student_id, f.month_year, f.amount_due, f.amount_paid, f.status
       FROM fee_records f
       WHERE f.id = $1
         AND (f.student_id = $2
              OR EXISTS (SELECT 1 FROM parent_students ps WHERE ps.parent_id = $2 AND ps.student_id = f.student_id))`,
      [feeId, req.user.id]
    );
    const fee = result.rows[0];
    if (!fee) {
      return res.status(404).json({ error: 'Fee record not found' });
    }
    if (fee.status === 'PAID') {
      return res.status(400).json({ error: 'This fee is already paid' });
    }

    const amountOwed = Number(fee.amount_due) - Number(fee.amount_paid);
    const appBaseUrl = process.env.APP_BASE_URL || `http://localhost:${process.env.PORT || 4000}`;

    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      payment_method_types: ['card'],
      line_items: [{
        price_data: {
          currency: process.env.STRIPE_CURRENCY || 'inr',
          unit_amount: Math.round(amountOwed * 100),
          product_data: { name: `Tuition fee — ${fee.month_year}` }
        },
        quantity: 1
      }],
      metadata: { feeId: fee.id, studentId: fee.student_id, payerId: req.user.id },
      success_url: `${appBaseUrl}/payment-result?status=success`,
      cancel_url: `${appBaseUrl}/payment-result?status=cancelled`
    });

    await pool.query('UPDATE fee_records SET stripe_session_id = $1 WHERE id = $2', [session.id, fee.id]);
    res.json({ checkoutUrl: session.url });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
