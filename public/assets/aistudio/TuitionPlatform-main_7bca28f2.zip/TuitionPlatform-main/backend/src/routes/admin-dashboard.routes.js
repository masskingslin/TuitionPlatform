const express = require('express');

const router = express.Router();

// GET /admin -> single-page dashboard (login + batches/attendance/assignments/fees management)
router.get('/', (req, res) => {
  res.send(`<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Tuition Platform — Dashboard</title>
<style>
  :root { --primary: #00695c; --bg: #f4f6f8; --card: #fff; --border: #e0e0e0; --danger: #c62828; --muted: #666; }
  * { box-sizing: border-box; }
  body { font-family: -apple-system, Segoe UI, Roboto, sans-serif; background: var(--bg); margin: 0; color: #222; }
  header { background: var(--primary); color: #fff; padding: 14px 20px; display: flex; justify-content: space-between; align-items: center; }
  header h1 { font-size: 18px; margin: 0; }
  header button { background: rgba(255,255,255,0.15); color: #fff; border: none; padding: 8px 14px; border-radius: 6px; cursor: pointer; }
  nav { display: flex; gap: 6px; padding: 12px 20px; background: #fff; border-bottom: 1px solid var(--border); flex-wrap: wrap; }
  nav button { background: none; border: 1px solid var(--border); padding: 8px 14px; border-radius: 20px; cursor: pointer; font-size: 13px; }
  nav button.active { background: var(--primary); color: #fff; border-color: var(--primary); }
  main { max-width: 900px; margin: 20px auto; padding: 0 16px; }
  .card { background: var(--card); border-radius: 10px; padding: 18px; margin-bottom: 14px; box-shadow: 0 1px 3px rgba(0,0,0,0.06); }
  .card h2 { font-size: 16px; margin: 0 0 12px; }
  label { display: block; font-size: 12px; font-weight: 600; color: var(--muted); margin: 10px 0 4px; }
  input, select, textarea { width: 100%; padding: 9px 10px; border: 1px solid #ccc; border-radius: 6px; font-size: 14px; font-family: inherit; }
  button.primary { background: var(--primary); color: #fff; border: none; padding: 10px 16px; border-radius: 6px; cursor: pointer; font-size: 14px; margin-top: 12px; }
  button.secondary { background: #eee; border: none; padding: 9px 14px; border-radius: 6px; cursor: pointer; font-size: 13px; margin-top: 12px; margin-left: 8px; }
  table { width: 100%; border-collapse: collapse; margin-top: 10px; }
  th, td { text-align: left; padding: 8px 6px; border-bottom: 1px solid var(--border); font-size: 13px; }
  th { color: var(--muted); font-weight: 600; }
  .error { color: var(--danger); font-size: 13px; margin-top: 8px; }
  .muted { color: var(--muted); font-size: 13px; }
  .status-PAID, .status-PRESENT { color: #2e7d32; font-weight: 600; }
  .status-PENDING, .status-LATE { color: #ef6c00; font-weight: 600; }
  .status-OVERDUE, .status-ABSENT { color: var(--danger); font-weight: 600; }
  #loginView { max-width: 380px; margin: 60px auto; }
  .hidden { display: none; }
  .row { display: flex; gap: 8px; align-items: flex-end; flex-wrap: wrap; }
  .row > div { flex: 1; min-width: 140px; }
</style>
</head>
<body>

<div id="loginView">
  <div class="card">
    <h2>Sign in</h2>
    <label>Server address</label>
    <input id="serverUrl" placeholder="https://api.yourschool.com" />
    <label>Email</label>
    <input id="loginEmail" type="email" />
    <label>Password</label>
    <input id="loginPassword" type="password" />
    <button class="primary" onclick="login()">Sign In</button>
    <div id="loginError" class="error hidden"></div>
    <p class="muted">Sign in with a TEACHER account. Student accounts can't access this dashboard.</p>
  </div>
</div>

<div id="appView" class="hidden">
  <header>
    <h1 id="headerTitle">Tuition Platform Dashboard</h1>
    <button onclick="logout()">Log Out</button>
  </header>
  <nav>
    <button data-tab="batches" onclick="showTab('batches')">Batches</button>
    <button data-tab="attendance" onclick="showTab('attendance')">Attendance</button>
    <button data-tab="assignments" onclick="showTab('assignments')">Assignments</button>
    <button data-tab="fees" onclick="showTab('fees')">Fees</button>
    <button data-tab="analytics" onclick="showTab('analytics')">Analytics</button>
    <button data-tab="school" id="schoolNavBtn" class="hidden" onclick="showTab('school')">School</button>
  </nav>
  <main>
    <div id="tab-batches" class="tab"></div>
    <div id="tab-attendance" class="tab hidden"></div>
    <div id="tab-assignments" class="tab hidden"></div>
    <div id="tab-fees" class="tab hidden"></div>
    <div id="tab-analytics" class="tab hidden"></div>
    <div id="tab-school" class="tab hidden"></div>
  </main>
</div>

<script>
let state = { baseUrl: '', token: '', batches: [], selectedBatchId: null, isSchoolAdmin: false };

function api(path, options) {
  options = options || {};
  const headers = Object.assign({ 'Content-Type': 'application/json' }, options.headers || {});
  if (state.token) headers['Authorization'] = 'Bearer ' + state.token;
  var url = state.baseUrl.charAt(state.baseUrl.length - 1) === '/' ? state.baseUrl.slice(0, -1) : state.baseUrl;
  return fetch(url + path, Object.assign({}, options, { headers }))
    .then(async (r) => {
      const data = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(data.error || ('Request failed (' + r.status + ')'));
      return data;
    });
}

function saveSession() {
  localStorage.setItem('tp_baseUrl', state.baseUrl);
  localStorage.setItem('tp_token', state.token);
}

function login() {
  const errEl = document.getElementById('loginError');
  errEl.classList.add('hidden');
  state.baseUrl = document.getElementById('serverUrl').value.trim();
  const email = document.getElementById('loginEmail').value.trim();
  const password = document.getElementById('loginPassword').value;
  if (!state.baseUrl || !email || !password) {
    errEl.textContent = 'Fill in all fields.';
    errEl.classList.remove('hidden');
    return;
  }
  api('/api/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) })
    .then((res) => {
      if (res.role !== 'TEACHER') throw new Error('This dashboard is for teacher accounts only.');
      state.token = res.token;
      saveSession();
      document.getElementById('headerTitle').textContent = res.fullName + "'s Dashboard";
      enterApp();
    })
    .catch((e) => {
      errEl.textContent = e.message;
      errEl.classList.remove('hidden');
    });
}

function logout() {
  localStorage.removeItem('tp_baseUrl');
  localStorage.removeItem('tp_token');
  state = { baseUrl: '', token: '', batches: [], selectedBatchId: null, isSchoolAdmin: false };
  document.getElementById('appView').classList.add('hidden');
  document.getElementById('loginView').classList.remove('hidden');
}

function enterApp() {
  document.getElementById('loginView').classList.add('hidden');
  document.getElementById('appView').classList.remove('hidden');
  api('/api/auth/me')
    .then((me) => {
      if (me.role !== 'TEACHER') throw new Error('This dashboard is for teacher accounts only.');
      state.isSchoolAdmin = me.isSchoolAdmin;
      document.getElementById('headerTitle').textContent = (me.schoolName ? me.schoolName + ' - ' : '') + me.fullName;
      document.getElementById('schoolNavBtn').classList.toggle('hidden', !me.isSchoolAdmin);
      return loadBatches();
    })
    .then(() => showTab('batches'))
    .catch(() => logout());
}

function showTab(name) {
  document.querySelectorAll('.tab').forEach((el) => el.classList.add('hidden'));
  document.getElementById('tab-' + name).classList.remove('hidden');
  document.querySelectorAll('nav button').forEach((b) => b.classList.toggle('active', b.dataset.tab === name));
  if (name === 'batches') renderBatches();
  if (name === 'attendance') renderAttendance();
  if (name === 'assignments') renderAssignments();
  if (name === 'fees') renderFees();
  if (name === 'analytics') renderAnalytics();
  if (name === 'school') renderSchool();
}

function loadBatches() {
  return api('/api/batches').then((batches) => {
    state.batches = batches;
    if (!state.selectedBatchId && batches.length > 0) state.selectedBatchId = batches[0].id;
  });
}

function batchOptions() {
  return state.batches.map((b) => '<option value="' + b.id + '"' + (b.id === state.selectedBatchId ? ' selected' : '') + '>' + b.title + '</option>').join('');
}

// --- Batches tab ---
function renderBatches() {
  const el = document.getElementById('tab-batches');
  el.innerHTML =
    '<div class="card"><h2>Create a Batch</h2>' +
    '<div class="row">' +
    '<div><label>Title</label><input id="b_title" /></div>' +
    '<div><label>Subject</label><input id="b_subject" /></div>' +
    '</div>' +
    '<div class="row">' +
    '<div><label>Schedule</label><input id="b_schedule" placeholder="5:00 PM - 6:30 PM" /></div>' +
    '<div><label>Room / Link</label><input id="b_room" /></div>' +
    '</div>' +
    '<button class="primary" onclick="createBatch()">Create Batch</button>' +
    '<div id="b_error" class="error hidden"></div></div>' +
    '<div class="card"><h2>Your Batches</h2><div id="b_list"></div></div>';

  const list = document.getElementById('b_list');
  if (state.batches.length === 0) {
    list.innerHTML = '<p class="muted">No batches yet.</p>';
    return;
  }
  list.innerHTML = '<table><tr><th>Title</th><th>Subject</th><th>Schedule</th><th>Students</th></tr>' +
    state.batches.map((b) => '<tr><td>' + escapeHtml(b.title) + '</td><td>' + escapeHtml(b.subject) + '</td><td>' + escapeHtml(b.scheduleTime) + '</td><td>' + b.activeStudentCount + '</td></tr>').join('') +
    '</table>';
}

function createBatch() {
  const title = document.getElementById('b_title').value.trim();
  const subject = document.getElementById('b_subject').value.trim();
  const scheduleTime = document.getElementById('b_schedule').value.trim();
  const roomOrMeetingLink = document.getElementById('b_room').value.trim();
  const errEl = document.getElementById('b_error');
  errEl.classList.add('hidden');
  if (!title || !subject || !scheduleTime) {
    errEl.textContent = 'Title, subject, and schedule are required.';
    errEl.classList.remove('hidden');
    return;
  }
  api('/api/batches', { method: 'POST', body: JSON.stringify({ title, subject, scheduleTime, roomOrMeetingLink }) })
    .then(() => loadBatches())
    .then(() => renderBatches())
    .catch((e) => { errEl.textContent = e.message; errEl.classList.remove('hidden'); });
}

// --- Attendance tab ---
function renderAttendance() {
  const el = document.getElementById('tab-attendance');
  const today = new Date().toISOString().slice(0, 10);
  el.innerHTML =
    '<div class="card"><h2>Mark Attendance</h2>' +
    '<label>Batch</label><select id="a_batch" onchange="onAttendanceBatchChange()">' + batchOptions() + '</select>' +
    '<p class="muted">Date: ' + today + '</p>' +
    '<div id="a_roster"></div>' +
    '<button class="primary" onclick="submitAttendance()">Save Attendance</button>' +
    '<div id="a_error" class="error hidden"></div></div>';
  loadRoster();
}

function onAttendanceBatchChange() {
  state.selectedBatchId = document.getElementById('a_batch').value;
  loadRoster();
}

function loadRoster() {
  const rosterEl = document.getElementById('a_roster');
  if (!state.selectedBatchId) { rosterEl.innerHTML = '<p class="muted">Create a batch first.</p>'; return; }
  rosterEl.innerHTML = '<p class="muted">Loading...</p>';
  api('/api/batches/' + state.selectedBatchId + '/students')
    .then((students) => {
      if (students.length === 0) { rosterEl.innerHTML = '<p class="muted">No students enrolled in this batch yet.</p>'; return; }
      rosterEl.innerHTML = '<table><tr><th>Student</th><th>Status</th></tr>' +
        students.map((s) =>
          '<tr><td>' + escapeHtml(s.fullName) + '</td><td>' +
          '<select data-student="' + s.id + '" class="att-status">' +
          '<option value="PRESENT">Present</option><option value="ABSENT">Absent</option><option value="LATE">Late</option>' +
          '</select></td></tr>'
        ).join('') + '</table>';
    })
    .catch((e) => { rosterEl.innerHTML = '<p class="error">' + escapeHtml(e.message) + '</p>'; });
}

function submitAttendance() {
  const today = new Date().toISOString().slice(0, 10);
  const errEl = document.getElementById('a_error');
  errEl.classList.add('hidden');
  const rows = Array.from(document.querySelectorAll('.att-status'));
  const records = rows.map((sel) => ({
    id: '', batchId: state.selectedBatchId, studentId: sel.dataset.student, studentName: '', date: today, status: sel.value, notes: ''
  }));
  api('/api/batches/' + state.selectedBatchId + '/attendance', {
    method: 'POST',
    body: JSON.stringify({ batchId: state.selectedBatchId, date: today, records })
  })
    .then(() => { errEl.textContent = 'Saved!'; errEl.style.color = '#2e7d32'; errEl.classList.remove('hidden'); })
    .catch((e) => { errEl.style.color = ''; errEl.textContent = e.message; errEl.classList.remove('hidden'); });
}

// --- Assignments tab ---
function renderAssignments() {
  const el = document.getElementById('tab-assignments');
  el.innerHTML =
    '<div class="card"><h2>Publish an Assignment</h2>' +
    '<label>Batch</label><select id="as_batch" onchange="loadAssignments()">' + batchOptions() + '</select>' +
    '<label>Title</label><input id="as_title" />' +
    '<label>Description</label><textarea id="as_desc" rows="2"></textarea>' +
    '<label>Due Date</label><input id="as_due" placeholder="2026-09-20" />' +
    '<button class="primary" onclick="createAssignment()">Publish</button>' +
    '<div id="as_error" class="error hidden"></div></div>' +
    '<div class="card"><h2>Assignments</h2><div id="as_list"></div></div>';
  if (!document.getElementById('as_batch').value) return;
  state.selectedBatchId = document.getElementById('as_batch').value;
  loadAssignments();
}

function loadAssignments() {
  state.selectedBatchId = document.getElementById('as_batch').value;
  const listEl = document.getElementById('as_list');
  if (!state.selectedBatchId) { listEl.innerHTML = '<p class="muted">Create a batch first.</p>'; return; }
  listEl.innerHTML = '<p class="muted">Loading...</p>';
  api('/api/batches/' + state.selectedBatchId + '/assignments')
    .then((items) => {
      if (items.length === 0) { listEl.innerHTML = '<p class="muted">No assignments yet.</p>'; return; }
      listEl.innerHTML = items.map((a) =>
        '<div style="padding:10px 0;border-bottom:1px solid #eee">' +
        '<strong>' + escapeHtml(a.title) + '</strong> <span class="muted">— due ' + escapeHtml(a.dueDate) + '</span>' +
        '<div><button class="secondary grade-btn" data-assignment-id="' + a.id + '" data-max-score="' + a.maxScore + '">Grade Submissions</button></div>' +
        '<div id="sub_' + a.id + '"></div></div>'
      ).join('');
      Array.from(document.getElementsByClassName('grade-btn')).forEach((btn) => {
        btn.onclick = function () { viewSubmissions(btn.dataset.assignmentId, parseInt(btn.dataset.maxScore, 10)); };
      });
    })
    .catch((e) => { listEl.innerHTML = '<p class="error">' + escapeHtml(e.message) + '</p>'; });
}

function createAssignment() {
  const title = document.getElementById('as_title').value.trim();
  const description = document.getElementById('as_desc').value.trim();
  const dueDate = document.getElementById('as_due').value.trim();
  const errEl = document.getElementById('as_error');
  errEl.classList.add('hidden');
  if (!title || !dueDate) {
    errEl.textContent = 'Title and due date are required.';
    errEl.classList.remove('hidden');
    return;
  }
  api('/api/batches/' + state.selectedBatchId + '/assignments', { method: 'POST', body: JSON.stringify({ title, description, dueDate }) })
    .then(() => { document.getElementById('as_title').value = ''; document.getElementById('as_desc').value = ''; document.getElementById('as_due').value = ''; loadAssignments(); })
    .catch((e) => { errEl.textContent = e.message; errEl.classList.remove('hidden'); });
}

function viewSubmissions(assignmentId, maxScore) {
  const container = document.getElementById('sub_' + assignmentId);
  container.innerHTML = '<p class="muted">Loading...</p>';
  api('/api/batches/' + state.selectedBatchId + '/assignments/' + assignmentId + '/submissions')
    .then((subs) => {
      container.innerHTML = '<table><tr><th>Student</th><th>Submitted</th><th>Score</th><th></th></tr>' +
        subs.map((s) =>
          '<tr><td>' + escapeHtml(s.studentName) + '</td><td>' + (s.isSubmitted ? 'Yes' : 'No') + '</td>' +
          '<td><input type="number" style="width:70px" id="score_' + assignmentId + '_' + s.studentId + '" value="' + (s.scoreEarned ?? '') + '" placeholder="/' + maxScore + '" /></td>' +
          '<td><button class="secondary save-grade-btn" data-assignment-id="' + assignmentId + '" data-student-id="' + s.studentId + '">Save</button></td></tr>'
        ).join('') + '</table>';
      Array.from(container.getElementsByClassName('save-grade-btn')).forEach((btn) => {
        btn.onclick = function () { saveGrade(btn.dataset.assignmentId, btn.dataset.studentId); };
      });
    })
    .catch((e) => { container.innerHTML = '<p class="error">' + escapeHtml(e.message) + '</p>'; });
}

function saveGrade(assignmentId, studentId) {
  const input = document.getElementById('score_' + assignmentId + '_' + studentId);
  const score = parseInt(input.value, 10);
  if (isNaN(score)) return;
  api('/api/batches/' + state.selectedBatchId + '/assignments/' + assignmentId + '/grade', {
    method: 'POST',
    body: JSON.stringify({ studentId: studentId, scoreEarned: score })
  }).catch((e) => alert(e.message));
}

// --- Fees tab ---
function renderFees() {
  const el = document.getElementById('tab-fees');
  el.innerHTML =
    '<div class="card"><h2>New Fee Record</h2>' +
    '<label>Student</label><select id="f_student"></select>' +
    '<div class="row">' +
    '<div><label>Month</label><input id="f_month" placeholder="September 2026" /></div>' +
    '<div><label>Amount Due</label><input id="f_amount" type="number" /></div>' +
    '<div><label>Due Date</label><input id="f_due" placeholder="2026-09-15" /></div>' +
    '</div>' +
    '<button class="primary" onclick="createFee()">Save</button>' +
    '<div id="f_error" class="error hidden"></div></div>' +
    '<div class="card"><h2>Fee Records</h2><div id="f_list"></div></div>';

  api('/api/fees/students').then((students) => {
    document.getElementById('f_student').innerHTML = students.map((s) => '<option value="' + s.id + '">' + escapeHtml(s.fullName) + '</option>').join('');
  });
  loadFees();
}

function loadFees() {
  const listEl = document.getElementById('f_list');
  listEl.innerHTML = '<p class="muted">Loading...</p>';
  api('/api/fees')
    .then((fees) => {
      if (fees.length === 0) { listEl.innerHTML = '<p class="muted">No fee records yet.</p>'; return; }
      listEl.innerHTML = '<table><tr><th>Student</th><th>Month</th><th>Amount</th><th>Status</th><th></th></tr>' +
        fees.map((f) =>
          '<tr><td>' + escapeHtml(f.studentName) + '</td><td>' + escapeHtml(f.monthYear) + '</td><td>' + f.amountDue + '</td>' +
          '<td class="status-' + f.status + '">' + f.status + '</td>' +
          '<td>' + (f.status !== 'PAID' ? '<button class="secondary mark-paid-btn" data-invoice-id="' + f.invoiceId + '">Mark Paid</button>' : '') + '</td></tr>'
        ).join('') + '</table>';
      Array.from(listEl.getElementsByClassName('mark-paid-btn')).forEach((btn) => {
        btn.onclick = function () { markPaid(btn.dataset.invoiceId); };
      });
    })
    .catch((e) => { listEl.innerHTML = '<p class="error">' + escapeHtml(e.message) + '</p>'; });
}

function createFee() {
  const studentId = document.getElementById('f_student').value;
  const monthYear = document.getElementById('f_month').value.trim();
  const amountDue = parseFloat(document.getElementById('f_amount').value);
  const dueDate = document.getElementById('f_due').value.trim();
  const errEl = document.getElementById('f_error');
  errEl.classList.add('hidden');
  if (!studentId || !monthYear || !amountDue || !dueDate) {
    errEl.textContent = 'All fields are required.';
    errEl.classList.remove('hidden');
    return;
  }
  api('/api/fees', { method: 'POST', body: JSON.stringify({ studentId, monthYear, amountDue, dueDate }) })
    .then(() => { document.getElementById('f_month').value = ''; document.getElementById('f_amount').value = ''; document.getElementById('f_due').value = ''; loadFees(); })
    .catch((e) => { errEl.textContent = e.message; errEl.classList.remove('hidden'); });
}

function markPaid(feeId) {
  api('/api/fees/' + feeId + '/mark-paid', { method: 'POST' }).then(loadFees).catch((e) => alert(e.message));
}

// --- Analytics tab ---
function renderAnalytics() {
  const el = document.getElementById('tab-analytics');
  el.innerHTML = '<div class="card"><p class="muted">Loading...</p></div>';

  Promise.all([
    api('/api/analytics/overview'),
    api('/api/analytics/attendance-trend?days=30'),
    api('/api/analytics/revenue-trend?months=6'),
    api('/api/analytics/batch-performance')
  ]).then((results) => {
    const overview = results[0];
    const attendanceTrend = results[1];
    const revenueTrend = results[2];
    const batchPerf = results[3];

    const presentPct = overview.attendance.presentRate == null ? null : Math.round(overview.attendance.presentRate * 100);
    const collectionRate = overview.fees.totalDue > 0 ? overview.fees.totalCollected / overview.fees.totalDue : null;
    const collectionPct = collectionRate == null ? null : Math.round(collectionRate * 100);

    el.innerHTML =
      '<div class="card">' +
      '<div class="row">' +
      statCard('Batches', overview.totalBatches) +
      statCard('Students', overview.totalStudents) +
      statCard('Homework', overview.totalAssignments) +
      statCard('Attendance (30d)', presentPct == null ? '—' : presentPct + '%') +
      statCard('Fees Collected', collectionPct == null ? '—' : collectionPct + '%') +
      '</div></div>' +
      '<div class="card"><h2>Attendance — last 30 days</h2>' + attendanceChart(attendanceTrend) + '</div>' +
      '<div class="card"><h2>Revenue — last 6 months</h2>' + revenueChart(revenueTrend) + '</div>' +
      '<div class="card"><h2>Batch Performance</h2>' + batchPerformanceTable(batchPerf) + '</div>';
  }).catch((e) => {
    el.innerHTML = '<div class="card"><p class="error">' + escapeHtml(e.message) + '</p></div>';
  });
}

function statCard(label, value) {
  return '<div style="flex:1;min-width:110px;text-align:center;padding:10px 4px">' +
    '<div style="font-size:22px;font-weight:700">' + escapeHtml(String(value)) + '</div>' +
    '<div class="muted" style="font-size:11px">' + escapeHtml(label) + '</div></div>';
}

function attendanceChart(points) {
  if (!points || points.length === 0) return '<p class="muted">No attendance marked in this period yet.</p>';
  const width = 700, height = 160, padding = 20;
  const barGap = 4;
  const barWidth = Math.max(4, (width - padding * 2) / points.length - barGap);
  const maxTotal = Math.max(1, ...points.map((p) => p.present + p.absent + p.late));

  let bars = '';
  points.forEach((p, i) => {
    const x = padding + i * (barWidth + barGap);
    const total = p.present + p.absent + p.late;
    const scale = (height - padding * 2) / maxTotal;
    let y = height - padding;
    const segments = [
      { value: p.present, color: '#2e7d32' },
      { value: p.late, color: '#ef6c00' },
      { value: p.absent, color: '#c62828' }
    ];
    segments.forEach((seg) => {
      const segHeight = seg.value * scale;
      y -= segHeight;
      if (segHeight > 0) {
        bars += '<rect x="' + x + '" y="' + y + '" width="' + barWidth + '" height="' + segHeight + '" fill="' + seg.color + '"><title>' + escapeHtml(p.date) + '</title></rect>';
      }
    });
  });

  return '<svg viewBox="0 0 ' + width + ' ' + height + '" style="width:100%;height:160px" preserveAspectRatio="none">' + bars + '</svg>' +
    '<div class="muted" style="font-size:12px;margin-top:6px">' +
    '<span style="color:#2e7d32">■</span> Present &nbsp; <span style="color:#ef6c00">■</span> Late &nbsp; <span style="color:#c62828">■</span> Absent' +
    '</div>';
}

function revenueChart(points) {
  if (!points || points.length === 0) return '<p class="muted">No fee records yet.</p>';
  const width = 700, height = 180, padding = 24;
  const barGap = 16;
  const groupWidth = (width - padding * 2) / points.length;
  const barWidth = (groupWidth - barGap) / 2;
  const maxAmount = Math.max(1, ...points.map((p) => p.collected + p.pending));

  let bars = '';
  let labels = '';
  points.forEach((p, i) => {
    const groupX = padding + i * groupWidth;
    const scale = (height - padding * 2) / maxAmount;
    const collectedHeight = p.collected * scale;
    const pendingHeight = p.pending * scale;
    bars += '<rect x="' + groupX + '" y="' + (height - padding - collectedHeight) + '" width="' + barWidth + '" height="' + collectedHeight + '" fill="#2e7d32"><title>' + escapeHtml(p.monthYear) + ' collected: ' + p.collected + '</title></rect>';
    bars += '<rect x="' + (groupX + barWidth + 2) + '" y="' + (height - padding - pendingHeight) + '" width="' + barWidth + '" height="' + pendingHeight + '" fill="#ef6c00"><title>' + escapeHtml(p.monthYear) + ' pending: ' + p.pending + '</title></rect>';
    labels += '<div style="flex:1;text-align:center;font-size:10px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + escapeHtml(p.monthYear) + '</div>';
  });

  return '<svg viewBox="0 0 ' + width + ' ' + height + '" style="width:100%;height:180px" preserveAspectRatio="none">' + bars + '</svg>' +
    '<div style="display:flex">' + labels + '</div>' +
    '<div class="muted" style="font-size:12px;margin-top:6px"><span style="color:#2e7d32">■</span> Collected &nbsp; <span style="color:#ef6c00">■</span> Pending</div>';
}

function batchPerformanceTable(rows) {
  if (!rows || rows.length === 0) return '<p class="muted">No batches yet.</p>';
  return '<table><tr><th>Batch</th><th>Students</th><th>Homework Completion</th><th>Attendance Rate</th></tr>' +
    rows.map((r) =>
      '<tr><td>' + escapeHtml(r.title) + '</td><td>' + r.studentCount + '</td>' +
      '<td>' + (r.submissionRate == null ? '—' : Math.round(r.submissionRate * 100) + '%') + '</td>' +
      '<td>' + (r.attendanceRate == null ? '—' : Math.round(r.attendanceRate * 100) + '%') + '</td></tr>'
    ).join('') + '</table>';
}

// --- School tab (school admins only) ---
function renderSchool() {
  const el = document.getElementById('tab-school');
  el.innerHTML = '<div class="card"><p class="muted">Loading...</p></div>';

  Promise.all([api('/api/school'), api('/api/school/members')]).then((results) => {
    const school = results[0];
    const members = results[1];

    el.innerHTML =
      '<div class="card"><h2>' + escapeHtml(school.name) + '</h2>' +
      '<p class="muted">' + school.teacherCount + ' teachers, ' + school.studentCount + ' students, ' + school.parentCount + ' parents</p>' +
      '<label>Student and parent join code</label><input readonly value="' + escapeHtml(school.studentCode) + '" />' +
      '<label>Teacher join code</label><input readonly value="' + escapeHtml(school.teacherCode) + '" />' +
      '<button class="secondary rotate-btn" data-which="student">New student/parent code</button>' +
      '<button class="secondary rotate-btn" data-which="teacher">New teacher code</button>' +
      '<div id="school_msg" class="muted" style="margin-top:8px"></div></div>' +
      '<div class="card"><h2>Members</h2><table><tr><th>Name</th><th>Email</th><th>Role</th><th>Joined</th></tr>' +
      members.map((m) =>
        '<tr><td>' + escapeHtml(m.fullName) + (m.isSchoolAdmin ? ' (admin)' : '') + '</td><td>' + escapeHtml(m.email) +
        '</td><td>' + escapeHtml(m.role) + '</td><td>' + escapeHtml(String(m.joinedAt).slice(0, 10)) + '</td></tr>'
      ).join('') + '</table></div>';

    Array.from(el.getElementsByClassName('rotate-btn')).forEach((btn) => {
      btn.onclick = function () {
        if (!confirm('Generate a new code? The old one will stop working immediately.')) return;
        api('/api/school/regenerate-codes', { method: 'POST', body: JSON.stringify({ which: btn.dataset.which }) })
          .then(() => renderSchool())
          .catch((e) => { document.getElementById('school_msg').textContent = e.message; });
      };
    });
  }).catch((e) => {
    el.innerHTML = '<div class="card"><p class="error">' + escapeHtml(e.message) + '</p></div>';
  });
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = String(str == null ? '' : str);
  return div.innerHTML;
}

// Restore a saved session, if any
(function restoreSession() {
  const baseUrl = localStorage.getItem('tp_baseUrl');
  const token = localStorage.getItem('tp_token');
  if (baseUrl && token) {
    state.baseUrl = baseUrl;
    state.token = token;
    document.getElementById('serverUrl').value = baseUrl;
    enterApp();
  }
})();
</script>
</body>
</html>`);
});

module.exports = router;
