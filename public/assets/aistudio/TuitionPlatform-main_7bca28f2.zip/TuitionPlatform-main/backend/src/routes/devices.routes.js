const express = require('express');
const { requireAuth } = require('../middleware/auth');
const { registerDeviceToken, removeDeviceToken } = require('../utils/push');

const router = express.Router();
router.use(requireAuth);

// POST /api/devices/register -> called after login and whenever FCM issues a new token
router.post('/register', async (req, res, next) => {
  try {
    const { fcmToken, platform } = req.body || {};
    if (!fcmToken) {
      return res.status(400).json({ error: 'fcmToken is required' });
    }
    await registerDeviceToken(req.user.id, fcmToken, platform);
    res.json({ success: true });
  } catch (err) {
    next(err);
  }
});

// POST /api/devices/unregister -> called on logout so a signed-out device stops getting pushes
router.post('/unregister', async (req, res, next) => {
  try {
    const { fcmToken } = req.body || {};
    if (!fcmToken) {
      return res.status(400).json({ error: 'fcmToken is required' });
    }
    await removeDeviceToken(fcmToken);
    res.json({ success: true });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
