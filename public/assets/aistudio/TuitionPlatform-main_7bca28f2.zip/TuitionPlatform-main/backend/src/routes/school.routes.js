const express = require('express');
const { pool } = require('../db');
const { requireAuth } = require('../middleware/auth');
const { isText } = require('../middleware/validate');
const { newStudentCode, newTeacherCode } = require('../utils/codes');

const router = express.Router();
router.use(requireAuth);

/** Loads the caller's school plus whether they administer it. */
async function loadSchool(req) {
  const result = await pool.query(
    `SELECT s.id, s.name, s.student_code, s.teacher_code, u.is_school_admin
     FROM schools s JOIN users u ON u.school_id = s.id
     WHERE u.id = $1 AND s.id = $2`,
    [req.user.id, req.user.schoolId]
  );
  return result.rows[0] || null;
}

/** Same as loadSchool, but answers 404/403 itself and returns null when the caller can't proceed. */
async function requireSchoolAdmin(req, res) {
  const school = await loadSchool(req);
  if (!school) {
    res.status(404).json({ error: 'School not found' });
    return null;
  }
  if (!school.is_school_admin) {
    res.status(403).json({ error: 'Only the school admin can do this' });
    return null;
  }
  return school;
}

// GET /api/school -> school name and head-counts; join codes are shown to the admin only
router.get('/', async (req, res, next) => {
  try {
    const school = await loadSchool(req);
    if (!school) return res.status(404).json({ error: 'School not found' });

    const counts = await pool.query(
      'SELECT role, COUNT(*)::int AS count FROM users WHERE school_id = $1 GROUP BY role',
      [school.id]
    );
    const byRole = { TEACHER: 0, STUDENT: 0, PARENT: 0 };
    counts.rows.forEach((row) => { byRole[row.role] = row.count; });

    res.json({
      id: school.id,
      name: school.name,
      isSchoolAdmin: Boolean(school.is_school_admin),
      teacherCount: byRole.TEACHER,
      studentCount: byRole.STUDENT,
      parentCount: byRole.PARENT,
      studentCode: school.is_school_admin ? school.student_code : null,
      teacherCode: school.is_school_admin ? school.teacher_code : null
    });
  } catch (err) {
    next(err);
  }
});

// PUT /api/school -> rename (admin only)
router.put('/', async (req, res, next) => {
  try {
    const school = await requireSchoolAdmin(req, res);
    if (!school) return;

    const { name } = req.body || {};
    if (!isText(name, 100)) {
      return res.status(400).json({ error: 'name is required (max 100 characters)' });
    }
    await pool.query('UPDATE schools SET name = $1 WHERE id = $2', [name.trim(), school.id]);
    res.json({ success: true });
  } catch (err) {
    next(err);
  }
});

// POST /api/school/regenerate-codes -> rotate a leaked join code (admin only)
//   body: { which: "student" | "teacher" | "both" }   (default "both")
router.post('/regenerate-codes', async (req, res, next) => {
  try {
    const school = await requireSchoolAdmin(req, res);
    if (!school) return;

    const which = (req.body && req.body.which) || 'both';
    if (!['student', 'teacher', 'both'].includes(which)) {
      return res.status(400).json({ error: 'which must be "student", "teacher", or "both"' });
    }

    const studentCode = which === 'teacher' ? school.student_code : newStudentCode();
    const teacherCode = which === 'student' ? school.teacher_code : newTeacherCode();
    await pool.query(
      'UPDATE schools SET student_code = $1, teacher_code = $2 WHERE id = $3',
      [studentCode, teacherCode, school.id]
    );
    res.json({ studentCode, teacherCode });
  } catch (err) {
    next(err);
  }
});

// GET /api/school/members -> everyone in the school (admin only)
router.get('/members', async (req, res, next) => {
  try {
    const school = await requireSchoolAdmin(req, res);
    if (!school) return;

    const result = await pool.query(
      `SELECT id, full_name, email, role, is_school_admin, avatar_url, created_at
       FROM users WHERE school_id = $1
       ORDER BY role, full_name`,
      [school.id]
    );
    res.json(result.rows.map((row) => ({
      id: row.id,
      fullName: row.full_name,
      email: row.email,
      role: row.role,
      isSchoolAdmin: Boolean(row.is_school_admin),
      avatarUrl: row.avatar_url || null,
      joinedAt: row.created_at instanceof Date ? row.created_at.toISOString() : row.created_at
    })));
  } catch (err) {
    next(err);
  }
});

module.exports = router;
