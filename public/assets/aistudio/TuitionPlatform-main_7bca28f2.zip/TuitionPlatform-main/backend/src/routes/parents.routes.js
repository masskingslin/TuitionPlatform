const express = require('express');
const { pool } = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');
const { isText, uuidParam } = require('../middleware/validate');
const { randomCode } = require('../utils/codes');

const router = express.Router();
router.use(requireAuth);
router.param('studentId', uuidParam('studentId'));
router.param('parentId', uuidParam('parentId'));

const LINK_CODE_TTL_MS = 48 * 60 * 60 * 1000; // 48 hours

// ---------------------------------------------------------------------
// Linking a parent to a student
//   1. The student asks for a code (POST /link-code) and gives it to a parent.
//   2. The parent enters it (POST /link). Codes work for 48 hours, so a
//      second parent can use the same one; the student can revoke access
//      at any time (DELETE /my-parents/:parentId).
// ---------------------------------------------------------------------

// POST /api/parents/link-code -> student generates a fresh code (replaces any earlier one)
router.post('/link-code', requireRole('STUDENT'), async (req, res, next) => {
  try {
    await pool.query('DELETE FROM parent_link_codes WHERE student_id = $1', [req.user.id]);
    const code = randomCode(8);
    const expiresAt = new Date(Date.now() + LINK_CODE_TTL_MS);
    await pool.query(
      'INSERT INTO parent_link_codes (code, student_id, expires_at) VALUES ($1, $2, $3)',
      [code, req.user.id, expiresAt]
    );
    res.status(201).json({ code, expiresAt: expiresAt.toISOString() });
  } catch (err) {
    next(err);
  }
});

// POST /api/parents/link { code } -> parent links themselves to the student who issued the code
router.post('/link', requireRole('PARENT'), async (req, res, next) => {
  try {
    const { code } = req.body || {};
    if (!isText(code, 20)) {
      return res.status(400).json({ error: 'code is required' });
    }

    const found = await pool.query(
      `SELECT c.student_id, u.full_name, u.avatar_url, u.school_id
       FROM parent_link_codes c JOIN users u ON u.id = c.student_id
       WHERE c.code = $1 AND c.expires_at > now()`,
      [code.trim().toUpperCase()]
    );
    const student = found.rows[0];
    // Same message for "unknown", "expired" and "other school" so codes can't be probed.
    if (!student || student.school_id !== req.user.schoolId) {
      return res.status(400).json({ error: 'That code is invalid or has expired' });
    }

    await pool.query(
      'INSERT INTO parent_students (parent_id, student_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
      [req.user.id, student.student_id]
    );
    res.status(201).json({ id: student.student_id, fullName: student.full_name, avatarUrl: student.avatar_url || null });
  } catch (err) {
    next(err);
  }
});

// GET /api/parents/children -> the parent's linked children
router.get('/children', requireRole('PARENT'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT u.id, u.full_name, u.avatar_url
       FROM parent_students ps JOIN users u ON u.id = ps.student_id
       WHERE ps.parent_id = $1
       ORDER BY u.full_name`,
      [req.user.id]
    );
    res.json(result.rows.map((row) => ({ id: row.id, fullName: row.full_name, avatarUrl: row.avatar_url || null })));
  } catch (err) {
    next(err);
  }
});

// DELETE /api/parents/children/:studentId -> parent unlinks themselves
router.delete('/children/:studentId', requireRole('PARENT'), async (req, res, next) => {
  try {
    await pool.query('DELETE FROM parent_students WHERE parent_id = $1 AND student_id = $2', [req.user.id, req.params.studentId]);
    res.json({ success: true });
  } catch (err) {
    next(err);
  }
});

// GET /api/parents/my-parents -> student sees who can view their data
router.get('/my-parents', requireRole('STUDENT'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT u.id, u.full_name, u.email
       FROM parent_students ps JOIN users u ON u.id = ps.parent_id
       WHERE ps.student_id = $1
       ORDER BY u.full_name`,
      [req.user.id]
    );
    res.json(result.rows.map((row) => ({ id: row.id, fullName: row.full_name, email: row.email })));
  } catch (err) {
    next(err);
  }
});

// DELETE /api/parents/my-parents/:parentId -> student revokes a parent's access
router.delete('/my-parents/:parentId', requireRole('STUDENT'), async (req, res, next) => {
  try {
    await pool.query('DELETE FROM parent_students WHERE student_id = $1 AND parent_id = $2', [req.user.id, req.params.parentId]);
    res.json({ success: true });
  } catch (err) {
    next(err);
  }
});

// ---------------------------------------------------------------------
// Read-only views of a linked child
// ---------------------------------------------------------------------

/** 404s (rather than 403s, to avoid confirming a student exists) unless the caller is a parent linked to :studentId. */
async function requireLinkedChild(req, res, next) {
  try {
    if (req.user.role !== 'PARENT') {
      return res.status(403).json({ error: 'Not permitted for this role' });
    }
    const link = await pool.query(
      'SELECT 1 FROM parent_students WHERE parent_id = $1 AND student_id = $2',
      [req.user.id, req.params.studentId]
    );
    if (link.rows.length === 0) {
      return res.status(404).json({ error: 'Child not found' });
    }
    next();
  } catch (err) {
    next(err);
  }
}

const dateString = (value) => (value instanceof Date ? value.toISOString().slice(0, 10) : value);

// GET /api/parents/children/:studentId/summary -> headline numbers for the overview screen
router.get('/children/:studentId/summary', requireLinkedChild, async (req, res, next) => {
  try {
    const { studentId } = req.params;
    const [child, attendance, fees, assignments] = await Promise.all([
      pool.query('SELECT id, full_name, avatar_url FROM users WHERE id = $1', [studentId]),
      pool.query(
        `SELECT status, COUNT(*)::int AS count FROM attendance_records
         WHERE student_id = $1 AND date >= (CURRENT_DATE - INTERVAL '30 days')
         GROUP BY status`,
        [studentId]
      ),
      pool.query(
        `SELECT COALESCE(SUM(amount_due), 0)::float AS total_due,
                COALESCE(SUM(amount_paid), 0)::float AS total_paid,
                (COUNT(*) FILTER (WHERE status = 'OVERDUE'))::int AS overdue
         FROM fee_records WHERE student_id = $1`,
        [studentId]
      ),
      pool.query(
        `SELECT COUNT(a.id)::int AS total,
                (COUNT(s.assignment_id) FILTER (WHERE s.is_submitted))::int AS submitted,
                COUNT(s.score_earned)::int AS graded,
                AVG(s.score_earned::float / NULLIF(a.max_score, 0))::float AS average_rate
         FROM assignments a
         JOIN enrollments e ON e.batch_id = a.batch_id AND e.student_id = $1
         LEFT JOIN assignment_submissions s ON s.assignment_id = a.id AND s.student_id = $1`,
        [studentId]
      )
    ]);

    const childRow = child.rows[0];
    if (!childRow) return res.status(404).json({ error: 'Child not found' });

    const byStatus = { PRESENT: 0, ABSENT: 0, LATE: 0, EXCUSED: 0 };
    attendance.rows.forEach((row) => { byStatus[row.status] = row.count; });
    const marked = Object.values(byStatus).reduce((sum, n) => sum + n, 0);

    const f = fees.rows[0];
    const a = assignments.rows[0];

    res.json({
      child: { id: childRow.id, fullName: childRow.full_name, avatarUrl: childRow.avatar_url || null },
      attendance: {
        presentCount: byStatus.PRESENT,
        absentCount: byStatus.ABSENT,
        lateCount: byStatus.LATE,
        excusedCount: byStatus.EXCUSED,
        presentRate: marked > 0 ? byStatus.PRESENT / marked : null
      },
      fees: {
        totalDue: f.total_due,
        totalPaid: f.total_paid,
        totalPending: f.total_due - f.total_paid,
        overdueInvoices: f.overdue
      },
      assignments: {
        total: a.total,
        submitted: a.submitted,
        graded: a.graded,
        averageScoreRate: a.graded > 0 ? a.average_rate : null
      }
    });
  } catch (err) {
    next(err);
  }
});

// GET /api/parents/children/:studentId/batches
router.get('/children/:studentId/batches', requireLinkedChild, async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT b.id, b.title, b.subject, t.full_name AS teacher_name, b.schedule_time, b.room_or_meeting_link,
              (SELECT COUNT(*) FROM enrollments e2 WHERE e2.batch_id = b.id)::int AS active_student_count
       FROM enrollments e
       JOIN batches b ON b.id = e.batch_id
       JOIN users t ON t.id = b.teacher_id
       WHERE e.student_id = $1
       ORDER BY b.title`,
      [req.params.studentId]
    );
    res.json(result.rows.map((row) => ({
      id: row.id,
      title: row.title,
      subject: row.subject,
      teacherName: row.teacher_name,
      scheduleTime: row.schedule_time,
      activeStudentCount: row.active_student_count,
      roomOrMeetingLink: row.room_or_meeting_link || ''
    })));
  } catch (err) {
    next(err);
  }
});

// GET /api/parents/children/:studentId/attendance -> most recent 200 records across all batches
router.get('/children/:studentId/attendance', requireLinkedChild, async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT ar.id, ar.batch_id, b.title AS batch_title, ar.student_id, u.full_name AS student_name,
              ar.date, ar.status, ar.notes
       FROM attendance_records ar
       JOIN batches b ON b.id = ar.batch_id
       JOIN users u ON u.id = ar.student_id
       WHERE ar.student_id = $1
       ORDER BY ar.date DESC
       LIMIT 200`,
      [req.params.studentId]
    );
    res.json(result.rows.map((row) => ({
      id: row.id,
      batchId: row.batch_id,
      batchTitle: row.batch_title,
      studentId: row.student_id,
      studentName: row.student_name,
      date: dateString(row.date),
      status: row.status,
      notes: row.notes || ''
    })));
  } catch (err) {
    next(err);
  }
});

// GET /api/parents/children/:studentId/assignments -> most recent 200 across all batches, with the child's status/score
router.get('/children/:studentId/assignments', requireLinkedChild, async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT a.id, a.batch_id, b.title AS batch_title, a.title, a.description, a.due_date, a.max_score,
              a.attachment_url, a.attachment_name,
              s.is_submitted, s.score_earned,
              s.attachment_url AS submission_attachment_url, s.attachment_name AS submission_attachment_name
       FROM assignments a
       JOIN batches b ON b.id = a.batch_id
       JOIN enrollments e ON e.batch_id = a.batch_id AND e.student_id = $1
       LEFT JOIN assignment_submissions s ON s.assignment_id = a.id AND s.student_id = $1
       ORDER BY a.created_at DESC
       LIMIT 200`,
      [req.params.studentId]
    );
    res.json(result.rows.map((row) => ({
      id: row.id,
      batchId: row.batch_id,
      batchTitle: row.batch_title,
      title: row.title,
      description: row.description,
      dueDate: row.due_date,
      maxScore: row.max_score,
      isSubmitted: row.is_submitted || false,
      scoreEarned: row.score_earned ?? null,
      attachmentUrl: row.attachment_url || null,
      attachmentName: row.attachment_name || null,
      submissionAttachmentUrl: row.submission_attachment_url || null,
      submissionAttachmentName: row.submission_attachment_name || null
    })));
  } catch (err) {
    next(err);
  }
});

// GET /api/parents/children/:studentId/fees
router.get('/children/:studentId/fees', requireLinkedChild, async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT f.id AS invoice_id, f.student_id, u.full_name AS student_name, f.month_year,
              f.amount_due, f.amount_paid, f.status, f.due_date
       FROM fee_records f JOIN users u ON u.id = f.student_id
       WHERE f.student_id = $1
       ORDER BY f.due_date DESC`,
      [req.params.studentId]
    );
    res.json(result.rows.map((row) => ({
      invoiceId: row.invoice_id,
      studentId: row.student_id,
      studentName: row.student_name,
      monthYear: row.month_year,
      amountDue: Number(row.amount_due),
      amountPaid: Number(row.amount_paid),
      status: row.status,
      dueDate: dateString(row.due_date)
    })));
  } catch (err) {
    next(err);
  }
});

module.exports = router;
