const express = require('express');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { pool } = require('../db');
const { signToken } = require('../utils/tokens');
const { sendPasswordResetEmail } = require('../utils/mailer');
const { newStudentCode, newTeacherCode } = require('../utils/codes');
const { requireAuth } = require('../middleware/auth');
const { isEmail, isText } = require('../middleware/validate');

const router = express.Router();

const RESET_TOKEN_TTL_MS = 60 * 60 * 1000; // 1 hour
const ROLES = ['STUDENT', 'TEACHER', 'PARENT'];

// Compared against when an email doesn't exist, so "unknown email" and
// "wrong password" take the same time and can't be told apart by timing.
const DUMMY_HASH = bcrypt.hashSync('not-a-real-password', 10);

function hashToken(rawToken) {
  return crypto.createHash('sha256').update(rawToken).digest('hex');
}

function toAuthResponse(user) {
  return {
    token: signToken({ id: user.id, role: user.role, email: user.email, schoolId: user.school_id }),
    userId: user.id,
    fullName: user.full_name,
    email: user.email,
    role: user.role,
    avatarUrl: user.avatar_url || null,
    schoolId: user.school_id,
    schoolName: user.school_name || null,
    isSchoolAdmin: Boolean(user.is_school_admin)
  };
}

// POST /api/auth/register
//   Join an existing school:  { fullName, email, password, role, schoolCode }
//   Start a new school:       { fullName, email, password, role: "TEACHER", createSchool: true, schoolName }
//     (the creator becomes that school's admin)
router.post('/register', async (req, res, next) => {
  try {
    const { fullName, email, password, role, schoolCode, createSchool, schoolName } = req.body || {};

    if (!isText(fullName, 100) || !isEmail(email) || typeof password !== 'string' || !role) {
      return res.status(400).json({ error: 'A valid fullName, email, password, and role are required' });
    }
    if (!ROLES.includes(role)) {
      return res.status(400).json({ error: 'role must be STUDENT, TEACHER, or PARENT' });
    }
    if (password.length < 6 || password.length > 128) {
      return res.status(400).json({ error: 'Password must be between 6 and 128 characters' });
    }
    if (createSchool && role !== 'TEACHER') {
      return res.status(400).json({ error: 'Only a teacher can create a new school' });
    }
    if (createSchool && !isText(schoolName, 100)) {
      return res.status(400).json({ error: 'schoolName is required when creating a school' });
    }
    if (!createSchool && !isText(schoolCode, 20)) {
      return res.status(400).json({ error: 'schoolCode is required (ask your school for its join code)' });
    }

    const normalizedEmail = email.trim().toLowerCase();
    const existing = await pool.query('SELECT id FROM users WHERE email = $1', [normalizedEmail]);
    if (existing.rows.length > 0) {
      return res.status(409).json({ error: 'An account with this email already exists' });
    }

    const passwordHash = await bcrypt.hash(password, 10);

    if (createSchool) {
      // One statement, so the school and its first user are created together or not at all.
      const result = await pool.query(
        `WITH new_school AS (
           INSERT INTO schools (name, student_code, teacher_code)
           VALUES ($1::text, $2::text, $3::text)
           RETURNING id, name
         )
         INSERT INTO users (full_name, email, password_hash, role, school_id, is_school_admin)
         SELECT $4::text, $5::text, $6::text, $7::user_role, id, true FROM new_school
         RETURNING id, full_name, email, role, avatar_url, school_id, is_school_admin,
                   (SELECT name FROM new_school) AS school_name`,
        [schoolName.trim(), newStudentCode(), newTeacherCode(), fullName.trim(), normalizedEmail, passwordHash, role]
      );
      return res.status(201).json(toAuthResponse(result.rows[0]));
    }

    const code = schoolCode.trim().toUpperCase();
    const schoolResult = await pool.query(
      'SELECT id, name, student_code, teacher_code FROM schools WHERE student_code = $1 OR teacher_code = $1',
      [code]
    );
    const school = schoolResult.rows[0];
    if (!school) {
      return res.status(400).json({ error: 'That school code was not recognised' });
    }
    if (role === 'TEACHER' && school.teacher_code !== code) {
      return res.status(400).json({ error: 'That is a student/parent code. Ask your school admin for the teacher code.' });
    }
    if (role !== 'TEACHER' && school.student_code !== code) {
      return res.status(400).json({ error: 'That is a teacher code. Use the student/parent code instead.' });
    }

    const result = await pool.query(
      `INSERT INTO users (full_name, email, password_hash, role, school_id)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING id, full_name, email, role, avatar_url, school_id, is_school_admin`,
      [fullName.trim(), normalizedEmail, passwordHash, role, school.id]
    );
    res.status(201).json(toAuthResponse({ ...result.rows[0], school_name: school.name }));
  } catch (err) {
    next(err);
  }
});

router.post('/login', async (req, res, next) => {
  try {
    const { email, password } = req.body || {};
    if (typeof email !== 'string' || typeof password !== 'string' || !email || !password) {
      return res.status(400).json({ error: 'email and password are required' });
    }

    const normalizedEmail = email.trim().toLowerCase();
    const result = await pool.query(
      `SELECT u.*, s.name AS school_name
       FROM users u LEFT JOIN schools s ON s.id = u.school_id
       WHERE u.email = $1`,
      [normalizedEmail]
    );
    const user = result.rows[0];
    if (!user) {
      await bcrypt.compare(password, DUMMY_HASH);
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    const passwordMatches = await bcrypt.compare(password, user.password_hash);
    if (!passwordMatches) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }
    if (!user.school_id) {
      return res.status(403).json({ error: 'This account is not attached to a school. Contact your administrator.' });
    }

    res.json(toAuthResponse(user));
  } catch (err) {
    next(err);
  }
});

// Request a reset link. Always responds success (regardless of whether the
// email exists) so this endpoint can't be used to enumerate accounts.
router.post('/forgot-password', async (req, res, next) => {
  try {
    const { email } = req.body || {};
    if (typeof email !== 'string' || !email) {
      return res.status(400).json({ error: 'email is required' });
    }

    const normalizedEmail = email.trim().toLowerCase();
    const result = await pool.query('SELECT id FROM users WHERE email = $1', [normalizedEmail]);
    const user = result.rows[0];

    if (user) {
      const rawToken = crypto.randomBytes(32).toString('hex');
      const expiresAt = new Date(Date.now() + RESET_TOKEN_TTL_MS);
      await pool.query(
        `INSERT INTO password_reset_tokens (user_id, token_hash, expires_at)
         VALUES ($1, $2, $3)`,
        [user.id, hashToken(rawToken), expiresAt]
      );

      const appBaseUrl = process.env.APP_BASE_URL || `http://localhost:${process.env.PORT || 4000}`;
      const resetUrl = `${appBaseUrl}/reset-password?token=${rawToken}`;
      await sendPasswordResetEmail(normalizedEmail, resetUrl);
    }

    res.json({ success: true });
  } catch (err) {
    next(err);
  }
});

// GET /api/auth/me -> refetch the current profile (e.g. after uploading a new avatar)
router.get('/me', requireAuth, async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT u.id, u.full_name, u.email, u.role, u.avatar_url, u.school_id, u.is_school_admin,
              s.name AS school_name
       FROM users u LEFT JOIN schools s ON s.id = u.school_id
       WHERE u.id = $1`,
      [req.user.id]
    );
    const user = result.rows[0];
    if (!user) {
      return res.status(404).json({ error: 'Account not found' });
    }
    res.json({
      userId: user.id,
      fullName: user.full_name,
      email: user.email,
      role: user.role,
      avatarUrl: user.avatar_url || null,
      schoolId: user.school_id,
      schoolName: user.school_name || null,
      isSchoolAdmin: Boolean(user.is_school_admin)
    });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
