const express = require('express');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { pool } = require('../db');

const router = express.Router();

function hashToken(rawToken) {
  return crypto.createHash('sha256').update(rawToken).digest('hex');
}

function pageShell(title, bodyHtml) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>${title}</title>
  <style>
    body { font-family: -apple-system, Segoe UI, Roboto, sans-serif; background: #f4f6f8; margin: 0; padding: 0; }
    .card { max-width: 380px; margin: 48px auto; background: #fff; border-radius: 12px; padding: 28px; box-shadow: 0 1px 4px rgba(0,0,0,0.08); }
    h1 { font-size: 20px; margin: 0 0 8px; }
    p { color: #555; font-size: 14px; line-height: 1.5; }
    label { display: block; font-size: 13px; font-weight: 600; margin: 16px 0 6px; }
    input { width: 100%; padding: 10px 12px; border: 1px solid #ccc; border-radius: 8px; font-size: 14px; box-sizing: border-box; }
    button { width: 100%; margin-top: 20px; padding: 12px; border: none; border-radius: 8px; background: #00695c; color: #fff; font-size: 15px; font-weight: 600; cursor: pointer; }
    .error { color: #c62828; font-size: 13px; margin-top: 10px; }
  </style>
</head>
<body>
  <div class="card">${bodyHtml}</div>
</body>
</html>`;
}

// GET /reset-password?token=... -> the form the emailed link opens
router.get('/reset-password', async (req, res) => {
  const { token } = req.query;
  if (!token) {
    return res.status(400).send(pageShell('Invalid Link', '<h1>Invalid link</h1><p>This reset link is missing its token.</p>'));
  }

  const result = await pool.query(
    'SELECT expires_at, used_at FROM password_reset_tokens WHERE token_hash = $1',
    [hashToken(token)]
  );
  const record = result.rows[0];
  if (!record || record.used_at || new Date(record.expires_at) < new Date()) {
    return res.status(400).send(pageShell(
      'Link Expired',
      '<h1>This link has expired</h1><p>Password reset links are valid for 1 hour. Please request a new one from the app.</p>'
    ));
  }

  res.send(pageShell('Reset Your Password', `
    <h1>Reset Your Password</h1>
    <p>Enter a new password for your account below.</p>
    <form method="POST" action="/reset-password">
      <input type="hidden" name="token" value="${token}" />
      <label for="password">New password</label>
      <input type="password" id="password" name="password" minlength="6" required />
      <label for="confirmPassword">Confirm new password</label>
      <input type="password" id="confirmPassword" name="confirmPassword" minlength="6" required />
      <button type="submit">Reset Password</button>
    </form>
  `));
});

// POST /reset-password -> handles the form submission above
router.post('/reset-password', async (req, res, next) => {
  try {
    const { token, password, confirmPassword } = req.body || {};

    if (!token || !password || !confirmPassword) {
      return res.status(400).send(pageShell('Something Went Wrong', '<h1>Missing information</h1><p>Please go back and fill out the form again.</p>'));
    }
    if (password !== confirmPassword) {
      return res.status(400).send(pageShell('Passwords Don\'t Match', '<h1>Passwords don\'t match</h1><p>Please go back and try again.</p>'));
    }
    if (password.length < 6) {
      return res.status(400).send(pageShell('Password Too Short', '<h1>Password too short</h1><p>Use at least 6 characters.</p>'));
    }

    const result = await pool.query(
      'SELECT id, user_id, expires_at, used_at FROM password_reset_tokens WHERE token_hash = $1',
      [hashToken(token)]
    );
    const record = result.rows[0];
    if (!record || record.used_at || new Date(record.expires_at) < new Date()) {
      return res.status(400).send(pageShell(
        'Link Expired',
        '<h1>This link has expired</h1><p>Password reset links are valid for 1 hour. Please request a new one from the app.</p>'
      ));
    }

    const newHash = await bcrypt.hash(password, 10);
    await pool.query('UPDATE users SET password_hash = $1 WHERE id = $2', [newHash, record.user_id]);
    await pool.query('UPDATE password_reset_tokens SET used_at = now() WHERE id = $1', [record.id]);

    res.send(pageShell('Password Updated', '<h1>Password updated</h1><p>You can now sign in with your new password in the app.</p>'));
  } catch (err) {
    next(err);
  }
});

// GET /payment-result?status=success|cancelled -> shown after returning from Stripe Checkout
router.get('/payment-result', (req, res) => {
  const success = req.query.status === 'success';
  res.send(pageShell(
    success ? 'Payment Received' : 'Payment Cancelled',
    success
      ? '<h1>Payment received</h1><p>Thanks! Your payment is being processed and your fee record will update shortly. You can close this page and return to the app.</p>'
      : '<h1>Payment cancelled</h1><p>No charge was made. You can close this page and try again from the app whenever you\'re ready.</p>'
  ));
});

module.exports = router;
