const express = require('express');
const { pool } = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');
const { sendPushToStudentsAndParents, notifyInBackground } = require('../utils/push');
const { isUuid, uuidParam } = require('../middleware/validate');

const STATUSES = ['PRESENT', 'ABSENT', 'LATE', 'EXCUSED'];
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

function isRealDate(value) {
  if (typeof value !== 'string' || !DATE_RE.test(value)) return false;
  const d = new Date(`${value}T00:00:00Z`);
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === value;
}

const router = express.Router();
router.use(requireAuth);
router.param('batchId', uuidParam('batchId'));

async function assertTeacherOwnsBatch(req, res, batchId) {
  const owned = await pool.query('SELECT id FROM batches WHERE id = $1 AND teacher_id = $2', [batchId, req.user.id]);
  if (owned.rows.length === 0) {
    res.status(403).json({ error: 'You do not teach this batch' });
    return false;
  }
  return true;
}

async function assertBatchAccess(req, res, batchId) {
  if (req.user.role === 'TEACHER') {
    return assertTeacherOwnsBatch(req, res, batchId);
  }
  const enrolled = await pool.query(
    'SELECT 1 FROM enrollments WHERE batch_id = $1 AND student_id = $2',
    [batchId, req.user.id]
  );
  if (enrolled.rows.length === 0) {
    res.status(403).json({ error: 'You are not enrolled in this batch' });
    return false;
  }
  return true;
}

function toIsoDate(value) {
  if (value instanceof Date) return value.toISOString().slice(0, 10);
  return value;
}

// GET /api/batches/:batchId/attendance
router.get('/:batchId/attendance', async (req, res, next) => {
  try {
    const { batchId } = req.params;
    if (!(await assertBatchAccess(req, res, batchId))) return;

    const params = [batchId];
    let studentFilter = '';
    if (req.user.role === 'STUDENT') {
      studentFilter = 'AND ar.student_id = $2';
      params.push(req.user.id);
    }

    const result = await pool.query(
      `SELECT ar.id, ar.batch_id, ar.student_id, u.full_name AS student_name, ar.date, ar.status, ar.notes
       FROM attendance_records ar
       JOIN users u ON u.id = ar.student_id
       WHERE ar.batch_id = $1 ${studentFilter}
       ORDER BY ar.date DESC`,
      params
    );

    res.json(result.rows.map((row) => ({
      id: row.id,
      batchId: row.batch_id,
      studentId: row.student_id,
      studentName: row.student_name,
      date: toIsoDate(row.date),
      status: row.status,
      notes: row.notes || ''
    })));
  } catch (err) {
    next(err);
  }
});

// POST /api/batches/:batchId/attendance -> teacher submits attendance for a date
router.post('/:batchId/attendance', requireRole('TEACHER'), async (req, res, next) => {
  try {
    const { batchId } = req.params;
    if (!(await assertTeacherOwnsBatch(req, res, batchId))) return;

    const { date, records } = req.body || {};
    if (!isRealDate(date) || !Array.isArray(records) || records.length === 0 || records.length > 500) {
      return res.status(400).json({ error: 'date (YYYY-MM-DD) and a non-empty records[] (max 500) are required' });
    }
    const hasInvalidRecord = records.some((r) =>
      !r || !isUuid(r.studentId) || !STATUSES.includes(r.status) ||
      (r.notes !== undefined && (typeof r.notes !== 'string' || r.notes.length > 500)));
    if (hasInvalidRecord) {
      return res.status(400).json({ error: 'Each record needs a valid studentId, a status of PRESENT/ABSENT/LATE/EXCUSED, and optional notes (max 500 characters)' });
    }

    // Only students actually enrolled in this batch can be marked.
    const studentIds = [...new Set(records.map((r) => r.studentId))];
    const enrolled = await pool.query(
      'SELECT student_id FROM enrollments WHERE batch_id = $1 AND student_id = ANY($2::uuid[])',
      [batchId, studentIds]
    );
    if (enrolled.rows.length !== studentIds.length) {
      return res.status(400).json({ error: 'One or more students are not enrolled in this batch' });
    }

    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      for (const record of records) {
        await client.query(
          `INSERT INTO attendance_records (batch_id, student_id, date, status, notes)
           VALUES ($1, $2, $3, $4, $5)
           ON CONFLICT (batch_id, student_id, date)
           DO UPDATE SET status = EXCLUDED.status, notes = EXCLUDED.notes`,
          [batchId, record.studentId, date, record.status, record.notes || '']
        );
      }
      await client.query('COMMIT');
      res.json({ success: true });

      // Tell students (and their parents) about absences/lateness — the most
      // actionable updates, and it avoids pinging everyone every day.
      const flagged = records.filter((r) => r.status === 'ABSENT' || r.status === 'LATE');
      if (flagged.length > 0) {
        notifyInBackground(async () => {
          const batchRow = await pool.query('SELECT title FROM batches WHERE id = $1', [batchId]);
          const batchTitle = batchRow.rows[0]?.title || 'class';
          for (const record of flagged) {
            const label = record.status === 'ABSENT' ? 'marked absent' : 'marked late';
            await sendPushToStudentsAndParents(
              [record.studentId], 'Attendance updated', `Marked ${label.replace('marked ', '')} for ${batchTitle} on ${date}`,
              { type: 'ATTENDANCE_MARKED', batchId, date }
            );
          }
        });
      }
    } catch (err) {
      await client.query('ROLLBACK');
      next(err);
    } finally {
      client.release();
    }
  } catch (outerErr) {
    next(outerErr);
  }
});

module.exports = router;
