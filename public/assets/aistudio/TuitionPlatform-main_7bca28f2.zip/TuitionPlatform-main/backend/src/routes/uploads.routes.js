const express = require('express');
const { pool } = require('../db');
const { requireAuth } = require('../middleware/auth');
const { profilePhotoUpload, publicUrlFor } = require('../utils/uploads');

const router = express.Router();
router.use(requireAuth);

// POST /api/uploads/profile-photo -> multipart/form-data, field name "photo"
router.post('/profile-photo', (req, res, next) => {
  profilePhotoUpload.single('photo')(req, res, async (err) => {
    if (err) {
      return res.status(400).json({ error: err.message });
    }
    if (!req.file) {
      return res.status(400).json({ error: 'No photo file was uploaded (expected field "photo")' });
    }

    try {
      const url = publicUrlFor(req, 'avatars', req.file.filename);
      await pool.query('UPDATE users SET avatar_url = $1 WHERE id = $2', [url, req.user.id]);
      res.json({ url, filename: req.file.filename });
    } catch (dbErr) {
      next(dbErr);
    }
  });
});

module.exports = router;
