const express = require('express');
const { pool } = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');
const { sendPushToStudentsAndParents, notifyInBackground } = require('../utils/push');
const { isText, isUuid, uuidParam } = require('../middleware/validate');
const { assignmentAttachmentUpload, submissionAttachmentUpload, publicUrlFor } = require('../utils/uploads');

const router = express.Router();
router.use(requireAuth);
router.param('batchId', uuidParam('batchId'));
router.param('assignmentId', uuidParam('assignmentId'));

async function assertBatchAccess(req, res, batchId) {
  if (req.user.role === 'TEACHER') {
    const owned = await pool.query('SELECT id FROM batches WHERE id = $1 AND teacher_id = $2', [batchId, req.user.id]);
    if (owned.rows.length === 0) {
      res.status(403).json({ error: 'You do not teach this batch' });
      return false;
    }
    return true;
  }

  const enrolled = await pool.query(
    'SELECT 1 FROM enrollments WHERE batch_id = $1 AND student_id = $2',
    [batchId, req.user.id]
  );
  if (enrolled.rows.length === 0) {
    res.status(403).json({ error: 'You are not enrolled in this batch' });
    return false;
  }
  return true;
}

function toAssignment(row) {
  return {
    id: row.id,
    batchId: row.batch_id,
    title: row.title,
    description: row.description,
    dueDate: row.due_date,
    maxScore: row.max_score,
    isSubmitted: row.is_submitted || false,
    scoreEarned: row.score_earned ?? null,
    attachmentUrl: row.attachment_url || null,
    attachmentName: row.attachment_name || null,
    submissionAttachmentUrl: row.submission_attachment_url || null,
    submissionAttachmentName: row.submission_attachment_name || null
  };
}

// GET /api/batches/:batchId/assignments
router.get('/:batchId/assignments', async (req, res, next) => {
  try {
    const { batchId } = req.params;
    if (!(await assertBatchAccess(req, res, batchId))) return;

    const result = await pool.query(
      `SELECT a.id, a.batch_id, a.title, a.description, a.due_date, a.max_score,
              a.attachment_url, a.attachment_name,
              s.is_submitted, s.score_earned, s.attachment_url AS submission_attachment_url,
              s.attachment_name AS submission_attachment_name
       FROM assignments a
       LEFT JOIN assignment_submissions s
         ON s.assignment_id = a.id AND s.student_id = $2
       WHERE a.batch_id = $1
       ORDER BY a.created_at DESC`,
      [batchId, req.user.role === 'STUDENT' ? req.user.id : null]
    );

    res.json(result.rows.map(toAssignment));
  } catch (err) {
    next(err);
  }
});

// POST /api/batches/:batchId/assignments -> create (teacher only)
router.post('/:batchId/assignments', requireRole('TEACHER'), async (req, res, next) => {
  try {
    const { batchId } = req.params;
    if (!(await assertBatchAccess(req, res, batchId))) return;

    const { title, description, dueDate, maxScore } = req.body || {};
    if (!isText(title, 150) || !isText(dueDate, 40)) {
      return res.status(400).json({ error: 'title and dueDate are required (title max 150 characters)' });
    }
    if (description !== undefined && (typeof description !== 'string' || description.length > 5000)) {
      return res.status(400).json({ error: 'description must be a string of at most 5000 characters' });
    }
    if (maxScore !== undefined && (!Number.isInteger(maxScore) || maxScore < 1 || maxScore > 1000)) {
      return res.status(400).json({ error: 'maxScore must be a whole number between 1 and 1000' });
    }

    const result = await pool.query(
      `INSERT INTO assignments (batch_id, title, description, due_date, max_score)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING id, batch_id, title, description, due_date, max_score`,
      [batchId, title.trim(), description || '', dueDate.trim(), maxScore || 100]
    );

    const assignment = toAssignment(result.rows[0]);
    res.status(201).json(assignment);

    notifyInBackground(async () => {
      const enrolled = await pool.query('SELECT student_id FROM enrollments WHERE batch_id = $1', [batchId]);
      await sendPushToStudentsAndParents(
        enrolled.rows.map((row) => row.student_id),
        'New assignment posted',
        assignment.title,
        { type: 'ASSIGNMENT_CREATED', batchId, assignmentId: assignment.id }
      );
    });
  } catch (err) {
    next(err);
  }
});

// POST /api/batches/:batchId/assignments/:assignmentId/submit -> student marks their work submitted
router.post('/:batchId/assignments/:assignmentId/submit', requireRole('STUDENT'), async (req, res, next) => {
  try {
    const { batchId, assignmentId } = req.params;
    if (!(await assertBatchAccess(req, res, batchId))) return;

    const assignment = await pool.query('SELECT id FROM assignments WHERE id = $1 AND batch_id = $2', [assignmentId, batchId]);
    if (assignment.rows.length === 0) {
      return res.status(404).json({ error: 'Assignment not found' });
    }

    await pool.query(
      `INSERT INTO assignment_submissions (assignment_id, student_id, is_submitted)
       VALUES ($1, $2, true)
       ON CONFLICT (assignment_id, student_id)
       DO UPDATE SET is_submitted = true`,
      [assignmentId, req.user.id]
    );
    res.json({ success: true });
  } catch (err) {
    next(err);
  }
});

// GET /api/batches/:batchId/assignments/:assignmentId/submissions -> teacher's grading roster
router.get('/:batchId/assignments/:assignmentId/submissions', requireRole('TEACHER'), async (req, res, next) => {
  try {
    const { batchId, assignmentId } = req.params;
    if (!(await assertBatchAccess(req, res, batchId))) return;

    const assignment = await pool.query('SELECT id FROM assignments WHERE id = $1 AND batch_id = $2', [assignmentId, batchId]);
    if (assignment.rows.length === 0) {
      return res.status(404).json({ error: 'Assignment not found' });
    }

    const result = await pool.query(
      `SELECT u.id AS student_id, u.full_name AS student_name,
              COALESCE(s.is_submitted, false) AS is_submitted, s.score_earned,
              s.attachment_url, s.attachment_name
       FROM enrollments e
       JOIN users u ON u.id = e.student_id
       LEFT JOIN assignment_submissions s ON s.assignment_id = $2 AND s.student_id = e.student_id
       WHERE e.batch_id = $1
       ORDER BY u.full_name`,
      [batchId, assignmentId]
    );

    res.json(result.rows.map((row) => ({
      studentId: row.student_id,
      studentName: row.student_name,
      isSubmitted: row.is_submitted,
      scoreEarned: row.score_earned ?? null,
      attachmentUrl: row.attachment_url || null,
      attachmentName: row.attachment_name || null
    })));
  } catch (err) {
    next(err);
  }
});

// POST /api/batches/:batchId/assignments/:assignmentId/grade -> teacher records a score for one student
router.post('/:batchId/assignments/:assignmentId/grade', requireRole('TEACHER'), async (req, res, next) => {
  try {
    const { batchId, assignmentId } = req.params;
    if (!(await assertBatchAccess(req, res, batchId))) return;

    const { studentId, scoreEarned } = req.body || {};
    if (!isUuid(studentId) || !Number.isInteger(scoreEarned) || scoreEarned < 0) {
      return res.status(400).json({ error: 'studentId and a whole-number scoreEarned (0 or more) are required' });
    }

    const assignment = await pool.query(
      'SELECT id, title, max_score FROM assignments WHERE id = $1 AND batch_id = $2',
      [assignmentId, batchId]
    );
    if (assignment.rows.length === 0) {
      return res.status(404).json({ error: 'Assignment not found' });
    }
    const { title, max_score: maxScore } = assignment.rows[0];
    if (scoreEarned > maxScore) {
      return res.status(400).json({ error: `scoreEarned cannot exceed the maximum score of ${maxScore}` });
    }

    const enrolled = await pool.query(
      'SELECT 1 FROM enrollments WHERE batch_id = $1 AND student_id = $2',
      [batchId, studentId]
    );
    if (enrolled.rows.length === 0) {
      return res.status(400).json({ error: 'That student is not enrolled in this batch' });
    }

    await pool.query(
      `INSERT INTO assignment_submissions (assignment_id, student_id, is_submitted, score_earned)
       VALUES ($1, $2, true, $3)
       ON CONFLICT (assignment_id, student_id)
       DO UPDATE SET score_earned = EXCLUDED.score_earned, is_submitted = true`,
      [assignmentId, studentId, scoreEarned]
    );
    res.json({ success: true });

    notifyInBackground(() => sendPushToStudentsAndParents(
      [studentId], 'Assignment graded', `"${title}" — ${scoreEarned}/${maxScore}`,
      { type: 'ASSIGNMENT_GRADED', batchId, assignmentId }
    ));
  } catch (err) {
    next(err);
  }
});

// POST /api/batches/:batchId/assignments/:assignmentId/attachment -> teacher attaches material (worksheet, etc.)
router.post('/:batchId/assignments/:assignmentId/attachment', requireRole('TEACHER'), (req, res, next) => {
  assignmentAttachmentUpload.single('file')(req, res, async (err) => {
    if (err) {
      return res.status(400).json({ error: err.message });
    }
    if (!req.file) {
      return res.status(400).json({ error: 'No file was uploaded (expected field "file")' });
    }

    try {
      const { batchId, assignmentId } = req.params;
      if (!(await assertBatchAccess(req, res, batchId))) return;

      const assignment = await pool.query('SELECT id FROM assignments WHERE id = $1 AND batch_id = $2', [assignmentId, batchId]);
      if (assignment.rows.length === 0) {
        return res.status(404).json({ error: 'Assignment not found' });
      }

      const url = publicUrlFor(req, 'assignments', req.file.filename);
      await pool.query(
        'UPDATE assignments SET attachment_url = $1, attachment_name = $2 WHERE id = $3',
        [url, req.file.originalname, assignmentId]
      );
      res.json({ url, filename: req.file.originalname });
    } catch (dbErr) {
      next(dbErr);
    }
  });
});

// POST /api/batches/:batchId/assignments/:assignmentId/submission-attachment -> student uploads their work
router.post('/:batchId/assignments/:assignmentId/submission-attachment', requireRole('STUDENT'), (req, res, next) => {
  submissionAttachmentUpload.single('file')(req, res, async (err) => {
    if (err) {
      return res.status(400).json({ error: err.message });
    }
    if (!req.file) {
      return res.status(400).json({ error: 'No file was uploaded (expected field "file")' });
    }

    try {
      const { batchId, assignmentId } = req.params;
      if (!(await assertBatchAccess(req, res, batchId))) return;

      const assignment = await pool.query('SELECT id FROM assignments WHERE id = $1 AND batch_id = $2', [assignmentId, batchId]);
      if (assignment.rows.length === 0) {
        return res.status(404).json({ error: 'Assignment not found' });
      }

      const url = publicUrlFor(req, 'submissions', req.file.filename);
      await pool.query(
        `INSERT INTO assignment_submissions (assignment_id, student_id, is_submitted, attachment_url, attachment_name)
         VALUES ($1, $2, true, $3, $4)
         ON CONFLICT (assignment_id, student_id)
         DO UPDATE SET is_submitted = true, attachment_url = EXCLUDED.attachment_url, attachment_name = EXCLUDED.attachment_name`,
        [assignmentId, req.user.id, url, req.file.originalname]
      );
      res.json({ url, filename: req.file.originalname });
    } catch (dbErr) {
      next(dbErr);
    }
  });
});

module.exports = router;
