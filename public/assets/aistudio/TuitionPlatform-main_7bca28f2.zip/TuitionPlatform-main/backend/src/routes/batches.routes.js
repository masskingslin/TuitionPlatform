const express = require('express');
const { pool } = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');
const { isText, uuidParam } = require('../middleware/validate');

const router = express.Router();
router.use(requireAuth);
router.param('batchId', uuidParam('batchId'));

function toCourseBatch(row) {
  return {
    id: row.id,
    title: row.title,
    subject: row.subject,
    teacherName: row.teacher_name,
    scheduleTime: row.schedule_time,
    activeStudentCount: Number(row.active_student_count) || 0,
    roomOrMeetingLink: row.room_or_meeting_link || ''
  };
}

// GET /api/batches -> "my batches": teacher's own, or the student's enrolled batches
router.get('/', async (req, res, next) => {
  try {
    if (req.user.role === 'TEACHER') {
      const result = await pool.query(
        `SELECT b.id, b.title, b.subject, u.full_name AS teacher_name, b.schedule_time,
                b.room_or_meeting_link,
                (SELECT COUNT(*) FROM enrollments e WHERE e.batch_id = b.id) AS active_student_count
         FROM batches b
         JOIN users u ON u.id = b.teacher_id
         WHERE b.teacher_id = $1
         ORDER BY b.created_at DESC`,
        [req.user.id]
      );
      return res.json(result.rows.map(toCourseBatch));
    }

    const result = await pool.query(
      `SELECT b.id, b.title, b.subject, u.full_name AS teacher_name, b.schedule_time,
              b.room_or_meeting_link,
              (SELECT COUNT(*) FROM enrollments e2 WHERE e2.batch_id = b.id) AS active_student_count
       FROM batches b
       JOIN users u ON u.id = b.teacher_id
       JOIN enrollments e ON e.batch_id = b.id
       WHERE e.student_id = $1
       ORDER BY b.created_at DESC`,
      [req.user.id]
    );
    res.json(result.rows.map(toCourseBatch));
  } catch (err) {
    next(err);
  }
});

// GET /api/batches/browse -> every batch on the server, for students to discover and join
router.get('/browse', async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT b.id, b.title, b.subject, u.full_name AS teacher_name, b.schedule_time,
              b.room_or_meeting_link,
              (SELECT COUNT(*) FROM enrollments e WHERE e.batch_id = b.id) AS active_student_count
       FROM batches b
       JOIN users u ON u.id = b.teacher_id
       WHERE b.school_id = $1
       ORDER BY b.created_at DESC`,
      [req.user.schoolId]
    );
    res.json(result.rows.map(toCourseBatch));
  } catch (err) {
    next(err);
  }
});

// POST /api/batches -> create a batch (teacher only)
router.post('/', requireRole('TEACHER'), async (req, res, next) => {
  try {
    const { title, subject, scheduleTime, roomOrMeetingLink } = req.body || {};
    if (!isText(title, 120) || !isText(subject, 80) || !isText(scheduleTime, 80)) {
      return res.status(400).json({ error: 'title, subject, and scheduleTime are required (and must be reasonably short)' });
    }
    if (roomOrMeetingLink !== undefined && (typeof roomOrMeetingLink !== 'string' || roomOrMeetingLink.length > 500)) {
      return res.status(400).json({ error: 'roomOrMeetingLink must be a string of at most 500 characters' });
    }

    const result = await pool.query(
      `INSERT INTO batches (title, subject, teacher_id, schedule_time, room_or_meeting_link, school_id)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING id, title, subject, schedule_time, room_or_meeting_link`,
      [title.trim(), subject.trim(), req.user.id, scheduleTime.trim(), roomOrMeetingLink || '', req.user.schoolId]
    );

    res.status(201).json(toCourseBatch({
      ...result.rows[0],
      teacher_name: req.user.email,
      active_student_count: 0
    }));
  } catch (err) {
    next(err);
  }
});

// POST /api/batches/:batchId/enroll -> student joins a batch
router.post('/:batchId/enroll', requireRole('STUDENT'), async (req, res, next) => {
  try {
    const { batchId } = req.params;
    const batch = await pool.query('SELECT id FROM batches WHERE id = $1 AND school_id = $2', [batchId, req.user.schoolId]);
    if (batch.rows.length === 0) {
      return res.status(404).json({ error: 'Batch not found' });
    }

    await pool.query(
      `INSERT INTO enrollments (batch_id, student_id) VALUES ($1, $2)
       ON CONFLICT (batch_id, student_id) DO NOTHING`,
      [batchId, req.user.id]
    );
    res.json({ success: true });
  } catch (err) {
    next(err);
  }
});

// GET /api/batches/:batchId/students -> roster (teacher only, used for marking attendance)
router.get('/:batchId/students', requireRole('TEACHER'), async (req, res, next) => {
  try {
    const { batchId } = req.params;
    const owned = await pool.query('SELECT id FROM batches WHERE id = $1 AND teacher_id = $2', [batchId, req.user.id]);
    if (owned.rows.length === 0) {
      return res.status(403).json({ error: 'You do not teach this batch' });
    }

    const result = await pool.query(
      `SELECT u.id, u.full_name
       FROM enrollments e
       JOIN users u ON u.id = e.student_id
       WHERE e.batch_id = $1
       ORDER BY u.full_name`,
      [batchId]
    );
    res.json(result.rows.map((row) => ({ id: row.id, fullName: row.full_name })));
  } catch (err) {
    next(err);
  }
});

module.exports = router;
