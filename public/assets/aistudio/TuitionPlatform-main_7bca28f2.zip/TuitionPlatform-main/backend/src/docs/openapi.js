/**
 * OpenAPI 3 description of the API, served as interactive docs at /api/docs
 * (and raw JSON at /api/docs.json). It is built from the compact table below —
 * when you add a route, add one line here.
 *
 * Body field notation: 'string', 'integer', 'number', 'boolean', 'array', 'file';
 * a trailing '?' means optional (e.g. 'string?').
 */

const TYPES = { string: 'string', integer: 'integer', number: 'number', boolean: 'boolean', file: 'string', array: 'array' };

function schemaFor(fields, multipart = false) {
  const properties = {};
  const required = [];
  Object.entries(fields).forEach(([name, spec]) => {
    const optional = spec.endsWith('?');
    const type = spec.replace('?', '');
    if (type === 'file') properties[name] = { type: 'string', format: 'binary' };
    else if (type === 'array') properties[name] = { type: 'array', items: { type: 'object' } };
    else properties[name] = { type: TYPES[type] };
    if (!optional) required.push(name);
  });
  const schema = { type: 'object', properties };
  if (required.length > 0) schema.required = required;
  return multipart ? { 'multipart/form-data': { schema } } : { 'application/json': { schema } };
}

const T = {
  auth: 'Auth', school: 'School', batches: 'Batches', homework: 'Assignments', attendance: 'Attendance',
  fees: 'Fees', parents: 'Parents', analytics: 'Analytics', devices: 'Devices', uploads: 'Uploads', system: 'System'
};

// [method, path, summary, { tag, public, roles, body, multipart, query }]
const ENDPOINTS = [
  ['get', '/health', 'Liveness check', { tag: T.system, public: true }],

  ['post', '/api/auth/register', 'Create an account (join a school by code, or start a new school as a teacher)',
    { tag: T.auth, public: true, body: { fullName: 'string', email: 'string', password: 'string', role: 'string', schoolCode: 'string?', createSchool: 'boolean?', schoolName: 'string?' } }],
  ['post', '/api/auth/login', 'Sign in', { tag: T.auth, public: true, body: { email: 'string', password: 'string' } }],
  ['post', '/api/auth/forgot-password', 'Email a password-reset link (always succeeds)', { tag: T.auth, public: true, body: { email: 'string' } }],
  ['get', '/api/auth/me', 'Current profile, including school and avatar', { tag: T.auth }],

  ['get', '/api/school', 'Your school (join codes are shown to the school admin only)', { tag: T.school }],
  ['put', '/api/school', 'Rename the school', { tag: T.school, roles: 'School admin', body: { name: 'string' } }],
  ['post', '/api/school/regenerate-codes', 'Rotate the student/parent and/or teacher join code', { tag: T.school, roles: 'School admin', body: { which: 'string?' } }],
  ['get', '/api/school/members', 'List everyone in the school', { tag: T.school, roles: 'School admin' }],

  ['get', '/api/batches', 'My batches (teacher: ones I teach; student: ones I joined)', { tag: T.batches }],
  ['get', '/api/batches/browse', "Every batch in my school, for joining", { tag: T.batches }],
  ['post', '/api/batches', 'Create a batch', { tag: T.batches, roles: 'Teacher', body: { title: 'string', subject: 'string', scheduleTime: 'string', roomOrMeetingLink: 'string?' } }],
  ['post', '/api/batches/{batchId}/enroll', 'Join a batch', { tag: T.batches, roles: 'Student' }],
  ['get', '/api/batches/{batchId}/students', 'Batch roster', { tag: T.batches, roles: 'Teacher (owner)' }],

  ['get', '/api/batches/{batchId}/assignments', 'List assignments (students see their own status/score)', { tag: T.homework }],
  ['post', '/api/batches/{batchId}/assignments', 'Publish an assignment', { tag: T.homework, roles: 'Teacher (owner)', body: { title: 'string', dueDate: 'string', description: 'string?', maxScore: 'integer?' } }],
  ['post', '/api/batches/{batchId}/assignments/{assignmentId}/submit', 'Mark an assignment submitted', { tag: T.homework, roles: 'Student' }],
  ['get', '/api/batches/{batchId}/assignments/{assignmentId}/submissions', 'Grading roster with scores and files', { tag: T.homework, roles: 'Teacher (owner)' }],
  ['post', '/api/batches/{batchId}/assignments/{assignmentId}/grade', 'Record a score', { tag: T.homework, roles: 'Teacher (owner)', body: { studentId: 'string', scoreEarned: 'integer' } }],
  ['post', '/api/batches/{batchId}/assignments/{assignmentId}/attachment', 'Attach a file to an assignment', { tag: T.homework, roles: 'Teacher (owner)', multipart: { file: 'file' } }],
  ['post', '/api/batches/{batchId}/assignments/{assignmentId}/submission-attachment', 'Upload your work (also marks it submitted)', { tag: T.homework, roles: 'Student', multipart: { file: 'file' } }],

  ['get', '/api/batches/{batchId}/attendance', 'Attendance records (students see only their own)', { tag: T.attendance }],
  ['post', '/api/batches/{batchId}/attendance', 'Submit attendance for a date', { tag: T.attendance, roles: 'Teacher (owner)', body: { date: 'string', records: 'array' } }],

  ['get', '/api/fees', 'Fee records (student: own; teacher: their students)', { tag: T.fees }],
  ['get', '/api/fees/students', 'Students a teacher can raise a fee for', { tag: T.fees, roles: 'Teacher' }],
  ['post', '/api/fees', 'Create a fee record', { tag: T.fees, roles: 'Teacher', body: { studentId: 'string', monthYear: 'string', amountDue: 'number', dueDate: 'string' } }],
  ['post', '/api/fees/{feeId}/mark-paid', 'Mark a fee paid', { tag: T.fees, roles: 'Teacher' }],
  ['post', '/api/fees/{feeId}/checkout', 'Start an online payment (Stripe Checkout)', { tag: T.fees, roles: 'Student, or Parent of the student' }],

  ['post', '/api/parents/link-code', 'Generate a code a parent can use to link to you (valid 48h)', { tag: T.parents, roles: 'Student' }],
  ['post', '/api/parents/link', 'Link to a child using their code', { tag: T.parents, roles: 'Parent', body: { code: 'string' } }],
  ['get', '/api/parents/children', 'My linked children', { tag: T.parents, roles: 'Parent' }],
  ['delete', '/api/parents/children/{studentId}', 'Unlink a child', { tag: T.parents, roles: 'Parent' }],
  ['get', '/api/parents/my-parents', 'Parents who can see my data', { tag: T.parents, roles: 'Student' }],
  ['delete', '/api/parents/my-parents/{parentId}', "Revoke a parent's access", { tag: T.parents, roles: 'Student' }],
  ['get', '/api/parents/children/{studentId}/summary', "Child overview: attendance, fees, homework", { tag: T.parents, roles: 'Parent (linked)' }],
  ['get', '/api/parents/children/{studentId}/batches', "Child's batches", { tag: T.parents, roles: 'Parent (linked)' }],
  ['get', '/api/parents/children/{studentId}/attendance', "Child's attendance across batches", { tag: T.parents, roles: 'Parent (linked)' }],
  ['get', '/api/parents/children/{studentId}/assignments', "Child's assignments across batches", { tag: T.parents, roles: 'Parent (linked)' }],
  ['get', '/api/parents/children/{studentId}/fees', "Child's fee records", { tag: T.parents, roles: 'Parent (linked)' }],

  ['get', '/api/analytics/overview', 'Headline stats', { tag: T.analytics, roles: 'Teacher' }],
  ['get', '/api/analytics/attendance-trend', 'Daily attendance counts', { tag: T.analytics, roles: 'Teacher', query: { days: 'integer?', batchId: 'string?' } }],
  ['get', '/api/analytics/revenue-trend', 'Collected vs pending fees by month', { tag: T.analytics, roles: 'Teacher', query: { months: 'integer?' } }],
  ['get', '/api/analytics/batch-performance', 'Per-batch homework completion and attendance', { tag: T.analytics, roles: 'Teacher' }],

  ['post', '/api/devices/register', 'Register a push-notification token', { tag: T.devices, body: { fcmToken: 'string', platform: 'string?' } }],
  ['post', '/api/devices/unregister', 'Remove a push-notification token', { tag: T.devices, body: { fcmToken: 'string' } }],

  ['post', '/api/uploads/profile-photo', 'Upload a profile photo (images, 5MB max)', { tag: T.uploads, multipart: { photo: 'file' } }]
];

function buildPaths() {
  const paths = {};
  ENDPOINTS.forEach(([method, path, summary, opts = {}]) => {
    const operation = {
      tags: [opts.tag],
      summary,
      responses: { 200: { description: 'Success' } }
    };
    if (opts.roles) operation.description = `Allowed: ${opts.roles}.`;
    if (!opts.public) {
      operation.security = [{ bearerAuth: [] }];
      operation.responses[401] = { description: 'Missing, invalid or expired token' };
      if (opts.roles) operation.responses[403] = { description: 'Your role (or school) may not do this' };
    }
    operation.responses[400] = { description: 'Validation error' };

    const parameters = [...path.matchAll(/\{(\w+)\}/g)].map((m) => ({
      name: m[1], in: 'path', required: true, schema: { type: 'string', format: 'uuid' }
    }));
    Object.entries(opts.query || {}).forEach(([name, spec]) => {
      parameters.push({ name, in: 'query', required: !spec.endsWith('?'), schema: { type: TYPES[spec.replace('?', '')] } });
    });
    if (parameters.length > 0) operation.parameters = parameters;

    if (opts.body) operation.requestBody = { required: true, content: schemaFor(opts.body) };
    if (opts.multipart) operation.requestBody = { required: true, content: schemaFor(opts.multipart, true) };

    paths[path] = paths[path] || {};
    paths[path][method] = operation;
  });
  return paths;
}

const spec = {
  openapi: '3.0.3',
  info: {
    title: 'Tuition Platform API',
    version: '1.0.0',
    description:
      'REST API behind the Teacher and Student/Parent apps and the /admin web dashboard.\n\n' +
      'Sign in via `POST /api/auth/login`, then click **Authorize** and paste the returned `token`. ' +
      'Everything is scoped to the signed-in user\'s school.'
  },
  tags: Object.values(T).map((name) => ({ name })),
  components: {
    securitySchemes: { bearerAuth: { type: 'http', scheme: 'bearer', bearerFormat: 'JWT' } }
  },
  paths: buildPaths()
};

// Exposed for tests only; non-enumerable so it never appears in the served JSON.
Object.defineProperty(spec, 'ENDPOINTS', { value: ENDPOINTS, enumerable: false });

module.exports = spec;
