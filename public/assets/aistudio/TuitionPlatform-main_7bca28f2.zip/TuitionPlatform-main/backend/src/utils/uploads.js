const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const multer = require('multer');

const UPLOAD_DIR = path.join(__dirname, '..', '..', 'uploads');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const IMAGE_MIME_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
const ATTACHMENT_MIME_TYPES = [
  ...IMAGE_MIME_TYPES,
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'text/plain'
];

// The stored extension comes from the validated MIME type, never from the
// client-supplied filename. Otherwise a file named "x.html" sent as image/png
// would be saved (and later served by express.static) as HTML from our own
// origin — a stored-XSS hole next to the /admin dashboard.
const EXTENSION_FOR_MIME = {
  'image/jpeg': '.jpg',
  'image/png': '.png',
  'image/webp': '.webp',
  'image/gif': '.gif',
  'application/pdf': '.pdf',
  'application/msword': '.doc',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': '.docx',
  'text/plain': '.txt'
};

function storageFor(subfolder) {
  const dir = path.join(UPLOAD_DIR, subfolder);
  fs.mkdirSync(dir, { recursive: true });

  return multer.diskStorage({
    destination: (req, file, cb) => cb(null, dir),
    filename: (req, file, cb) => {
      const ext = EXTENSION_FOR_MIME[file.mimetype] || '';
      cb(null, `${crypto.randomUUID()}${ext}`);
    }
  });
}

function fileFilterFor(allowedMimeTypes) {
  return (req, file, cb) => {
    if (allowedMimeTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error(`Unsupported file type: ${file.mimetype}`));
    }
  };
}

const profilePhotoUpload = multer({
  storage: storageFor('avatars'),
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
  fileFilter: fileFilterFor(IMAGE_MIME_TYPES)
});

const assignmentAttachmentUpload = multer({
  storage: storageFor('assignments'),
  limits: { fileSize: 20 * 1024 * 1024 }, // 20MB
  fileFilter: fileFilterFor(ATTACHMENT_MIME_TYPES)
});

const submissionAttachmentUpload = multer({
  storage: storageFor('submissions'),
  limits: { fileSize: 20 * 1024 * 1024 }, // 20MB
  fileFilter: fileFilterFor(ATTACHMENT_MIME_TYPES)
});

/** Builds the public URL for a file multer just saved under `subfolder`. */
function publicUrlFor(req, subfolder, filename) {
  const appBaseUrl = process.env.APP_BASE_URL || `http://localhost:${process.env.PORT || 4000}`;
  return `${appBaseUrl}/uploads/${subfolder}/${filename}`;
}

/** Response headers for /uploads: never let an uploaded file execute or be sniffed as something else. */
function setUploadHeaders(res) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Content-Security-Policy', "default-src 'none'; sandbox");
}

module.exports = {
  UPLOAD_DIR,
  EXTENSION_FOR_MIME,
  setUploadHeaders,
  profilePhotoUpload,
  assignmentAttachmentUpload,
  submissionAttachmentUpload,
  publicUrlFor
};
