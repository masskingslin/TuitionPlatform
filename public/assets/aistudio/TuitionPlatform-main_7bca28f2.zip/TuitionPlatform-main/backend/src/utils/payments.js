let stripeClient = null;
let initAttempted = false;

/** Returns a configured Stripe client, or null if STRIPE_SECRET_KEY isn't set. */
function getStripeClient() {
  if (initAttempted) return stripeClient;
  initAttempted = true;

  if (!process.env.STRIPE_SECRET_KEY) {
    console.log('STRIPE_SECRET_KEY not set — online fee payments are disabled.');
    return null;
  }

  const Stripe = require('stripe');
  stripeClient = new Stripe(process.env.STRIPE_SECRET_KEY);
  return stripeClient;
}

module.exports = { getStripeClient };
