const crypto = require('crypto');

// No 0/O/1/I/L — codes get read aloud and typed by hand.
const ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';

/** Cryptographically random, human-friendly code, e.g. randomCode(7, 'S') -> "S4KZ9QWB". */
function randomCode(length, prefix = '') {
  let out = '';
  for (let i = 0; i < length; i += 1) {
    out += ALPHABET[crypto.randomInt(ALPHABET.length)];
  }
  return prefix + out;
}

const newStudentCode = () => randomCode(7, 'S');
const newTeacherCode = () => randomCode(7, 'T');

module.exports = { randomCode, newStudentCode, newTeacherCode };
