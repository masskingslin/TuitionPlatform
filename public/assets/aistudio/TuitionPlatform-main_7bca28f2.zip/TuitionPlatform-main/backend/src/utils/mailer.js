const nodemailer = require('nodemailer');

let transporter = null;

function getTransporter() {
  if (transporter) return transporter;
  if (!process.env.SMTP_HOST) return null;

  transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: process.env.SMTP_SECURE === 'true',
    auth: process.env.SMTP_USER
      ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASSWORD }
      : undefined
  });
  return transporter;
}

async function sendPasswordResetEmail(toEmail, resetUrl) {
  const from = process.env.SMTP_FROM || 'no-reply@tuition-platform.local';
  const subject = 'Reset your Tuition Platform password';
  const text = `We received a request to reset your password.\n\n` +
    `Reset it here (this link expires in 1 hour): ${resetUrl}\n\n` +
    `If you didn't request this, you can safely ignore this email.`;
  const html = `
    <p>We received a request to reset your password.</p>
    <p><a href="${resetUrl}">Click here to reset your password</a> (this link expires in 1 hour).</p>
    <p>If you didn't request this, you can safely ignore this email.</p>
  `;

  const client = getTransporter();
  if (!client) {
    // No SMTP configured — log it so local/dev setups still work end to end.
    console.log('--- SMTP not configured; would have sent this email ---');
    console.log(`To: ${toEmail}`);
    console.log(`Subject: ${subject}`);
    console.log(`Reset URL: ${resetUrl}`);
    console.log('---------------------------------------------------------');
    return;
  }

  await client.sendMail({ from, to: toEmail, subject, text, html });
}

module.exports = { sendPasswordResetEmail };
