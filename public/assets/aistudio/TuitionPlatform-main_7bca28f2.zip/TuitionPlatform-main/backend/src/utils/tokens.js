const jwt = require('jsonwebtoken');

/** `user` needs: id, role, email, schoolId. The school is embedded so every request is school-scoped without an extra lookup. */
function signToken(user) {
  return jwt.sign(
    { sub: user.id, role: user.role, email: user.email, sid: user.schoolId },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
  );
}

module.exports = { signToken };
