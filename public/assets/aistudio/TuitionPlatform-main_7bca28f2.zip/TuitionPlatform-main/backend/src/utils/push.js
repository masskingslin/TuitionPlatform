const { pool } = require('../db');

let messaging = null;
let initAttempted = false;

function getMessaging() {
  if (initAttempted) return messaging;
  initAttempted = true;

  const raw = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
  if (!raw) {
    console.log('FIREBASE_SERVICE_ACCOUNT_JSON not set — push notifications are disabled (logged instead).');
    return null;
  }

  try {
    const admin = require('firebase-admin');
    // Accept either raw JSON or base64-encoded JSON (base64 is much easier
    // to paste into a single .env line than a multi-line JSON blob).
    const jsonText = raw.trim().startsWith('{') ? raw : Buffer.from(raw, 'base64').toString('utf8');
    const serviceAccount = JSON.parse(jsonText);
    admin.initializeApp({ credential: admin.credential.cert(serviceAccount) });
    messaging = admin.messaging();
    return messaging;
  } catch (err) {
    console.error('Failed to initialize Firebase Admin — push notifications are disabled:', err.message);
    return null;
  }
}

/** Registers (or re-registers) a device's FCM token against a user. */
async function registerDeviceToken(userId, fcmToken, platform) {
  await pool.query(
    `INSERT INTO device_tokens (user_id, fcm_token, platform)
     VALUES ($1, $2, $3)
     ON CONFLICT (fcm_token) DO UPDATE SET user_id = EXCLUDED.user_id, platform = EXCLUDED.platform`,
    [userId, fcmToken, platform || 'android']
  );
}

async function removeDeviceToken(fcmToken) {
  await pool.query('DELETE FROM device_tokens WHERE fcm_token = $1', [fcmToken]);
}

/** Sends a notification to every device registered for one user. */
async function sendPushToUser(userId, title, body, data = {}) {
  return sendPushToUsers([userId], title, body, data);
}

/** Sends a notification to every device registered for a list of users. */
async function sendPushToUsers(userIds, title, body, data = {}) {
  if (userIds.length === 0) return;

  const result = await pool.query(
    'SELECT fcm_token FROM device_tokens WHERE user_id = ANY($1)',
    [userIds]
  );
  const tokens = result.rows.map((row) => row.fcm_token);
  if (tokens.length === 0) return;

  const client = getMessaging();
  if (!client) {
    console.log(`--- Push (not sent, FCM unconfigured) --- "${title}": ${body} -> ${tokens.length} device(s)`);
    return;
  }

  const stringData = Object.fromEntries(Object.entries(data).map(([k, v]) => [k, String(v)]));

  try {
    const response = await client.sendEachForMulticast({
      tokens,
      notification: { title, body },
      data: stringData
    });

    // Clean up tokens that are no longer valid (app uninstalled, etc.)
    const deadTokens = [];
    response.responses.forEach((r, i) => {
      if (!r.success && r.error && ['messaging/registration-token-not-registered', 'messaging/invalid-registration-token'].includes(r.error.code)) {
        deadTokens.push(tokens[i]);
      }
    });
    if (deadTokens.length > 0) {
      await pool.query('DELETE FROM device_tokens WHERE fcm_token = ANY($1)', [deadTokens]);
    }
  } catch (err) {
    console.error('Failed to send push notification:', err.message);
  }
}

/**
 * Notifies the given students AND every parent linked to any of them.
 * Used for events a parent also cares about (grades, absences, new homework, payments).
 */
async function sendPushToStudentsAndParents(studentIds, title, body, data = {}) {
  if (studentIds.length === 0) return;
  const parents = await pool.query(
    'SELECT DISTINCT parent_id FROM parent_students WHERE student_id = ANY($1)',
    [studentIds]
  );
  const recipients = [...new Set([...studentIds, ...parents.rows.map((row) => row.parent_id)])];
  return sendPushToUsers(recipients, title, body, data);
}

/**
 * Runs a notification AFTER the HTTP response has been sent, and makes sure a
 * failure can never surface as an unhandled rejection or a late next(err).
 */
function notifyInBackground(task) {
  Promise.resolve()
    .then(task)
    .catch((err) => console.error('Push notification failed:', err.message));
}

module.exports = {
  registerDeviceToken,
  removeDeviceToken,
  sendPushToUser,
  sendPushToUsers,
  sendPushToStudentsAndParents,
  notifyInBackground
};
