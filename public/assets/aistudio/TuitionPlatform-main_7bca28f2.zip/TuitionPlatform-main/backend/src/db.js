require('dotenv').config();
const { Pool, types } = require('pg');

// Return DATE columns as plain "YYYY-MM-DD" strings. By default node-pg turns
// them into local-midnight JS Dates, and calling toISOString() on those can
// land on the previous day when the server isn't running in UTC.
types.setTypeParser(1082, (value) => value);

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_SSL === 'true' ? { rejectUnauthorized: false } : false
});

module.exports = { pool };
