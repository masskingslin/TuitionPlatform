const path = require('path');
const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const swaggerUi = require('swagger-ui-express');

const authRoutes = require('./routes/auth.routes');
const schoolRoutes = require('./routes/school.routes');
const batchesRoutes = require('./routes/batches.routes');
const assignmentsRoutes = require('./routes/assignments.routes');
const attendanceRoutes = require('./routes/attendance.routes');
const feesRoutes = require('./routes/fees.routes');
const parentsRoutes = require('./routes/parents.routes');
const devicesRoutes = require('./routes/devices.routes');
const analyticsRoutes = require('./routes/analytics.routes');
const uploadsRoutes = require('./routes/uploads.routes');
const webPagesRoutes = require('./routes/web-pages.routes');
const stripeWebhookRoutes = require('./routes/stripe-webhook.routes');
const adminDashboardRoutes = require('./routes/admin-dashboard.routes');
const openapiSpec = require('./docs/openapi');
const { setUploadHeaders } = require('./utils/uploads');

function limiter({ windowMs, limit, message, keyGenerator, skipSuccessfulRequests }) {
  return rateLimit({
    windowMs,
    limit,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    skipSuccessfulRequests: Boolean(skipSuccessfulRequests),
    ...(keyGenerator ? { keyGenerator } : {}),
    message: { error: message }
  });
}

function corsMiddleware() {
  const origins = (process.env.CORS_ORIGINS || '').split(',').map((s) => s.trim()).filter(Boolean);
  // The mobile apps aren't affected by CORS; this only matters for browsers.
  // With CORS_ORIGINS unset we stay permissive (backwards compatible).
  if (origins.length === 0) return cors();
  return cors({ origin: (origin, cb) => cb(null, !origin || origins.includes(origin)) });
}

/**
 * Builds the Express app without touching the database or opening a port, so
 * tests can exercise the real middleware stack. `options` override the
 * rate-limit settings that otherwise come from environment variables.
 */
function createApp(options = {}) {
  const app = express();

  const trustProxy = process.env.TRUST_PROXY;
  if (trustProxy) {
    app.set('trust proxy', /^\d+$/.test(trustProxy) ? Number(trustProxy) : trustProxy === 'true' ? true : trustProxy);
  }

  const windowMs = options.rateLimitWindowMs ?? Number(process.env.RATE_LIMIT_WINDOW_MS || 15 * 60 * 1000);
  const apiMax = options.apiLimit ?? Number(process.env.API_RATE_LIMIT_MAX || 3000);
  const authIpMax = options.authIpLimit ?? Number(process.env.AUTH_IP_RATE_LIMIT_MAX || 300);
  const loginMax = options.loginLimit ?? Number(process.env.LOGIN_RATE_LIMIT_MAX || 10);
  const forgotMax = options.forgotLimit ?? Number(process.env.FORGOT_RATE_LIMIT_MAX || 5);

  app.use(helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        // The admin dashboard and the small server-rendered pages use inline
        // <script>/<style>; the mobile apps never render HTML.
        scriptSrc: ["'self'", "'unsafe-inline'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        imgSrc: ["'self'", 'data:', 'https:'],
        connectSrc: ["'self'", 'http:', 'https:'],
        objectSrc: ["'none'"],
        frameAncestors: ["'none'"],
        formAction: ["'self'"],
        upgradeInsecureRequests: null // would break plain-http self-hosted setups
      }
    },
    crossOriginResourcePolicy: { policy: 'cross-origin' }
  }));
  app.use(corsMiddleware());
  if (process.env.NODE_ENV !== 'test') app.use(morgan('tiny'));

  // Stripe's webhook needs the raw body for signature verification, so it
  // is mounted before express.json() — and before rate limiting, since
  // Stripe may legitimately retry in bursts.
  app.use('/webhooks/stripe', express.raw({ type: 'application/json' }), stripeWebhookRoutes);

  app.use(express.json({ limit: '100kb' }));
  app.use(express.urlencoded({ extended: true, limit: '100kb' }));

  app.get('/health', (req, res) => res.json({ status: 'ok' }));

  app.use('/uploads', express.static(path.join(__dirname, '..', 'uploads'), {
    setHeaders: setUploadHeaders,
    index: false,
    dotfiles: 'ignore'
  }));

  if (process.env.ENABLE_API_DOCS !== 'false') {
    app.get('/api/docs.json', (req, res) => res.json(openapiSpec));
    app.use('/api/docs', swaggerUi.serve, swaggerUi.setup(openapiSpec, { customSiteTitle: 'Tuition Platform API' }));
  }

  // --- Rate limiting -------------------------------------------------
  // A school's students often share one IP (school Wi-Fi), so the coarse
  // per-IP limits are generous; brute-force protection comes from the
  // per-account limits keyed by IP + email.
  const emailKey = (req) => `${req.ip}|${String(req.body?.email || '').trim().toLowerCase()}`;
  const authPaths = ['/api/auth/login', '/api/auth/register', '/api/auth/forgot-password', '/reset-password'];

  app.post(authPaths, limiter({
    windowMs, limit: authIpMax, message: 'Too many attempts from this network. Please wait a while and try again.'
  }));
  app.post('/api/auth/login', limiter({
    windowMs, limit: loginMax, skipSuccessfulRequests: true, keyGenerator: emailKey,
    message: 'Too many failed sign-in attempts for this account. Please wait a while and try again.'
  }));
  app.post('/api/auth/forgot-password', limiter({
    windowMs, limit: forgotMax, keyGenerator: emailKey,
    message: 'Too many password reset requests. Please wait a while and try again.'
  }));
  // Parent link codes are short; keep guessing impractical.
  app.post('/api/parents/link', limiter({
    windowMs, limit: options.linkLimit ?? Number(process.env.LINK_RATE_LIMIT_MAX || 20),
    message: 'Too many link attempts. Please wait a while and try again.'
  }));
  app.use('/api', limiter({
    windowMs, limit: apiMax, message: 'Too many requests. Please slow down.'
  }));

  app.use('/', webPagesRoutes);
  app.use('/admin', adminDashboardRoutes);

  app.use('/api/auth', authRoutes);
  app.use('/api/school', schoolRoutes);
  app.use('/api/batches', batchesRoutes);
  app.use('/api/batches', assignmentsRoutes);
  app.use('/api/batches', attendanceRoutes);
  app.use('/api/fees', feesRoutes);
  app.use('/api/parents', parentsRoutes);
  app.use('/api/devices', devicesRoutes);
  app.use('/api/analytics', analyticsRoutes);
  app.use('/api/uploads', uploadsRoutes);

  app.use((req, res) => {
    res.status(404).json({ error: 'Not found' });
  });

  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    // Body-parser errors (bad JSON, payload too large) are the client's fault, not a 500.
    if (err.type === 'entity.too.large') return res.status(413).json({ error: 'Request body too large' });
    if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Malformed JSON body' });
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  });

  return app;
}

module.exports = { createApp };
