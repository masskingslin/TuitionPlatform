// Valid v4-style UUIDs for tests. Route params and body IDs are validated as
// UUIDs now, so short placeholders like "b1" would be rejected with a 400.
const { signToken } = require('../src/utils/tokens');

const ID = {
  school: '11111111-1111-4111-8111-111111111111',
  otherSchool: '22222222-2222-4222-8222-222222222222',
  teacher: 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa',
  student: 'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb',
  student2: 'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbb2',
  parent: 'cccccccc-cccc-4ccc-8ccc-cccccccccccc',
  batch: 'dddddddd-dddd-4ddd-8ddd-dddddddddddd',
  assignment: 'eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee',
  fee: 'ffffffff-ffff-4fff-8fff-ffffffffffff'
};

function tokenFor(role, id, schoolId = ID.school) {
  return signToken({ id, role, email: `${role.toLowerCase()}@example.com`, schoolId });
}

const teacherToken = tokenFor('TEACHER', ID.teacher);
const studentToken = tokenFor('STUDENT', ID.student);
const parentToken = tokenFor('PARENT', ID.parent);

module.exports = { ID, tokenFor, teacherToken, studentToken, parentToken };
