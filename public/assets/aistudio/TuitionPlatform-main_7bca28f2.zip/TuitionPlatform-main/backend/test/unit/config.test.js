const { assertSecureConfig, assertSafeAdminPassword } = require('../../src/config');

const GOOD_SECRET = 'a'.repeat(40);

describe('assertSecureConfig', () => {
  it('throws in production when JWT_SECRET is missing', () => {
    expect(() => assertSecureConfig({ NODE_ENV: 'production' })).toThrow(/JWT_SECRET/);
  });
  it('throws in production for a short secret', () => {
    expect(() => assertSecureConfig({ NODE_ENV: 'production', JWT_SECRET: 'short' })).toThrow();
  });
  it('throws in production for a known placeholder, even if long enough', () => {
    expect(() => assertSecureConfig({ NODE_ENV: 'production', JWT_SECRET: 'change-this-to-a-long-random-string' })).toThrow(/placeholder/);
  });
  it('accepts a strong secret in production', () => {
    expect(assertSecureConfig({ NODE_ENV: 'production', JWT_SECRET: GOOD_SECRET, APP_BASE_URL: 'https://api.example.com' })).toEqual([]);
  });
  it('warns about plain-http public URLs in production, but does not throw', () => {
    const warnings = assertSecureConfig({ NODE_ENV: 'production', JWT_SECRET: GOOD_SECRET, APP_BASE_URL: 'http://api.example.com' });
    expect(warnings.join(' ')).toMatch(/https/i);
  });
  it('only warns (never throws) outside production', () => {
    const warnings = assertSecureConfig({ NODE_ENV: 'development', JWT_SECRET: 'short' });
    expect(warnings.length).toBeGreaterThan(0);
  });
});

describe('assertSafeAdminPassword', () => {
  it('rejects default and short passwords in production', () => {
    expect(() => assertSafeAdminPassword('admin123', { NODE_ENV: 'production' })).toThrow();
    expect(() => assertSafeAdminPassword('change-me-now', { NODE_ENV: 'production' })).toThrow();
    expect(() => assertSafeAdminPassword('short', { NODE_ENV: 'production' })).toThrow();
  });
  it('accepts a strong password in production', () => {
    expect(() => assertSafeAdminPassword('Tr0ub4dor&3-horse', { NODE_ENV: 'production' })).not.toThrow();
  });
  it('allows anything outside production, for easy local setup', () => {
    expect(() => assertSafeAdminPassword('admin123', { NODE_ENV: 'development' })).not.toThrow();
  });
});
