const spec = require('../../src/docs/openapi');

describe('OpenAPI spec', () => {
  it('is a valid-looking OpenAPI 3 document with bearer auth', () => {
    expect(spec.openapi).toMatch(/^3\./);
    expect(spec.components.securitySchemes.bearerAuth.scheme).toBe('bearer');
  });

  it('describes every endpoint it lists, with summaries and responses', () => {
    spec.ENDPOINTS.forEach(([method, path, summary]) => {
      const op = spec.paths[path][method];
      expect(op).toBeDefined();
      expect(op.summary).toBe(summary);
      expect(op.responses[200]).toBeDefined();
    });
  });

  it('declares a path parameter for every {placeholder}', () => {
    Object.entries(spec.paths).forEach(([path, methods]) => {
      const placeholders = [...path.matchAll(/\{(\w+)\}/g)].map((m) => m[1]);
      Object.values(methods).forEach((op) => {
        expect((op.parameters || []).filter((p) => p.in === 'path').map((p) => p.name).sort()).toEqual(placeholders.sort());
      });
    });
  });

  it('requires auth everywhere except the explicitly public endpoints', () => {
    const publicPaths = ['/health', '/api/auth/register', '/api/auth/login', '/api/auth/forgot-password'];
    Object.entries(spec.paths).forEach(([path, methods]) => {
      Object.values(methods).forEach((op) => {
        if (publicPaths.includes(path)) expect(op.security).toBeUndefined();
        else expect(op.security).toEqual([{ bearerAuth: [] }]);
      });
    });
  });

  it('documents the school, parent and upload features', () => {
    ['/api/school', '/api/parents/link', '/api/parents/children/{studentId}/summary', '/api/uploads/profile-photo']
      .forEach((p) => expect(spec.paths[p]).toBeDefined());
  });

  it('does not leak its internal endpoint table into the served JSON', () => {
    expect(JSON.stringify(spec)).not.toContain('ENDPOINTS');
  });
});
