const { randomCode, newStudentCode, newTeacherCode } = require('../../src/utils/codes');

describe('join code generation', () => {
  it('student codes start with S, teacher codes with T, both 8 characters', () => {
    expect(newStudentCode()).toMatch(/^S[A-Z0-9]{7}$/);
    expect(newTeacherCode()).toMatch(/^T[A-Z0-9]{7}$/);
  });
  it('avoids look-alike characters (0, O, 1, I, L)', () => {
    const sample = Array.from({ length: 300 }, () => randomCode(8)).join('');
    expect(sample).not.toMatch(/[01OIL]/);
  });
  it('produces varied codes', () => {
    const codes = new Set(Array.from({ length: 200 }, () => randomCode(8)));
    expect(codes.size).toBe(200);
  });
});
