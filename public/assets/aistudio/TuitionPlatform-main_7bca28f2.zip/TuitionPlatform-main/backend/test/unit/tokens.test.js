const jwt = require('jsonwebtoken');
const { signToken } = require('../../src/utils/tokens');

describe('signToken', () => {
  it('produces a JWT that decodes back to the given claims, including the school', () => {
    const token = signToken({ id: 'user-123', role: 'TEACHER', email: 'teacher@example.com', schoolId: 'school-9' });
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    expect(decoded.sub).toBe('user-123');
    expect(decoded.role).toBe('TEACHER');
    expect(decoded.email).toBe('teacher@example.com');
    expect(decoded.sid).toBe('school-9');
  });

  it('sets an expiry in the future', () => {
    const token = signToken({ id: 'user-1', role: 'STUDENT', email: 'a@b.com', schoolId: 's' });
    const decoded = jwt.decode(token);
    expect(decoded.exp).toBeGreaterThan(Math.floor(Date.now() / 1000));
  });

  it('fails verification against a different secret', () => {
    const token = signToken({ id: 'user-1', role: 'STUDENT', email: 'a@b.com', schoolId: 's' });
    expect(() => jwt.verify(token, 'wrong-secret')).toThrow();
  });
});
