const jwt = require('jsonwebtoken');
const { requireAuth, requireRole } = require('../../src/middleware/auth');
const { signToken } = require('../../src/utils/tokens');

function mockRes() {
  const res = {};
  res.status = jest.fn().mockReturnValue(res);
  res.json = jest.fn().mockReturnValue(res);
  return res;
}

describe('requireAuth', () => {
  it('rejects requests with no Authorization header', () => {
    const res = mockRes();
    const next = jest.fn();
    requireAuth({ headers: {} }, res, next);
    expect(res.status).toHaveBeenCalledWith(401);
    expect(next).not.toHaveBeenCalled();
  });

  it('rejects an invalid token', () => {
    const res = mockRes();
    const next = jest.fn();
    requireAuth({ headers: { authorization: 'Bearer not-a-real-token' } }, res, next);
    expect(res.status).toHaveBeenCalledWith(401);
    expect(next).not.toHaveBeenCalled();
  });

  it('rejects an expired token', () => {
    const expired = jwt.sign({ sub: 'u1', role: 'TEACHER', email: 'a@b.com', sid: 's1' }, process.env.JWT_SECRET, { expiresIn: -10 });
    const res = mockRes();
    const next = jest.fn();
    requireAuth({ headers: { authorization: `Bearer ${expired}` } }, res, next);
    expect(res.status).toHaveBeenCalledWith(401);
    expect(next).not.toHaveBeenCalled();
  });

  it('rejects a token signed with a different secret', () => {
    const forged = jwt.sign({ sub: 'u1', role: 'TEACHER', email: 'a@b.com', sid: 's1' }, 'attacker-secret');
    const res = mockRes();
    const next = jest.fn();
    requireAuth({ headers: { authorization: `Bearer ${forged}` } }, res, next);
    expect(res.status).toHaveBeenCalledWith(401);
    expect(next).not.toHaveBeenCalled();
  });

  it('rejects a legacy token that carries no school, asking the user to sign in again', () => {
    const legacy = jwt.sign({ sub: 'u1', role: 'TEACHER', email: 'a@b.com' }, process.env.JWT_SECRET);
    const res = mockRes();
    const next = jest.fn();
    requireAuth({ headers: { authorization: `Bearer ${legacy}` } }, res, next);
    expect(res.status).toHaveBeenCalledWith(401);
    expect(res.json).toHaveBeenCalledWith({ error: 'Session expired, please sign in again' });
    expect(next).not.toHaveBeenCalled();
  });

  it('accepts a valid token and attaches req.user with the school', () => {
    const token = signToken({ id: 'u1', role: 'TEACHER', email: 'a@b.com', schoolId: 's1' });
    const req = { headers: { authorization: `Bearer ${token}` } };
    const next = jest.fn();
    requireAuth(req, mockRes(), next);
    expect(next).toHaveBeenCalledTimes(1);
    expect(req.user).toEqual({ id: 'u1', role: 'TEACHER', email: 'a@b.com', schoolId: 's1' });
  });
});

describe('requireRole', () => {
  it('allows a matching role through', () => {
    const next = jest.fn();
    requireRole('TEACHER')({ user: { role: 'TEACHER' } }, mockRes(), next);
    expect(next).toHaveBeenCalledTimes(1);
  });

  it('rejects a non-matching role with 403', () => {
    const res = mockRes();
    const next = jest.fn();
    requireRole('TEACHER')({ user: { role: 'STUDENT' } }, res, next);
    expect(res.status).toHaveBeenCalledWith(403);
    expect(next).not.toHaveBeenCalled();
  });

  it('rejects a parent from teacher-only routes', () => {
    const res = mockRes();
    requireRole('TEACHER')({ user: { role: 'PARENT' } }, res, jest.fn());
    expect(res.status).toHaveBeenCalledWith(403);
  });

  it('accepts any of multiple allowed roles', () => {
    const next = jest.fn();
    requireRole('STUDENT', 'PARENT')({ user: { role: 'PARENT' } }, mockRes(), next);
    expect(next).toHaveBeenCalledTimes(1);
  });
});
