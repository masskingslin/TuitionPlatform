const { isUuid, isEmail, isText, uuidParam } = require('../../src/middleware/validate');

describe('isUuid', () => {
  it('accepts a real UUID, any case', () => {
    expect(isUuid('11111111-1111-4111-8111-111111111111')).toBe(true);
    expect(isUuid('AAAAAAAA-AAAA-4AAA-8AAA-AAAAAAAAAAAA')).toBe(true);
  });
  it('rejects non-UUIDs, SQL-ish strings and non-strings', () => {
    expect(isUuid('b1')).toBe(false);
    expect(isUuid("1' OR '1'='1")).toBe(false);
    expect(isUuid('')).toBe(false);
    expect(isUuid(undefined)).toBe(false);
    expect(isUuid(123)).toBe(false);
    expect(isUuid(['11111111-1111-4111-8111-111111111111'])).toBe(false);
  });
});

describe('isEmail', () => {
  it('accepts normal addresses', () => {
    expect(isEmail('a@b.com')).toBe(true);
    expect(isEmail('first.last+tag@school.example.org')).toBe(true);
  });
  it('rejects malformed, spaced or oversized addresses', () => {
    expect(isEmail('nope')).toBe(false);
    expect(isEmail('a@b')).toBe(false);
    expect(isEmail('a b@c.com')).toBe(false);
    expect(isEmail(`${'x'.repeat(250)}@b.com`)).toBe(false);
    expect(isEmail(null)).toBe(false);
  });
});

describe('isText', () => {
  it('accepts non-empty strings within the limit', () => {
    expect(isText('hello', 10)).toBe(true);
  });
  it('rejects blank, too-long and non-string values', () => {
    expect(isText('   ', 10)).toBe(false);
    expect(isText('x'.repeat(11), 10)).toBe(false);
    expect(isText({}, 10)).toBe(false);
    expect(isText(undefined, 10)).toBe(false);
  });
});

describe('uuidParam', () => {
  it('calls next() for a valid id', () => {
    const next = jest.fn();
    uuidParam('batchId')({}, {}, next, '11111111-1111-4111-8111-111111111111');
    expect(next).toHaveBeenCalled();
  });
  it('answers 400 for an invalid id without calling next()', () => {
    const res = { status: jest.fn().mockReturnThis(), json: jest.fn() };
    const next = jest.fn();
    uuidParam('batchId')({}, res, next, 'not-a-uuid');
    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith({ error: 'Invalid batchId' });
    expect(next).not.toHaveBeenCalled();
  });
});
