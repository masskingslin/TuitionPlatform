// Runs before every test file. Keeps tests deterministic and offline:
// - a fixed JWT secret so tokens are verifiable within a test run
// - SMTP/Firebase/Stripe left unset so those utils take their "unconfigured"
//   no-op code path instead of attempting any real network call
process.env.JWT_SECRET = 'test-secret-do-not-use-in-production';
process.env.JWT_EXPIRES_IN = '1h';
delete process.env.SMTP_HOST;
delete process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
delete process.env.STRIPE_SECRET_KEY;
