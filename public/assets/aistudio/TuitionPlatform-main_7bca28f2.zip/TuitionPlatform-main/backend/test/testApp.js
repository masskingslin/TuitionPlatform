const express = require('express');

/** Wraps a router in a bare Express app with JSON body parsing — no DB, no listen(). */
function buildTestApp(basePath, router) {
  const app = express();
  app.use(express.json());
  app.use(basePath, router);
  // Minimal error handler matching index.js's shape, so thrown errors in
  // routes surface as a clean 500 instead of Express's default HTML page.
  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    res.status(500).json({ error: err.message || 'Internal server error' });
  });
  return app;
}

module.exports = { buildTestApp };
