const request = require('supertest');

jest.mock('../../src/db', () => ({
  pool: { query: jest.fn() }
}));

const { pool } = require('../../src/db');
const parentsRoutes = require('../../src/routes/parents.routes');
const { buildTestApp } = require('../testApp');
const { ID, tokenFor, teacherToken, studentToken, parentToken } = require('../ids');

const app = buildTestApp('/api/parents', parentsRoutes);
const auth = (token) => ({ Authorization: `Bearer ${token}` });
const child = `/api/parents/children/${ID.student}`;

beforeEach(() => {
  pool.query.mockReset();
});

const linked = () => pool.query.mockResolvedValueOnce({ rows: [{ x: 1 }] });
const notLinked = () => pool.query.mockResolvedValueOnce({ rows: [] });

describe('POST /api/parents/link-code (student)', () => {
  it.each([['parent', parentToken], ['teacher', teacherToken]])('is not available to a %s', async (_w, token) => {
    expect((await request(app).post('/api/parents/link-code').set(auth(token))).status).toBe(403);
  });

  it('replaces any earlier code and returns a fresh 8-character code valid for ~48 hours', async () => {
    pool.query.mockResolvedValue({ rows: [] });
    const before = Date.now();
    const res = await request(app).post('/api/parents/link-code').set(auth(studentToken));

    expect(res.status).toBe(201);
    expect(res.body.code).toMatch(/^[A-Z2-9]{8}$/);
    const hours = (new Date(res.body.expiresAt).getTime() - before) / 3600000;
    expect(hours).toBeGreaterThan(47.9);
    expect(hours).toBeLessThan(48.1);

    expect(pool.query.mock.calls[0][0]).toMatch(/DELETE FROM parent_link_codes/);
    expect(pool.query.mock.calls[0][1]).toEqual([ID.student]);
    expect(pool.query.mock.calls[1][1][0]).toBe(res.body.code);
    expect(pool.query.mock.calls[1][1][1]).toBe(ID.student);
  });
});

describe('POST /api/parents/link (parent)', () => {
  it('is parent-only', async () => {
    expect((await request(app).post('/api/parents/link').set(auth(studentToken)).send({ code: 'ABCD2345' })).status).toBe(403);
  });

  it.each([[{}], [{ code: '' }], [{ code: 123 }], [{ code: 'x'.repeat(30) }]])('rejects the body %j', async (body) => {
    expect((await request(app).post('/api/parents/link').set(auth(parentToken)).send(body)).status).toBe(400);
  });

  it('rejects an unknown or expired code', async () => {
    pool.query.mockResolvedValueOnce({ rows: [] });
    const res = await request(app).post('/api/parents/link').set(auth(parentToken)).send({ code: 'ABCD2345' });
    expect(res.status).toBe(400);
    expect(res.body.error).toMatch(/invalid or has expired/);
  });

  it("looks codes up case-insensitively and only counts unexpired ones", async () => {
    pool.query.mockResolvedValueOnce({ rows: [] });
    await request(app).post('/api/parents/link').set(auth(parentToken)).send({ code: ' abcd2345 ' });
    expect(pool.query.mock.calls[0][1]).toEqual(['ABCD2345']);
    expect(pool.query.mock.calls[0][0]).toMatch(/expires_at > now\(\)/);
  });

  it("refuses a code from a student at ANOTHER school, with the same message as an invalid code", async () => {
    pool.query.mockResolvedValueOnce({ rows: [{ student_id: ID.student, full_name: 'Alice', avatar_url: null, school_id: ID.otherSchool }] });
    const res = await request(app).post('/api/parents/link').set(auth(parentToken)).send({ code: 'ABCD2345' });

    expect(res.status).toBe(400);
    expect(res.body.error).toMatch(/invalid or has expired/);
    expect(pool.query).toHaveBeenCalledTimes(1); // never reached the INSERT
  });

  it('links the parent to the student from the same school', async () => {
    pool.query
      .mockResolvedValueOnce({ rows: [{ student_id: ID.student, full_name: 'Alice', avatar_url: 'https://x/a.png', school_id: ID.school }] })
      .mockResolvedValueOnce({ rows: [] });
    const res = await request(app).post('/api/parents/link').set(auth(parentToken)).send({ code: 'ABCD2345' });

    expect(res.status).toBe(201);
    expect(res.body).toEqual({ id: ID.student, fullName: 'Alice', avatarUrl: 'https://x/a.png' });
    expect(pool.query.mock.calls[1][1]).toEqual([ID.parent, ID.student]);
  });
});

describe('children list, unlink and revoke', () => {
  it('lists the parent\'s own children only', async () => {
    pool.query.mockResolvedValueOnce({ rows: [{ id: ID.student, full_name: 'Alice', avatar_url: null }] });
    const res = await request(app).get('/api/parents/children').set(auth(parentToken));
    expect(res.body).toEqual([{ id: ID.student, fullName: 'Alice', avatarUrl: null }]);
    expect(pool.query.mock.calls[0][1]).toEqual([ID.parent]);
  });

  it('students cannot list children', async () => {
    expect((await request(app).get('/api/parents/children').set(auth(studentToken))).status).toBe(403);
  });

  it('a parent can unlink themselves — scoped to their own id', async () => {
    pool.query.mockResolvedValueOnce({ rows: [] });
    const res = await request(app).delete(child).set(auth(parentToken));
    expect(res.status).toBe(200);
    expect(pool.query.mock.calls[0][1]).toEqual([ID.parent, ID.student]);
  });

  it('a student sees who can view their data', async () => {
    pool.query.mockResolvedValueOnce({ rows: [{ id: ID.parent, full_name: 'Pat', email: 'pat@x.com' }] });
    const res = await request(app).get('/api/parents/my-parents').set(auth(studentToken));
    expect(res.body).toEqual([{ id: ID.parent, fullName: 'Pat', email: 'pat@x.com' }]);
  });

  it("a student can revoke a parent's access — scoped to their own id", async () => {
    pool.query.mockResolvedValueOnce({ rows: [] });
    const res = await request(app).delete(`/api/parents/my-parents/${ID.parent}`).set(auth(studentToken));
    expect(res.status).toBe(200);
    expect(pool.query.mock.calls[0][1]).toEqual([ID.student, ID.parent]);
  });

  it('a parent cannot revoke on a student\'s behalf', async () => {
    expect((await request(app).delete(`/api/parents/my-parents/${ID.parent}`).set(auth(parentToken))).status).toBe(403);
  });
});

describe('access control on child data', () => {
  const endpoints = ['summary', 'batches', 'attendance', 'assignments', 'fees'];

  it.each(endpoints)('%s: students and teachers are refused outright', async (endpoint) => {
    expect((await request(app).get(`${child}/${endpoint}`).set(auth(studentToken))).status).toBe(403);
    expect((await request(app).get(`${child}/${endpoint}`).set(auth(teacherToken))).status).toBe(403);
    expect(pool.query).not.toHaveBeenCalled();
  });

  it.each(endpoints)("%s: a parent who is NOT linked to that child gets 404 and no data", async (endpoint) => {
    notLinked();
    const res = await request(app).get(`${child}/${endpoint}`).set(auth(parentToken));
    expect(res.status).toBe(404);
    expect(pool.query).toHaveBeenCalledTimes(1);
    expect(pool.query.mock.calls[0][1]).toEqual([ID.parent, ID.student]);
  });

  it('rejects a malformed child id', async () => {
    expect((await request(app).get('/api/parents/children/not-a-uuid/summary').set(auth(parentToken))).status).toBe(400);
  });

  it("a parent linked to child A cannot read child B (the link is checked per child)", async () => {
    notLinked();
    const res = await request(app).get(`/api/parents/children/${ID.student2}/fees`).set(auth(parentToken));
    expect(res.status).toBe(404);
    expect(pool.query.mock.calls[0][1]).toEqual([ID.parent, ID.student2]);
  });

  it('another parent\'s token cannot read the child either', async () => {
    const otherParent = tokenFor('PARENT', 'cccccccc-cccc-4ccc-8ccc-ccccccccccc2');
    notLinked();
    expect((await request(app).get(`${child}/summary`).set(auth(otherParent))).status).toBe(404);
  });
});

describe('GET child summary', () => {
  const mockSummary = ({ graded = 3 } = {}) => {
    linked();
    pool.query
      .mockResolvedValueOnce({ rows: [{ id: ID.student, full_name: 'Alice', avatar_url: null }] })
      .mockResolvedValueOnce({ rows: [{ status: 'PRESENT', count: 8 }, { status: 'ABSENT', count: 1 }, { status: 'LATE', count: 1 }] })
      .mockResolvedValueOnce({ rows: [{ total_due: 3000, total_paid: 1000, overdue: 1 }] })
      .mockResolvedValueOnce({ rows: [{ total: 5, submitted: 4, graded, average_rate: graded ? 0.85 : null }] });
  };

  it('combines attendance, fees and homework into one overview', async () => {
    mockSummary();
    const res = await request(app).get(`${child}/summary`).set(auth(parentToken));

    expect(res.status).toBe(200);
    expect(res.body).toEqual({
      child: { id: ID.student, fullName: 'Alice', avatarUrl: null },
      attendance: { presentCount: 8, absentCount: 1, lateCount: 0 + 1, excusedCount: 0, presentRate: 0.8 },
      fees: { totalDue: 3000, totalPaid: 1000, totalPending: 2000, overdueInvoices: 1 },
      assignments: { total: 5, submitted: 4, graded: 3, averageScoreRate: 0.85 }
    });
  });

  it('reports a null average (not 0%) when nothing has been graded yet', async () => {
    mockSummary({ graded: 0 });
    const res = await request(app).get(`${child}/summary`).set(auth(parentToken));
    expect(res.body.assignments.averageScoreRate).toBeNull();
  });

  it('reports a null attendance rate when no attendance has been marked', async () => {
    linked();
    pool.query
      .mockResolvedValueOnce({ rows: [{ id: ID.student, full_name: 'Alice', avatar_url: null }] })
      .mockResolvedValueOnce({ rows: [] })
      .mockResolvedValueOnce({ rows: [{ total_due: 0, total_paid: 0, overdue: 0 }] })
      .mockResolvedValueOnce({ rows: [{ total: 0, submitted: 0, graded: 0, average_rate: null }] });
    const res = await request(app).get(`${child}/summary`).set(auth(parentToken));
    expect(res.body.attendance.presentRate).toBeNull();
  });

  it('every query is limited to this one child', async () => {
    mockSummary();
    await request(app).get(`${child}/summary`).set(auth(parentToken));
    pool.query.mock.calls.slice(1).forEach((call) => expect(call[1]).toEqual([ID.student]));
  });
});

describe('GET child lists', () => {
  it('attendance includes the batch title', async () => {
    linked();
    pool.query.mockResolvedValueOnce({
      rows: [{ id: 'r1', batch_id: ID.batch, batch_title: 'Math', student_id: ID.student, student_name: 'Alice', date: '2026-09-08', status: 'ABSENT', notes: null }]
    });
    const res = await request(app).get(`${child}/attendance`).set(auth(parentToken));
    expect(res.body[0]).toEqual({
      id: 'r1', batchId: ID.batch, batchTitle: 'Math', studentId: ID.student, studentName: 'Alice',
      date: '2026-09-08', status: 'ABSENT', notes: ''
    });
  });

  it('assignments include batch title, score and the child\'s own submission file', async () => {
    linked();
    pool.query.mockResolvedValueOnce({
      rows: [{
        id: ID.assignment, batch_id: ID.batch, batch_title: 'Math', title: 'HW1', description: '', due_date: '2026-09-20', max_score: 50,
        attachment_url: null, attachment_name: null, is_submitted: true, score_earned: 45,
        submission_attachment_url: 'https://x/s.png', submission_attachment_name: 's.png'
      }]
    });
    const res = await request(app).get(`${child}/assignments`).set(auth(parentToken));
    expect(res.body[0]).toMatchObject({
      batchTitle: 'Math', isSubmitted: true, scoreEarned: 45, maxScore: 50, submissionAttachmentName: 's.png'
    });
  });

  it('fees map to numeric camelCase fields', async () => {
    linked();
    pool.query.mockResolvedValueOnce({
      rows: [{ invoice_id: ID.fee, student_id: ID.student, student_name: 'Alice', month_year: 'Sept', amount_due: '1500.00', amount_paid: '500.00', status: 'PENDING', due_date: '2026-09-15' }]
    });
    const res = await request(app).get(`${child}/fees`).set(auth(parentToken));
    expect(res.body[0]).toMatchObject({ invoiceId: ID.fee, amountDue: 1500, amountPaid: 500, status: 'PENDING', dueDate: '2026-09-15' });
  });

  it('batches list the child\'s classes', async () => {
    linked();
    pool.query.mockResolvedValueOnce({
      rows: [{ id: ID.batch, title: 'Math', subject: 'Math', teacher_name: 'Ms. Lee', schedule_time: '5pm', room_or_meeting_link: null, active_student_count: 12 }]
    });
    const res = await request(app).get(`${child}/batches`).set(auth(parentToken));
    expect(res.body[0]).toEqual({
      id: ID.batch, title: 'Math', subject: 'Math', teacherName: 'Ms. Lee', scheduleTime: '5pm', activeStudentCount: 12, roomOrMeetingLink: ''
    });
  });
});
