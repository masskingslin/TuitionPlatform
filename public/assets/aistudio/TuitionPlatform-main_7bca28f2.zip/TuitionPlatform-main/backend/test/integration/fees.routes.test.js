const request = require('supertest');

jest.mock('../../src/db', () => ({
  pool: { query: jest.fn() }
}));

const { pool } = require('../../src/db');
const feesRoutes = require('../../src/routes/fees.routes');
const { buildTestApp } = require('../testApp');
const { ID, teacherToken, studentToken, parentToken } = require('../ids');

const app = buildTestApp('/api/fees', feesRoutes);
const auth = (token) => ({ Authorization: `Bearer ${token}` });

const feeRow = (overrides = {}) => ({
  invoice_id: ID.fee, student_id: ID.student, month_year: 'Sept 2026',
  amount_due: '1500.00', amount_paid: '0.00', status: 'PENDING', due_date: '2026-09-15', ...overrides
});

beforeEach(() => {
  pool.query.mockReset();
});

describe('GET /api/fees', () => {
  it('maps a fee record to camelCase fields with numeric amounts', async () => {
    pool.query.mockResolvedValueOnce({ rows: [feeRow({ student_name: 'Alice' })] });
    const res = await request(app).get('/api/fees').set(auth(studentToken));

    expect(res.status).toBe(200);
    expect(res.body[0]).toEqual({
      invoiceId: ID.fee, studentId: ID.student, studentName: 'Alice', monthYear: 'Sept 2026',
      amountDue: 1500, amountPaid: 0, status: 'PENDING', dueDate: '2026-09-15'
    });
  });

  it('sends parents to the per-child endpoints instead of returning someone else\'s data', async () => {
    const res = await request(app).get('/api/fees').set(auth(parentToken));
    expect(res.status).toBe(403);
    expect(pool.query).not.toHaveBeenCalled();
  });
});

describe('GET /api/fees/students', () => {
  it('is teacher-only', async () => {
    expect((await request(app).get('/api/fees/students').set(auth(studentToken))).status).toBe(403);
  });

  it("lists the teacher's students", async () => {
    pool.query.mockResolvedValueOnce({ rows: [{ id: ID.student, full_name: 'Alice' }] });
    const res = await request(app).get('/api/fees/students').set(auth(teacherToken));
    expect(res.body).toEqual([{ id: ID.student, fullName: 'Alice' }]);
  });
});

describe('POST /api/fees', () => {
  const body = { studentId: ID.student, monthYear: 'Sept 2026', amountDue: 100, dueDate: '2026-09-15' };

  it.each([['student', studentToken], ['parent', parentToken]])('rejects a %s', async (_w, token) => {
    expect((await request(app).post('/api/fees').set(auth(token)).send(body)).status).toBe(403);
  });

  it.each([
    ['missing fields', { studentId: ID.student }],
    ['a studentId that is not a UUID', { ...body, studentId: 's1' }],
    ['a non-numeric amount', { ...body, amountDue: '100' }],
    ['a zero amount', { ...body, amountDue: 0 }],
    ['a negative amount', { ...body, amountDue: -5 }],
    ['an absurdly large amount', { ...body, amountDue: 1e12 }],
    ['an impossible date', { ...body, dueDate: '2026-13-45' }],
    ['a non-ISO date', { ...body, dueDate: '15/09/2026' }]
  ])('rejects %s with 400', async (_label, payload) => {
    const res = await request(app).post('/api/fees').set(auth(teacherToken)).send(payload);
    expect(res.status).toBe(400);
    expect(pool.query).not.toHaveBeenCalled();
  });

  it("rejects a student who isn't in any of the teacher's batches", async () => {
    pool.query.mockResolvedValueOnce({ rows: [] });
    expect((await request(app).post('/api/fees').set(auth(teacherToken)).send(body)).status).toBe(403);
  });

  it('creates a fee record for an enrolled student', async () => {
    pool.query
      .mockResolvedValueOnce({ rows: [{ x: 1 }] })
      .mockResolvedValueOnce({ rows: [feeRow({ amount_due: '100' })] })
      .mockResolvedValueOnce({ rows: [{ full_name: 'Alice' }] });

    const res = await request(app).post('/api/fees').set(auth(teacherToken)).send(body);

    expect(res.status).toBe(201);
    expect(res.body.studentName).toBe('Alice');
    expect(res.body.amountDue).toBe(100);
  });
});

describe('POST /api/fees/:feeId/mark-paid', () => {
  it('rejects a malformed fee id', async () => {
    expect((await request(app).post('/api/fees/f1/mark-paid').set(auth(teacherToken))).status).toBe(400);
  });

  it("returns 404 when the fee isn't for one of the teacher's students", async () => {
    pool.query.mockResolvedValueOnce({ rows: [] });
    expect((await request(app).post(`/api/fees/${ID.fee}/mark-paid`).set(auth(teacherToken))).status).toBe(404);
  });

  it('marks a fee paid', async () => {
    pool.query
      .mockResolvedValueOnce({ rows: [{ id: ID.fee }] })
      .mockResolvedValueOnce({ rows: [feeRow({ amount_paid: '1500.00', status: 'PAID' })] })
      .mockResolvedValueOnce({ rows: [{ full_name: 'Alice' }] });
    const res = await request(app).post(`/api/fees/${ID.fee}/mark-paid`).set(auth(teacherToken));
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('PAID');
  });
});

describe('POST /api/fees/:feeId/checkout', () => {
  it('rejects teachers', async () => {
    expect((await request(app).post(`/api/fees/${ID.fee}/checkout`).set(auth(teacherToken))).status).toBe(403);
  });

  it.each([['student', studentToken], ['parent', parentToken]])(
    'lets a %s through to the payment step — 503 here only because Stripe is unconfigured in tests',
    async (_w, token) => {
      const res = await request(app).post(`/api/fees/${ID.fee}/checkout`).set(auth(token));
      expect(res.status).toBe(503);
      expect(pool.query).not.toHaveBeenCalled();
    }
  );

  it('rejects a malformed fee id', async () => {
    expect((await request(app).post('/api/fees/nope/checkout').set(auth(studentToken))).status).toBe(400);
  });
});
