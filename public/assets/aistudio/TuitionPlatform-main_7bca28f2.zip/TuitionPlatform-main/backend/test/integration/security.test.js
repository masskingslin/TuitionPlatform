const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const request = require('supertest');

jest.mock('../../src/db', () => ({
  pool: { query: jest.fn(), connect: jest.fn() }
}));

const { pool } = require('../../src/db');
const { createApp } = require('../../src/app');
const { UPLOAD_DIR } = require('../../src/utils/uploads');
const { ID, parentToken } = require('../ids');

beforeEach(() => {
  pool.query.mockReset();
  pool.query.mockResolvedValue({ rows: [] });
});

describe('security headers', () => {
  it('sets hardening headers and hides the framework', async () => {
    const res = await request(createApp()).get('/health');

    expect(res.status).toBe(200);
    expect(res.headers['x-content-type-options']).toBe('nosniff');
    expect(res.headers['x-powered-by']).toBeUndefined();
    expect(res.headers['cross-origin-resource-policy']).toBe('cross-origin');

    const csp = res.headers['content-security-policy'];
    expect(csp).toContain("frame-ancestors 'none'");
    expect(csp).toContain("object-src 'none'");
    expect(csp).toContain("default-src 'self'");
    // would silently break plain-http self-hosted installs
    expect(csp).not.toContain('upgrade-insecure-requests');
  });
});

describe('request hygiene', () => {
  it('answers malformed JSON with 400, not 500', async () => {
    const res = await request(createApp()).post('/api/auth/login').set('Content-Type', 'application/json').send('{"email": ');
    expect(res.status).toBe(400);
    expect(res.body.error).toMatch(/Malformed JSON/);
  });

  it('rejects an oversized JSON body with 413', async () => {
    const res = await request(createApp()).post('/api/auth/login').send({ email: 'a@b.com', password: 'x'.repeat(200 * 1024) });
    expect(res.status).toBe(413);
  });

  it('returns a JSON 404 for unknown routes', async () => {
    const res = await request(createApp()).get('/api/does-not-exist');
    expect(res.status).toBe(404);
    expect(res.body).toEqual({ error: 'Not found' });
  });

  it('protects API routes without a token', async () => {
    expect((await request(createApp()).get('/api/batches')).status).toBe(401);
    expect((await request(createApp()).get('/api/school')).status).toBe(401);
    expect((await request(createApp()).get('/api/parents/children')).status).toBe(401);
  });

  it('mounts the Stripe webhook ahead of the JSON parser (503 only because Stripe is unconfigured)', async () => {
    const res = await request(createApp()).post('/webhooks/stripe').set('Content-Type', 'application/json').send('{}');
    expect(res.status).toBe(503);
  });
});

describe('rate limiting', () => {
  const login = (app, email, password = 'wrong-password') =>
    request(app).post('/api/auth/login').send({ email, password });

  it('locks out repeated FAILED logins for one account, then answers 429', async () => {
    const app = createApp({ loginLimit: 3 });
    for (let i = 0; i < 3; i += 1) {
      expect((await login(app, 'victim@example.com')).status).toBe(401);
    }
    const blocked = await login(app, 'victim@example.com');
    expect(blocked.status).toBe(429);
    expect(blocked.body.error).toMatch(/Too many failed sign-in attempts/);
    expect(blocked.headers['ratelimit-policy'] ?? blocked.headers['ratelimit']).toBeDefined();
  });

  it("does not let one account's failures block a different account on the same network", async () => {
    const app = createApp({ loginLimit: 2 });
    await login(app, 'victim@example.com');
    await login(app, 'victim@example.com');
    expect((await login(app, 'victim@example.com')).status).toBe(429);
    expect((await login(app, 'classmate@example.com')).status).toBe(401); // a normal wrong password, not blocked
  });

  it('treats email case/whitespace variants as the same account', async () => {
    const app = createApp({ loginLimit: 2 });
    await login(app, 'victim@example.com');
    await login(app, ' VICTIM@example.com ');
    expect((await login(app, 'Victim@Example.com')).status).toBe(429);
  });

  it('limits password-reset emails per account (successful requests count too)', async () => {
    const app = createApp({ forgotLimit: 2 });
    const forgot = () => request(app).post('/api/auth/forgot-password').send({ email: 'someone@example.com' });
    expect((await forgot()).status).toBe(200);
    expect((await forgot()).status).toBe(200);
    expect((await forgot()).status).toBe(429);
  });

  it('applies a coarse per-IP cap to all auth endpoints', async () => {
    const app = createApp({ authIpLimit: 2, loginLimit: 100 });
    await login(app, 'a@example.com');
    await login(app, 'b@example.com');
    expect((await login(app, 'c@example.com')).status).toBe(429);
  });

  it('applies a general cap to the API', async () => {
    const app = createApp({ apiLimit: 3 });
    for (let i = 0; i < 3; i += 1) {
      expect((await request(app).get('/api/batches')).status).toBe(401);
    }
    expect((await request(app).get('/api/batches')).status).toBe(429);
  });

  it('makes parent link-code guessing impractical', async () => {
    const app = createApp({ linkLimit: 2 });
    const guess = () => request(app).post('/api/parents/link').set('Authorization', `Bearer ${parentToken}`).send({ code: 'AAAAAAAA' });
    expect((await guess()).status).toBe(400);
    expect((await guess()).status).toBe(400);
    expect((await guess()).status).toBe(429);
  });

  it('does not rate-limit the health check', async () => {
    const app = createApp({ apiLimit: 1 });
    for (let i = 0; i < 5; i += 1) {
      expect((await request(app).get('/health')).status).toBe(200);
    }
  });
});

describe('API documentation', () => {
  it('serves the OpenAPI document as JSON', async () => {
    const res = await request(createApp()).get('/api/docs.json');
    expect(res.status).toBe(200);
    expect(res.body.openapi).toMatch(/^3\./);
    expect(Object.keys(res.body.paths).length).toBeGreaterThan(30);
  });

  it('serves the interactive docs page', async () => {
    const res = await request(createApp()).get('/api/docs/');
    expect(res.status).toBe(200);
    expect(res.headers['content-type']).toMatch(/html/);
  });

  it('can be switched off with ENABLE_API_DOCS=false', async () => {
    process.env.ENABLE_API_DOCS = 'false';
    try {
      expect((await request(createApp()).get('/api/docs.json')).status).toBe(404);
    } finally {
      delete process.env.ENABLE_API_DOCS;
    }
  });
});

describe('uploaded files are served defensively', () => {
  const dir = path.join(UPLOAD_DIR, 'avatars');
  const name = `security-test-${crypto.randomUUID()}.png`;
  const file = path.join(dir, name);

  beforeAll(() => {
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(file, Buffer.from('iVBORw0KGgo=', 'base64'));
  });
  afterAll(() => {
    try { fs.unlinkSync(file); } catch (e) { /* already gone */ }
  });

  it('adds nosniff and a sandboxing CSP to every upload', async () => {
    const res = await request(createApp()).get(`/uploads/avatars/${name}`);
    expect(res.status).toBe(200);
    expect(res.headers['x-content-type-options']).toBe('nosniff');
    expect(res.headers['content-security-policy']).toBe("default-src 'none'; sandbox");
  });

  it('does not list directories', async () => {
    expect((await request(createApp()).get('/uploads/avatars/')).status).toBe(404);
  });

  it('does not serve dotfiles', async () => {
    expect((await request(createApp()).get('/uploads/.gitkeep')).status).toBe(404);
  });
});

describe('legacy sessions', () => {
  it('asks a user whose token predates multi-school support to sign in again', async () => {
    const jwt = require('jsonwebtoken');
    const legacy = jwt.sign({ sub: ID.teacher, role: 'TEACHER', email: 't@x.com' }, process.env.JWT_SECRET);
    const res = await request(createApp()).get('/api/batches').set('Authorization', `Bearer ${legacy}`);
    expect(res.status).toBe(401);
    expect(res.body.error).toMatch(/sign in again/);
  });
});
