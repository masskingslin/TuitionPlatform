const fs = require('fs');
const path = require('path');
const request = require('supertest');

jest.mock('../../src/db', () => ({
  pool: { query: jest.fn() }
}));

const { pool } = require('../../src/db');
const uploadsRoutes = require('../../src/routes/uploads.routes');
const assignmentsRoutes = require('../../src/routes/assignments.routes');
const { UPLOAD_DIR } = require('../../src/utils/uploads');
const { buildTestApp } = require('../testApp');
const { ID, teacherToken, studentToken } = require('../ids');

const uploadsApp = buildTestApp('/api/uploads', uploadsRoutes);
const assignmentsApp = buildTestApp('/api/batches', assignmentsRoutes);
const auth = (token) => ({ Authorization: `Bearer ${token}` });

const tinyPng = Buffer.from(
  'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=',
  'base64'
);
const attachUrl = `/api/batches/${ID.batch}/assignments/${ID.assignment}/attachment`;
const submitUrl = `/api/batches/${ID.batch}/assignments/${ID.assignment}/submission-attachment`;

const savedFiles = [];
function remember(url) {
  const relative = url.split('/uploads/')[1];
  savedFiles.push(path.join(UPLOAD_DIR, relative));
}

beforeEach(() => {
  pool.query.mockReset();
});

afterAll(() => {
  savedFiles.forEach((file) => { try { fs.unlinkSync(file); } catch (e) { /* already gone */ } });
});

describe('POST /api/uploads/profile-photo', () => {
  it('rejects requests with no token', async () => {
    expect((await request(uploadsApp).post('/api/uploads/profile-photo')).status).toBe(401);
  });

  it('rejects a request with no file', async () => {
    expect((await request(uploadsApp).post('/api/uploads/profile-photo').set(auth(studentToken))).status).toBe(400);
  });

  it.each([
    ['plain text', Buffer.from('hi'), { filename: 'notes.txt', contentType: 'text/plain' }],
    ['HTML', Buffer.from('<script>alert(1)</script>'), { filename: 'x.html', contentType: 'text/html' }],
    ['SVG (can carry scripts)', Buffer.from('<svg/>'), { filename: 'x.svg', contentType: 'image/svg+xml' }]
  ])('rejects %s as a profile photo', async (_label, buffer, opts) => {
    const res = await request(uploadsApp).post('/api/uploads/profile-photo').set(auth(studentToken)).attach('photo', buffer, opts);
    expect(res.status).toBe(400);
  });

  it('accepts a valid image and updates the user record', async () => {
    pool.query.mockResolvedValueOnce({ rows: [] });
    const res = await request(uploadsApp).post('/api/uploads/profile-photo').set(auth(studentToken))
      .attach('photo', tinyPng, { filename: 'me.png', contentType: 'image/png' });

    expect(res.status).toBe(200);
    expect(res.body.url).toContain('/uploads/avatars/');
    remember(res.body.url);
    expect(pool.query).toHaveBeenCalledWith('UPDATE users SET avatar_url = $1 WHERE id = $2', [res.body.url, ID.student]);
  });

  it('SECURITY: derives the stored extension from the MIME type, never from the client filename', async () => {
    pool.query.mockResolvedValueOnce({ rows: [] });
    // A file called "evil.html" that merely *claims* to be a PNG must not be saved as .html,
    // or express.static would later serve it as HTML from our own origin.
    const res = await request(uploadsApp).post('/api/uploads/profile-photo').set(auth(studentToken))
      .attach('photo', tinyPng, { filename: 'evil.html', contentType: 'image/png' });

    expect(res.status).toBe(200);
    remember(res.body.url);
    expect(res.body.url).toMatch(/\.png$/);
    expect(res.body.url).not.toMatch(/html/i);
    expect(res.body.filename).toMatch(/^[0-9a-f-]{36}\.png$/);
  });
});

describe('POST .../assignments/:assignmentId/attachment', () => {
  it('rejects students', async () => {
    const res = await request(assignmentsApp).post(attachUrl).set(auth(studentToken))
      .attach('file', tinyPng, { filename: 'w.png', contentType: 'image/png' });
    expect(res.status).toBe(403);
  });

  it('rejects a teacher who does not own the batch', async () => {
    pool.query.mockResolvedValueOnce({ rows: [] });
    const res = await request(assignmentsApp).post(attachUrl).set(auth(teacherToken))
      .attach('file', tinyPng, { filename: 'w.png', contentType: 'image/png' });
    expect(res.status).toBe(403);
  });

  it('attaches a file to an assignment the teacher owns', async () => {
    pool.query
      .mockResolvedValueOnce({ rows: [{ id: ID.batch }] })
      .mockResolvedValueOnce({ rows: [{ id: ID.assignment }] })
      .mockResolvedValueOnce({ rows: [] });
    const res = await request(assignmentsApp).post(attachUrl).set(auth(teacherToken))
      .attach('file', tinyPng, { filename: 'worksheet.png', contentType: 'image/png' });

    expect(res.status).toBe(200);
    expect(res.body.filename).toBe('worksheet.png'); // the display name keeps the original
    expect(res.body.url).toContain('/uploads/assignments/');
    remember(res.body.url);
  });
});

describe('POST .../assignments/:assignmentId/submission-attachment', () => {
  it('rejects teachers', async () => {
    const res = await request(assignmentsApp).post(submitUrl).set(auth(teacherToken))
      .attach('file', tinyPng, { filename: 'h.png', contentType: 'image/png' });
    expect(res.status).toBe(403);
  });

  it('uploads a submission and marks the assignment submitted', async () => {
    pool.query
      .mockResolvedValueOnce({ rows: [{ x: 1 }] })
      .mockResolvedValueOnce({ rows: [{ id: ID.assignment }] })
      .mockResolvedValueOnce({ rows: [] });
    const res = await request(assignmentsApp).post(submitUrl).set(auth(studentToken))
      .attach('file', tinyPng, { filename: 'homework.png', contentType: 'image/png' });

    expect(res.status).toBe(200);
    expect(res.body.url).toContain('/uploads/submissions/');
    remember(res.body.url);
  });
});
