const request = require('supertest');

jest.mock('../../src/db', () => ({
  pool: { query: jest.fn() }
}));

const { pool } = require('../../src/db');
const batchesRoutes = require('../../src/routes/batches.routes');
const { buildTestApp } = require('../testApp');
const { ID, teacherToken, studentToken, parentToken } = require('../ids');

const app = buildTestApp('/api/batches', batchesRoutes);

const batchRow = (overrides = {}) => ({
  id: ID.batch, title: 'Math 101', subject: 'Math', teacher_name: 'Ms. Lee',
  schedule_time: '5pm', room_or_meeting_link: 'Room 1', active_student_count: '3', ...overrides
});

beforeEach(() => {
  pool.query.mockReset();
});

describe('GET /api/batches', () => {
  it('rejects requests with no token', async () => {
    expect((await request(app).get('/api/batches')).status).toBe(401);
  });

  it("maps a teacher's own batches with correct field names", async () => {
    pool.query.mockResolvedValueOnce({ rows: [batchRow()] });
    const res = await request(app).get('/api/batches').set('Authorization', `Bearer ${teacherToken}`);

    expect(res.status).toBe(200);
    expect(res.body).toEqual([{
      id: ID.batch, title: 'Math 101', subject: 'Math', teacherName: 'Ms. Lee',
      scheduleTime: '5pm', activeStudentCount: 3, roomOrMeetingLink: 'Room 1'
    }]);
    expect(pool.query.mock.calls[0][1]).toEqual([ID.teacher]);
  });

  it("queries a student's enrolled batches", async () => {
    pool.query.mockResolvedValueOnce({ rows: [] });
    const res = await request(app).get('/api/batches').set('Authorization', `Bearer ${studentToken}`);
    expect(res.status).toBe(200);
    expect(pool.query.mock.calls[0][1]).toEqual([ID.student]);
  });

  it('defaults a missing active_student_count to 0', async () => {
    pool.query.mockResolvedValueOnce({ rows: [batchRow({ active_student_count: null })] });
    const res = await request(app).get('/api/batches').set('Authorization', `Bearer ${teacherToken}`);
    expect(res.body[0].activeStudentCount).toBe(0);
  });
});

describe('GET /api/batches/browse', () => {
  it("only lists batches from the caller's own school", async () => {
    pool.query.mockResolvedValueOnce({ rows: [batchRow()] });
    const res = await request(app).get('/api/batches/browse').set('Authorization', `Bearer ${studentToken}`);

    expect(res.status).toBe(200);
    expect(res.body).toHaveLength(1);
    expect(pool.query.mock.calls[0][0]).toMatch(/b\.school_id = \$1/);
    expect(pool.query.mock.calls[0][1]).toEqual([ID.school]);
  });
});

describe('POST /api/batches', () => {
  const body = { title: 'Physics', subject: 'Science', scheduleTime: '6pm' };

  it.each([
    ['student', studentToken],
    ['parent', parentToken]
  ])('rejects a %s from creating a batch', async (_who, token) => {
    const res = await request(app).post('/api/batches').set('Authorization', `Bearer ${token}`).send(body);
    expect(res.status).toBe(403);
  });

  it.each([
    ['missing fields', { title: 'X' }],
    ['over-long title', { ...body, title: 'x'.repeat(200) }],
    ['non-string title', { ...body, title: { a: 1 } }],
    ['over-long room link', { ...body, roomOrMeetingLink: 'x'.repeat(600) }]
  ])('rejects %s with 400', async (_label, payload) => {
    const res = await request(app).post('/api/batches').set('Authorization', `Bearer ${teacherToken}`).send(payload);
    expect(res.status).toBe(400);
  });

  it("creates the batch inside the teacher's school", async () => {
    pool.query.mockResolvedValueOnce({
      rows: [{ id: ID.batch, title: 'Physics', subject: 'Science', schedule_time: '6pm', room_or_meeting_link: '' }]
    });
    const res = await request(app).post('/api/batches').set('Authorization', `Bearer ${teacherToken}`).send(body);

    expect(res.status).toBe(201);
    expect(res.body.title).toBe('Physics');
    expect(res.body.activeStudentCount).toBe(0);
    const params = pool.query.mock.calls[0][1];
    expect(params[2]).toBe(ID.teacher);
    expect(params[5]).toBe(ID.school);
  });
});

describe('POST /api/batches/:batchId/enroll', () => {
  it('rejects teachers and parents', async () => {
    expect((await request(app).post(`/api/batches/${ID.batch}/enroll`).set('Authorization', `Bearer ${teacherToken}`)).status).toBe(403);
    expect((await request(app).post(`/api/batches/${ID.batch}/enroll`).set('Authorization', `Bearer ${parentToken}`)).status).toBe(403);
  });

  it('rejects a malformed batch id before touching the database', async () => {
    const res = await request(app).post('/api/batches/does-not-exist/enroll').set('Authorization', `Bearer ${studentToken}`);
    expect(res.status).toBe(400);
    expect(pool.query).not.toHaveBeenCalled();
  });

  it("returns 404 for a batch that isn't in the student's school", async () => {
    pool.query.mockResolvedValueOnce({ rows: [] });
    const res = await request(app).post(`/api/batches/${ID.batch}/enroll`).set('Authorization', `Bearer ${studentToken}`);

    expect(res.status).toBe(404);
    // the lookup is scoped to the caller's school
    expect(pool.query.mock.calls[0][1]).toEqual([ID.batch, ID.school]);
  });

  it('enrolls a student in a batch from their own school', async () => {
    pool.query.mockResolvedValueOnce({ rows: [{ id: ID.batch }] }).mockResolvedValueOnce({ rows: [] });
    const res = await request(app).post(`/api/batches/${ID.batch}/enroll`).set('Authorization', `Bearer ${studentToken}`);
    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
  });
});

describe('GET /api/batches/:batchId/students', () => {
  it('rejects a teacher who does not own the batch', async () => {
    pool.query.mockResolvedValueOnce({ rows: [] });
    const res = await request(app).get(`/api/batches/${ID.batch}/students`).set('Authorization', `Bearer ${teacherToken}`);
    expect(res.status).toBe(403);
  });

  it('returns the roster for a batch the teacher owns', async () => {
    pool.query
      .mockResolvedValueOnce({ rows: [{ id: ID.batch }] })
      .mockResolvedValueOnce({ rows: [{ id: ID.student, full_name: 'Alice' }] });
    const res = await request(app).get(`/api/batches/${ID.batch}/students`).set('Authorization', `Bearer ${teacherToken}`);
    expect(res.status).toBe(200);
    expect(res.body).toEqual([{ id: ID.student, fullName: 'Alice' }]);
  });
});
