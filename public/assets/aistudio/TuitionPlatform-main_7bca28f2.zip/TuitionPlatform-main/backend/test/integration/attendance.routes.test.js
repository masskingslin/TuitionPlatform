const request = require('supertest');

jest.mock('../../src/db', () => ({
  pool: { query: jest.fn(), connect: jest.fn() }
}));

const { pool } = require('../../src/db');
const attendanceRoutes = require('../../src/routes/attendance.routes');
const { buildTestApp } = require('../testApp');
const { ID, teacherToken, studentToken, parentToken } = require('../ids');

const app = buildTestApp('/api/batches', attendanceRoutes);
const auth = (token) => ({ Authorization: `Bearer ${token}` });
const url = `/api/batches/${ID.batch}/attendance`;

let client;
beforeEach(() => {
  pool.query.mockReset();
  pool.query.mockResolvedValue({ rows: [] }); // default for background notification queries
  client = { query: jest.fn().mockResolvedValue({ rows: [] }), release: jest.fn() };
  pool.connect.mockReset();
  pool.connect.mockResolvedValue(client);
});

const ownsBatch = () => pool.query.mockResolvedValueOnce({ rows: [{ id: ID.batch }] });
const record = (overrides = {}) => ({ studentId: ID.student, status: 'PRESENT', ...overrides });

describe('POST attendance — access', () => {
  it('is teacher-only', async () => {
    expect((await request(app).post(url).set(auth(studentToken)).send({})).status).toBe(403);
    expect((await request(app).post(url).set(auth(parentToken)).send({})).status).toBe(403);
  });

  it('rejects a malformed batch id', async () => {
    expect((await request(app).post('/api/batches/nope/attendance').set(auth(teacherToken)).send({})).status).toBe(400);
  });

  it('refuses a teacher who does not own the batch', async () => {
    pool.query.mockResolvedValueOnce({ rows: [] });
    const res = await request(app).post(url).set(auth(teacherToken)).send({ date: '2026-09-08', records: [record()] });
    expect(res.status).toBe(403);
  });
});

describe('POST attendance — validation', () => {
  it.each([
    ['a missing date', { records: [record()] }],
    ['an impossible date', { date: '2026-02-31', records: [record()] }],
    ['a non-ISO date', { date: '08/09/2026', records: [record()] }],
    ['no records', { date: '2026-09-08', records: [] }],
    ['records that are not an array', { date: '2026-09-08', records: 'all present' }],
    ['more than 500 records', { date: '2026-09-08', records: Array.from({ length: 501 }, () => record()) }],
    ['a studentId that is not a UUID', { date: '2026-09-08', records: [record({ studentId: 's1' })] }],
    ['an unknown status', { date: '2026-09-08', records: [record({ status: 'SLEEPING' })] }],
    ['over-long notes', { date: '2026-09-08', records: [record({ notes: 'x'.repeat(600) })] }],
    ['a null record', { date: '2026-09-08', records: [null] }]
  ])('rejects %s with 400', async (_label, payload) => {
    ownsBatch();
    const res = await request(app).post(url).set(auth(teacherToken)).send(payload);
    expect(res.status).toBe(400);
    expect(pool.connect).not.toHaveBeenCalled();
  });

  it('rejects students who are not enrolled in the batch', async () => {
    ownsBatch();
    pool.query.mockResolvedValueOnce({ rows: [] }); // none of the submitted students are enrolled
    const res = await request(app).post(url).set(auth(teacherToken)).send({ date: '2026-09-08', records: [record()] });
    expect(res.status).toBe(400);
    expect(res.body.error).toMatch(/not enrolled/);
    expect(pool.connect).not.toHaveBeenCalled();
  });
});

describe('POST attendance — saving', () => {
  const payload = {
    date: '2026-09-08',
    records: [record(), record({ studentId: ID.student2, status: 'ABSENT', notes: 'sick' })]
  };

  it('saves all records in one transaction', async () => {
    ownsBatch();
    pool.query.mockResolvedValueOnce({ rows: [{ student_id: ID.student }, { student_id: ID.student2 }] });

    const res = await request(app).post(url).set(auth(teacherToken)).send(payload);

    expect(res.status).toBe(200);
    const statements = client.query.mock.calls.map((c) => c[0].trim().split(/\s+/)[0]);
    expect(statements).toEqual(['BEGIN', 'INSERT', 'INSERT', 'COMMIT']);
    expect(client.release).toHaveBeenCalledTimes(1);
  });

  it('counts a student listed twice only once when checking enrollment', async () => {
    ownsBatch();
    pool.query.mockResolvedValueOnce({ rows: [{ student_id: ID.student }] });
    const res = await request(app).post(url).set(auth(teacherToken))
      .send({ date: '2026-09-08', records: [record(), record({ status: 'LATE' })] });
    expect(res.status).toBe(200);
  });

  it('rolls back and releases the connection if a write fails', async () => {
    ownsBatch();
    pool.query.mockResolvedValueOnce({ rows: [{ student_id: ID.student }, { student_id: ID.student2 }] });
    client.query.mockImplementation(async (sql) => {
      if (/^\s*INSERT/.test(sql)) throw new Error('disk full');
      return { rows: [] };
    });

    const res = await request(app).post(url).set(auth(teacherToken)).send(payload);

    expect(res.status).toBe(500);
    expect(client.query.mock.calls.map((c) => c[0].trim())).toContain('ROLLBACK');
    expect(client.release).toHaveBeenCalledTimes(1);
  });
});

describe('GET attendance', () => {
  it("limits a student to their own records", async () => {
    pool.query.mockResolvedValueOnce({ rows: [{ x: 1 }] }); // enrollment check
    pool.query.mockResolvedValueOnce({
      rows: [{ id: 'r1', batch_id: ID.batch, student_id: ID.student, student_name: 'A', date: '2026-09-08', status: 'PRESENT', notes: null }]
    });
    const res = await request(app).get(url).set(auth(studentToken));

    expect(res.status).toBe(200);
    expect(res.body[0]).toMatchObject({ date: '2026-09-08', status: 'PRESENT', notes: '' });
    const [sql, params] = pool.query.mock.calls[1];
    expect(sql).toMatch(/ar\.student_id = \$2/);
    expect(params).toEqual([ID.batch, ID.student]);
  });
});
