const request = require('supertest');

jest.mock('../../src/db', () => ({
  pool: { query: jest.fn() }
}));

const { pool } = require('../../src/db');
const schoolRoutes = require('../../src/routes/school.routes');
const { buildTestApp } = require('../testApp');
const { ID, teacherToken, studentToken } = require('../ids');

const app = buildTestApp('/api/school', schoolRoutes);
const auth = (token) => ({ Authorization: `Bearer ${token}` });

const schoolRow = (isAdmin) => ({
  id: ID.school, name: 'Oak School', student_code: 'SABC1234', teacher_code: 'TXYZ9876', is_school_admin: isAdmin
});

beforeEach(() => {
  pool.query.mockReset();
});

describe('GET /api/school', () => {
  const counts = { rows: [{ role: 'TEACHER', count: 2 }, { role: 'STUDENT', count: 10 }] };

  it('requires sign-in', async () => {
    expect((await request(app).get('/api/school')).status).toBe(401);
  });

  it('looks the school up using the id carried in the token', async () => {
    pool.query.mockResolvedValueOnce({ rows: [schoolRow(false)] }).mockResolvedValueOnce(counts);
    await request(app).get('/api/school').set(auth(studentToken));
    expect(pool.query.mock.calls[0][1]).toEqual([ID.student, ID.school]);
    expect(pool.query.mock.calls[1][1]).toEqual([ID.school]);
  });

  it('shows the admin the join codes and head-counts', async () => {
    pool.query.mockResolvedValueOnce({ rows: [schoolRow(true)] }).mockResolvedValueOnce(counts);
    const res = await request(app).get('/api/school').set(auth(teacherToken));

    expect(res.status).toBe(200);
    expect(res.body).toEqual({
      id: ID.school, name: 'Oak School', isSchoolAdmin: true,
      teacherCount: 2, studentCount: 10, parentCount: 0,
      studentCode: 'SABC1234', teacherCode: 'TXYZ9876'
    });
  });

  it('hides the join codes from everyone who is not the admin', async () => {
    pool.query.mockResolvedValueOnce({ rows: [schoolRow(false)] }).mockResolvedValueOnce(counts);
    const res = await request(app).get('/api/school').set(auth(studentToken));

    expect(res.status).toBe(200);
    expect(res.body.isSchoolAdmin).toBe(false);
    expect(res.body.studentCode).toBeNull();
    expect(res.body.teacherCode).toBeNull();
    expect(JSON.stringify(res.body)).not.toContain('SABC1234');
    expect(JSON.stringify(res.body)).not.toContain('TXYZ9876');
  });

  it('404s when the account has no matching school', async () => {
    pool.query.mockResolvedValueOnce({ rows: [] });
    expect((await request(app).get('/api/school').set(auth(teacherToken))).status).toBe(404);
  });
});

describe('PUT /api/school', () => {
  it('is admin-only', async () => {
    pool.query.mockResolvedValueOnce({ rows: [schoolRow(false)] });
    expect((await request(app).put('/api/school').set(auth(teacherToken)).send({ name: 'New' })).status).toBe(403);
  });

  it.each([[''], ['   '], ['x'.repeat(101)], [42]])('rejects the name %p', async (name) => {
    pool.query.mockResolvedValueOnce({ rows: [schoolRow(true)] });
    expect((await request(app).put('/api/school').set(auth(teacherToken)).send({ name })).status).toBe(400);
  });

  it('renames the school', async () => {
    pool.query.mockResolvedValueOnce({ rows: [schoolRow(true)] }).mockResolvedValueOnce({ rows: [] });
    const res = await request(app).put('/api/school').set(auth(teacherToken)).send({ name: '  Maple School ' });
    expect(res.status).toBe(200);
    expect(pool.query.mock.calls[1][1]).toEqual(['Maple School', ID.school]);
  });
});

describe('POST /api/school/regenerate-codes', () => {
  it('is admin-only', async () => {
    pool.query.mockResolvedValueOnce({ rows: [schoolRow(false)] });
    expect((await request(app).post('/api/school/regenerate-codes').set(auth(teacherToken)).send({})).status).toBe(403);
  });

  it('rejects an unknown "which"', async () => {
    pool.query.mockResolvedValueOnce({ rows: [schoolRow(true)] });
    expect((await request(app).post('/api/school/regenerate-codes').set(auth(teacherToken)).send({ which: 'everyone' })).status).toBe(400);
  });

  it('rotates both codes by default', async () => {
    pool.query.mockResolvedValueOnce({ rows: [schoolRow(true)] }).mockResolvedValueOnce({ rows: [] });
    const res = await request(app).post('/api/school/regenerate-codes').set(auth(teacherToken)).send({});

    expect(res.status).toBe(200);
    expect(res.body.studentCode).toMatch(/^S[A-Z0-9]{7}$/);
    expect(res.body.teacherCode).toMatch(/^T[A-Z0-9]{7}$/);
    expect(res.body.studentCode).not.toBe('SABC1234');
    expect(res.body.teacherCode).not.toBe('TXYZ9876');
  });

  it('rotates only the student code and leaves the teacher code untouched', async () => {
    pool.query.mockResolvedValueOnce({ rows: [schoolRow(true)] }).mockResolvedValueOnce({ rows: [] });
    const res = await request(app).post('/api/school/regenerate-codes').set(auth(teacherToken)).send({ which: 'student' });

    expect(res.body.teacherCode).toBe('TXYZ9876');
    expect(res.body.studentCode).not.toBe('SABC1234');
    expect(pool.query.mock.calls[1][1]).toEqual([res.body.studentCode, 'TXYZ9876', ID.school]);
  });
});

describe('GET /api/school/members', () => {
  it('is admin-only', async () => {
    pool.query.mockResolvedValueOnce({ rows: [schoolRow(false)] });
    expect((await request(app).get('/api/school/members').set(auth(teacherToken))).status).toBe(403);
  });

  it("lists the school's members (and only queries this school)", async () => {
    pool.query.mockResolvedValueOnce({ rows: [schoolRow(true)] }).mockResolvedValueOnce({
      rows: [{ id: ID.student, full_name: 'Alice', email: 'a@x.com', role: 'STUDENT', is_school_admin: false, avatar_url: null, created_at: new Date('2026-01-02T03:04:05Z') }]
    });
    const res = await request(app).get('/api/school/members').set(auth(teacherToken));

    expect(res.status).toBe(200);
    expect(res.body).toEqual([{
      id: ID.student, fullName: 'Alice', email: 'a@x.com', role: 'STUDENT',
      isSchoolAdmin: false, avatarUrl: null, joinedAt: '2026-01-02T03:04:05.000Z'
    }]);
    expect(pool.query.mock.calls[1][1]).toEqual([ID.school]);
  });
});
