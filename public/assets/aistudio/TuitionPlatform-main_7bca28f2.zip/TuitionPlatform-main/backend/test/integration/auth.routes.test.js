const request = require('supertest');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

jest.mock('../../src/db', () => ({
  pool: { query: jest.fn() }
}));

const { pool } = require('../../src/db');
const authRoutes = require('../../src/routes/auth.routes');
const { buildTestApp } = require('../testApp');
const { ID, studentToken } = require('../ids');

const app = buildTestApp('/api/auth', authRoutes);

const SCHOOL_ROW = { id: ID.school, name: 'Oak School', student_code: 'SABC1234', teacher_code: 'TXYZ9876' };
const valid = { fullName: 'Ada Lovelace', email: 'ada@example.com', password: 'password1' };

beforeEach(() => {
  pool.query.mockReset();
});

describe('POST /api/auth/register — validation', () => {
  it.each([
    ['missing fields', { email: 'a@b.com' }],
    ['invalid role', { ...valid, role: 'PRINCIPAL', schoolCode: 'SABC1234' }],
    ['short password', { ...valid, password: '123', role: 'STUDENT', schoolCode: 'SABC1234' }],
    ['over-long password', { ...valid, password: 'x'.repeat(200), role: 'STUDENT', schoolCode: 'SABC1234' }],
    ['malformed email', { ...valid, email: 'not-an-email', role: 'STUDENT', schoolCode: 'SABC1234' }],
    ['non-string email', { ...valid, email: { $ne: null }, role: 'STUDENT', schoolCode: 'SABC1234' }],
    ['no school code and not creating a school', { ...valid, role: 'STUDENT' }],
    ['a student trying to create a school', { ...valid, role: 'STUDENT', createSchool: true, schoolName: 'Mine' }],
    ['a parent trying to create a school', { ...valid, role: 'PARENT', createSchool: true, schoolName: 'Mine' }],
    ['creating a school without a name', { ...valid, role: 'TEACHER', createSchool: true }]
  ])('rejects %s with 400', async (_label, body) => {
    const res = await request(app).post('/api/auth/register').send(body);
    expect(res.status).toBe(400);
    expect(pool.query).not.toHaveBeenCalled();
  });

  it('rejects a duplicate email with 409', async () => {
    pool.query.mockResolvedValueOnce({ rows: [{ id: 'existing' }] });
    const res = await request(app).post('/api/auth/register').send({ ...valid, role: 'STUDENT', schoolCode: 'SABC1234' });
    expect(res.status).toBe(409);
  });
});

describe('POST /api/auth/register — joining a school by code', () => {
  it('rejects an unknown school code', async () => {
    pool.query.mockResolvedValueOnce({ rows: [] }).mockResolvedValueOnce({ rows: [] });
    const res = await request(app).post('/api/auth/register').send({ ...valid, role: 'STUDENT', schoolCode: 'SNOPE000' });
    expect(res.status).toBe(400);
    expect(res.body.error).toMatch(/not recognised/);
  });

  it('refuses a student code for a teacher, so students cannot become teachers', async () => {
    pool.query.mockResolvedValueOnce({ rows: [] }).mockResolvedValueOnce({ rows: [SCHOOL_ROW] });
    const res = await request(app).post('/api/auth/register').send({ ...valid, role: 'TEACHER', schoolCode: 'SABC1234' });
    expect(res.status).toBe(400);
    expect(res.body.error).toMatch(/student\/parent code/);
  });

  it.each(['STUDENT', 'PARENT'])('refuses the teacher code for a %s', async (role) => {
    pool.query.mockResolvedValueOnce({ rows: [] }).mockResolvedValueOnce({ rows: [SCHOOL_ROW] });
    const res = await request(app).post('/api/auth/register').send({ ...valid, role, schoolCode: 'TXYZ9876' });
    expect(res.status).toBe(400);
    expect(res.body.error).toMatch(/teacher code/);
  });

  it('registers a student into the school and puts the school in the token', async () => {
    pool.query
      .mockResolvedValueOnce({ rows: [] })
      .mockResolvedValueOnce({ rows: [SCHOOL_ROW] })
      .mockResolvedValueOnce({ rows: [{ id: ID.student, full_name: 'Ada Lovelace', email: 'ada@example.com', role: 'STUDENT', avatar_url: null, school_id: ID.school, is_school_admin: false }] });

    const res = await request(app).post('/api/auth/register').send({ ...valid, role: 'STUDENT', schoolCode: 'SABC1234' });

    expect(res.status).toBe(201);
    expect(res.body).toMatchObject({ role: 'STUDENT', schoolId: ID.school, schoolName: 'Oak School', isSchoolAdmin: false, avatarUrl: null });
    expect(jwt.verify(res.body.token, process.env.JWT_SECRET).sid).toBe(ID.school);
    // the user row is inserted into the school that owns the code
    expect(pool.query.mock.calls[2][1]).toContain(ID.school);
  });

  it('registers a parent with the student/parent code', async () => {
    pool.query
      .mockResolvedValueOnce({ rows: [] })
      .mockResolvedValueOnce({ rows: [SCHOOL_ROW] })
      .mockResolvedValueOnce({ rows: [{ id: ID.parent, full_name: 'Ada Lovelace', email: 'ada@example.com', role: 'PARENT', school_id: ID.school, is_school_admin: false }] });

    const res = await request(app).post('/api/auth/register').send({ ...valid, role: 'PARENT', schoolCode: 'SABC1234' });

    expect(res.status).toBe(201);
    expect(res.body.role).toBe('PARENT');
  });

  it('registers a teacher with the teacher code', async () => {
    pool.query
      .mockResolvedValueOnce({ rows: [] })
      .mockResolvedValueOnce({ rows: [SCHOOL_ROW] })
      .mockResolvedValueOnce({ rows: [{ id: ID.teacher, full_name: 'Ada Lovelace', email: 'ada@example.com', role: 'TEACHER', school_id: ID.school, is_school_admin: false }] });

    const res = await request(app).post('/api/auth/register').send({ ...valid, role: 'TEACHER', schoolCode: 'TXYZ9876' });

    expect(res.status).toBe(201);
    expect(res.body.role).toBe('TEACHER');
    expect(res.body.isSchoolAdmin).toBe(false);
  });

  it('normalises the code (trim + uppercase) before looking it up', async () => {
    pool.query.mockResolvedValueOnce({ rows: [] }).mockResolvedValueOnce({ rows: [] });
    await request(app).post('/api/auth/register').send({ ...valid, role: 'STUDENT', schoolCode: '  sabc1234 ' });
    expect(pool.query.mock.calls[1][1]).toEqual(['SABC1234']);
  });
});

describe('POST /api/auth/register — creating a school', () => {
  it('creates the school and makes the teacher its admin, with fresh S/T codes', async () => {
    pool.query
      .mockResolvedValueOnce({ rows: [] })
      .mockResolvedValueOnce({ rows: [{ id: ID.teacher, full_name: 'Ada Lovelace', email: 'ada@example.com', role: 'TEACHER', avatar_url: null, school_id: ID.school, is_school_admin: true, school_name: 'Brand New School' }] });

    const res = await request(app).post('/api/auth/register')
      .send({ ...valid, role: 'TEACHER', createSchool: true, schoolName: ' Brand New School ' });

    expect(res.status).toBe(201);
    expect(res.body).toMatchObject({ role: 'TEACHER', isSchoolAdmin: true, schoolName: 'Brand New School', schoolId: ID.school });

    const params = pool.query.mock.calls[1][1];
    expect(params[0]).toBe('Brand New School');
    expect(params[1]).toMatch(/^S[A-Z0-9]{7}$/);
    expect(params[2]).toMatch(/^T[A-Z0-9]{7}$/);
    // school + admin are created in ONE statement so they can't get out of sync
    expect(pool.query.mock.calls[1][0]).toMatch(/WITH new_school AS/);
  });
});

describe('POST /api/auth/login', () => {
  const userRow = async (overrides = {}) => ({
    id: ID.teacher, full_name: 'A Teacher', email: 'a@b.com', role: 'TEACHER',
    password_hash: await bcrypt.hash('correct-password', 10),
    school_id: ID.school, school_name: 'Oak School', is_school_admin: true, ...overrides
  });

  it('rejects missing or non-string fields', async () => {
    expect((await request(app).post('/api/auth/login').send({ email: 'a@b.com' })).status).toBe(400);
    expect((await request(app).post('/api/auth/login').send({ email: { $gt: '' }, password: 'x' })).status).toBe(400);
  });

  it('returns 401 when no account matches', async () => {
    pool.query.mockResolvedValueOnce({ rows: [] });
    const res = await request(app).post('/api/auth/login').send({ email: 'nobody@x.com', password: 'password1' });
    expect(res.status).toBe(401);
  });

  it('returns 401 for a wrong password, with the same message as an unknown email', async () => {
    pool.query.mockResolvedValueOnce({ rows: [await userRow()] });
    const wrong = await request(app).post('/api/auth/login').send({ email: 'a@b.com', password: 'wrong-password' });
    pool.query.mockResolvedValueOnce({ rows: [] });
    const unknown = await request(app).post('/api/auth/login').send({ email: 'x@y.com', password: 'whatever1' });

    expect(wrong.status).toBe(401);
    expect(wrong.body).toEqual(unknown.body);
  });

  it('returns a token carrying the school, plus school details', async () => {
    pool.query.mockResolvedValueOnce({ rows: [await userRow()] });
    const res = await request(app).post('/api/auth/login').send({ email: 'a@b.com', password: 'correct-password' });

    expect(res.status).toBe(200);
    expect(res.body).toMatchObject({ role: 'TEACHER', schoolId: ID.school, schoolName: 'Oak School', isSchoolAdmin: true });
    expect(jwt.verify(res.body.token, process.env.JWT_SECRET).sid).toBe(ID.school);
  });

  it('refuses an account that is not attached to any school', async () => {
    pool.query.mockResolvedValueOnce({ rows: [await userRow({ school_id: null, school_name: null })] });
    const res = await request(app).post('/api/auth/login').send({ email: 'a@b.com', password: 'correct-password' });
    expect(res.status).toBe(403);
  });

  it('is case-insensitive on email', async () => {
    pool.query.mockResolvedValueOnce({ rows: [await userRow()] });
    const res = await request(app).post('/api/auth/login').send({ email: 'A@B.COM', password: 'correct-password' });
    expect(res.status).toBe(200);
    expect(pool.query).toHaveBeenCalledWith(expect.any(String), ['a@b.com']);
  });
});

describe('POST /api/auth/forgot-password', () => {
  it('returns success even when the email does not exist (no account enumeration)', async () => {
    pool.query.mockResolvedValueOnce({ rows: [] });
    const res = await request(app).post('/api/auth/forgot-password').send({ email: 'nobody@x.com' });
    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
  });

  it('returns success and stores a hashed reset token when the email exists', async () => {
    pool.query.mockResolvedValueOnce({ rows: [{ id: 'u1' }] }).mockResolvedValueOnce({ rows: [] });
    const res = await request(app).post('/api/auth/forgot-password').send({ email: 'a@b.com' });

    expect(res.status).toBe(200);
    expect(pool.query).toHaveBeenCalledTimes(2);
    // the stored value is a sha256 hex digest, never the raw token
    expect(pool.query.mock.calls[1][1][1]).toMatch(/^[0-9a-f]{64}$/);
  });

  it('rejects a missing or non-string email', async () => {
    expect((await request(app).post('/api/auth/forgot-password').send({})).status).toBe(400);
    expect((await request(app).post('/api/auth/forgot-password').send({ email: ['a@b.com'] })).status).toBe(400);
  });
});

describe('GET /api/auth/me', () => {
  it('rejects requests with no token', async () => {
    expect((await request(app).get('/api/auth/me')).status).toBe(401);
  });

  it('returns the profile with school info and avatar', async () => {
    pool.query.mockResolvedValueOnce({
      rows: [{ id: ID.student, full_name: 'A Student', email: 'a@b.com', role: 'STUDENT', avatar_url: 'https://x.test/a.png', school_id: ID.school, school_name: 'Oak School', is_school_admin: false }]
    });
    const res = await request(app).get('/api/auth/me').set('Authorization', `Bearer ${studentToken}`);

    expect(res.status).toBe(200);
    expect(res.body).toEqual({
      userId: ID.student, fullName: 'A Student', email: 'a@b.com', role: 'STUDENT',
      avatarUrl: 'https://x.test/a.png', schoolId: ID.school, schoolName: 'Oak School', isSchoolAdmin: false
    });
  });

  it('defaults avatarUrl to null', async () => {
    pool.query.mockResolvedValueOnce({
      rows: [{ id: ID.student, full_name: 'A', email: 'a@b.com', role: 'STUDENT', avatar_url: null, school_id: ID.school, school_name: 'Oak', is_school_admin: false }]
    });
    const res = await request(app).get('/api/auth/me').set('Authorization', `Bearer ${studentToken}`);
    expect(res.body.avatarUrl).toBeNull();
  });
});
