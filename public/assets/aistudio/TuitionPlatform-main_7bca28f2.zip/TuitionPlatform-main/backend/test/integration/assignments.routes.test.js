const request = require('supertest');

jest.mock('../../src/db', () => ({
  pool: { query: jest.fn() }
}));

const { pool } = require('../../src/db');
const assignmentsRoutes = require('../../src/routes/assignments.routes');
const { buildTestApp } = require('../testApp');
const { ID, teacherToken, studentToken, parentToken } = require('../ids');

const app = buildTestApp('/api/batches', assignmentsRoutes);
const auth = (token) => ({ Authorization: `Bearer ${token}` });
const base = `/api/batches/${ID.batch}/assignments`;

beforeEach(() => {
  pool.query.mockReset();
  pool.query.mockResolvedValue({ rows: [] }); // default for background notification queries
});

const ownsBatch = () => pool.query.mockResolvedValueOnce({ rows: [{ id: ID.batch }] });
const enrolledStudent = () => pool.query.mockResolvedValueOnce({ rows: [{ x: 1 }] });

describe('path parameter validation', () => {
  it('rejects a malformed batch id', async () => {
    expect((await request(app).get('/api/batches/nope/assignments').set(auth(teacherToken))).status).toBe(400);
  });
  it('rejects a malformed assignment id', async () => {
    expect((await request(app).post(`${base}/nope/grade`).set(auth(teacherToken)).send({})).status).toBe(400);
  });
});

describe('GET assignments', () => {
  it("shows a student their own status, score and both attachments", async () => {
    enrolledStudent();
    pool.query.mockResolvedValueOnce({
      rows: [{
        id: ID.assignment, batch_id: ID.batch, title: 'HW1', description: 'd', due_date: '2026-09-20', max_score: 100,
        attachment_url: 'https://x/a.pdf', attachment_name: 'a.pdf',
        is_submitted: true, score_earned: 80, submission_attachment_url: 'https://x/s.png', submission_attachment_name: 's.png'
      }]
    });
    const res = await request(app).get(base).set(auth(studentToken));

    expect(res.status).toBe(200);
    expect(res.body[0]).toMatchObject({
      isSubmitted: true, scoreEarned: 80, attachmentName: 'a.pdf', submissionAttachmentName: 's.png'
    });
  });

  it('refuses a student who is not enrolled in the batch', async () => {
    pool.query.mockResolvedValueOnce({ rows: [] });
    expect((await request(app).get(base).set(auth(studentToken))).status).toBe(403);
  });

  it('refuses a parent (they use /api/parents/children/:id/assignments)', async () => {
    pool.query.mockResolvedValueOnce({ rows: [] });
    expect((await request(app).get(base).set(auth(parentToken))).status).toBe(403);
  });
});

describe('POST create assignment', () => {
  const body = { title: 'HW 2', description: 'do it', dueDate: '2026-09-30', maxScore: 50 };

  it('is teacher-only', async () => {
    expect((await request(app).post(base).set(auth(studentToken)).send(body)).status).toBe(403);
  });

  it.each([
    ['missing title', { ...body, title: '' }],
    ['over-long title', { ...body, title: 'x'.repeat(200) }],
    ['missing due date', { ...body, dueDate: undefined }],
    ['non-string description', { ...body, description: 42 }],
    ['huge description', { ...body, description: 'x'.repeat(6000) }],
    ['fractional maxScore', { ...body, maxScore: 10.5 }],
    ['zero maxScore', { ...body, maxScore: 0 }],
    ['absurd maxScore', { ...body, maxScore: 99999 }]
  ])('rejects %s', async (_label, payload) => {
    ownsBatch();
    expect((await request(app).post(base).set(auth(teacherToken)).send(payload)).status).toBe(400);
  });

  it('refuses a teacher who does not own the batch', async () => {
    pool.query.mockResolvedValueOnce({ rows: [] });
    expect((await request(app).post(base).set(auth(teacherToken)).send(body)).status).toBe(403);
  });

  it('creates the assignment', async () => {
    ownsBatch();
    pool.query.mockResolvedValueOnce({
      rows: [{ id: ID.assignment, batch_id: ID.batch, title: 'HW 2', description: 'do it', due_date: '2026-09-30', max_score: 50 }]
    });
    const res = await request(app).post(base).set(auth(teacherToken)).send(body);
    expect(res.status).toBe(201);
    expect(res.body).toMatchObject({ title: 'HW 2', maxScore: 50, isSubmitted: false, attachmentUrl: null });
  });
});

describe('POST grade', () => {
  const url = `${base}/${ID.assignment}/grade`;
  const assignmentRow = () => pool.query.mockResolvedValueOnce({ rows: [{ id: ID.assignment, title: 'HW1', max_score: 100 }] });

  it('is teacher-only', async () => {
    expect((await request(app).post(url).set(auth(studentToken)).send({ studentId: ID.student, scoreEarned: 5 })).status).toBe(403);
  });

  it.each([
    ['a studentId that is not a UUID', { studentId: 's1', scoreEarned: 5 }],
    ['a missing score', { studentId: ID.student }],
    ['a string score', { studentId: ID.student, scoreEarned: '90' }],
    ['a fractional score', { studentId: ID.student, scoreEarned: 90.5 }],
    ['a negative score', { studentId: ID.student, scoreEarned: -1 }]
  ])('rejects %s', async (_label, payload) => {
    ownsBatch();
    expect((await request(app).post(url).set(auth(teacherToken)).send(payload)).status).toBe(400);
  });

  it('returns 404 for an assignment that is not in this batch', async () => {
    ownsBatch();
    pool.query.mockResolvedValueOnce({ rows: [] });
    expect((await request(app).post(url).set(auth(teacherToken)).send({ studentId: ID.student, scoreEarned: 5 })).status).toBe(404);
  });

  it('rejects a score above the assignment maximum', async () => {
    ownsBatch();
    assignmentRow();
    const res = await request(app).post(url).set(auth(teacherToken)).send({ studentId: ID.student, scoreEarned: 101 });
    expect(res.status).toBe(400);
    expect(res.body.error).toMatch(/100/);
  });

  it('rejects grading a student who is not enrolled in the batch', async () => {
    ownsBatch();
    assignmentRow();
    pool.query.mockResolvedValueOnce({ rows: [] });
    const res = await request(app).post(url).set(auth(teacherToken)).send({ studentId: ID.student, scoreEarned: 50 });
    expect(res.status).toBe(400);
    expect(res.body.error).toMatch(/not enrolled/);
  });

  it('records the grade for an enrolled student (boundary: full marks allowed)', async () => {
    ownsBatch();
    assignmentRow();
    enrolledStudent();
    const res = await request(app).post(url).set(auth(teacherToken)).send({ studentId: ID.student, scoreEarned: 100 });
    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    const upsert = pool.query.mock.calls.find((c) => /INSERT INTO assignment_submissions/.test(c[0]));
    expect(upsert[1]).toEqual([ID.assignment, ID.student, 100]);
  });
});

describe('POST submit', () => {
  const url = `${base}/${ID.assignment}/submit`;

  it('is student-only', async () => {
    expect((await request(app).post(url).set(auth(teacherToken))).status).toBe(403);
  });

  it('marks work submitted', async () => {
    enrolledStudent();
    pool.query.mockResolvedValueOnce({ rows: [{ id: ID.assignment }] });
    expect((await request(app).post(url).set(auth(studentToken))).status).toBe(200);
  });

  it('returns 404 for an unknown assignment', async () => {
    enrolledStudent();
    pool.query.mockResolvedValueOnce({ rows: [] });
    expect((await request(app).post(url).set(auth(studentToken))).status).toBe(404);
  });
});
