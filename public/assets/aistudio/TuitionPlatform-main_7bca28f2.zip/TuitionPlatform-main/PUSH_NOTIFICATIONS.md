# Setting Up Push Notifications

Push notifications use Firebase Cloud Messaging (FCM). The code for it is
already wired into the backend and both apps, but it needs credentials only
you can generate — a Firebase project. Nobody can provision this for you in
advance since it's tied to your own Google account.

Without doing this setup, both apps will still build and run fine — you just
won't receive push notifications (the backend logs what it *would* have
sent instead).

## 1. Create a Firebase project

1. Go to [console.firebase.google.com](https://console.firebase.google.com) and create a new project (or reuse an existing one).
2. You don't need Analytics for this — feel free to skip it.

## 2. Register both Android apps

For **each** app (Teacher and Student), in the Firebase console:

1. Project settings → Add app → Android.
2. Package name must match exactly:
   - Teacher app: `com.tuition.teacher`
   - Student app: `com.tuition.student`
3. Download the generated `google-services.json`.
4. Replace the placeholder file at:
   - `app-teacher/google-services.json`
   - `app-student/google-services.json`

Each app needs its **own** `google-services.json` — don't reuse one file for
both, the package name embedded in the file has to match the module it's in.

## 3. Generate a service account key for the backend

1. In the Firebase console: Project settings → Service accounts → **Generate new private key**. This downloads a JSON file.
2. The backend reads this from the `FIREBASE_SERVICE_ACCOUNT_JSON` environment variable. Since pasting multi-line JSON into a `.env` file is awkward, base64-encode it first:
   ```bash
   base64 -i path/to/your-service-account.json | tr -d '\n'
   ```
3. Paste that output as the value of `FIREBASE_SERVICE_ACCOUNT_JSON` in `backend/.env` (or your host's environment variables). Raw (unencoded) JSON on one line also works if you prefer, as long as it's valid JSON.

## 4. Rebuild and restart

- Android: sync Gradle and rebuild both apps.
- Backend: restart it so it picks up the new environment variable. On boot you should stop seeing "FIREBASE_SERVICE_ACCOUNT_JSON not set" in the logs.

## What triggers a push notification

| Event | Who gets notified |
|---|---|
| Teacher publishes an assignment | All students enrolled in that batch |
| Teacher grades an assignment | That student |
| Teacher marks a student absent or late | That student |
| A Stripe payment completes | That student |

## Troubleshooting

- **Notifications never arrive**: check the backend logs for `Failed to send push notification` or `Failed to initialize Firebase Admin` — the error message usually says exactly what's wrong (bad JSON, wrong project, etc.).
- **Android build fails after adding `google-services.json`**: double-check the `package_name` inside the file matches the module exactly (`com.tuition.teacher` / `com.tuition.student`), and that the file is valid JSON (no trailing commas, no stray `_comment` issues if you hand-edited it).
- **Testing without a physical setup**: leave `FIREBASE_SERVICE_ACCOUNT_JSON` unset — the backend will log what it would have sent to the console instead of failing, which is often enough to confirm the trigger logic works.

## Parents

Parents who have linked to a child (Student & Parent app → parent account) are
notified alongside the child for new assignments, grades, absences/lateness and
fee payments. No extra setup: parents use the same Student & Parent app, so the
same `google-services.json` and server key apply.
