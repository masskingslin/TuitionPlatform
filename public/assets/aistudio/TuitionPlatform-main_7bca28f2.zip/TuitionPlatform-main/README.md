# Tuition Platform

An Android Teacher app, an Android Student & Parent app, and a shared
self-hosted backend for running tuition/coaching classes: batches, attendance,
assignments & grading, fees (with real online payment), push notifications, a
browser-based teacher dashboard, **multiple schools on one server**, and
**parent accounts** with read-only access to their child's progress.

## Structure

- **`backend/`** — Node.js/Express + PostgreSQL REST API. See `backend/README.md`
  for setup, deployment, and the full API reference. This is what both apps
  (and the `/admin` web dashboard) talk to.
- **`app-teacher/`** — Android app (Kotlin + Jetpack Compose) for teachers:
  create batches, mark attendance, publish assignments (with file
  attachments) and grade submissions, manage fees, view insights, set a
  profile photo.
- **`app-student/`** — Android app (Kotlin + Jetpack Compose) for students
  **and parents** (one app; the home screen depends on who signs in).
  Students: browse/join batches, view attendance and assignments, submit work
  (as a plain "mark submitted" or by uploading a file), pay fees, set a profile
  photo, and create a code to give a parent access. Parents: link to one or
  more children, then see attendance, homework/grades and fees (and pay them).
- **`core-network/`** — shared Android library: the data models and Retrofit
  API interface both apps use to talk to the backend.

## Getting started

1. **Stand up the backend.** Follow `backend/README.md` — the fastest path
   is `docker compose up -d --build` inside `backend/`.
2. **Open `app-teacher/` and `app-student/` in Android Studio** (or build
   both from the root with Gradle — they're separate application modules
   in this one project).
3. **Point each app at your backend.** On first launch, each app asks for
   a server address (e.g. `http://10.0.2.2:4000` from an emulator talking
   to a backend on your host machine, or your real deployed URL).
4. **Create your school.** In the Teacher app choose *Create account → Start a
   new school* (or sign in with the admin account the server created on first
   boot). You become the school admin, and the Account tab shows the school's
   two join codes: a **teacher code** and a **student & parent code**.
5. **Invite people.** Share the teacher code with other teachers and the
   student & parent code with students and parents (Account → *Share*). Each
   registers in their app with that code. A parent then links to their child
   with a code the child creates under *Account → Parent access*.

## Optional upgrades

These are built in but need credentials only you can provide:

- **Push notifications** — see `PUSH_NOTIFICATIONS.md`. Needs a Firebase project.
- **Online fee payments** — see the "Online fee payments" section of
  `backend/README.md`. Needs a Stripe account.

Everything works without either of these — the apps just won't send push
notifications or accept online payments until they're configured.

## Admin/teacher web dashboard

Once the backend is running, open `{your-backend-url}/admin` in a browser
and sign in with a teacher account for a browser-based alternative to the
Teacher app — useful for managing things from a desktop. The school admin also
gets a *School* tab for join codes and members. Interactive API docs are at
`{your-backend-url}/api/docs`.

## Tests & CI

- **Backend**: `cd backend && npm install && npm test` — a fully offline
  Jest + Supertest suite (mocked database, no real SMTP/Firebase/Stripe
  needed) covering every route, validation, security middleware and the API
  docs. See "Running tests" in `backend/README.md`.
- **`core-network`**: plain JVM unit tests (`./gradlew :core-network:testDebugUnitTest`
  once you've regenerated the Gradle wrapper — see below) verifying the
  JSON contract between the apps and the backend (including school and
  parent responses, and error-message parsing) doesn't silently drift.
- **CI**: `.github/workflows/build.yml` runs both of the above, plus builds
  debug APKs for both apps, on every push/PR.

**Gradle wrapper note**: this repo's `gradle-wrapper.properties` pins
Gradle 8.9, but the actual wrapper executable (`gradlew`, `gradlew.bat`,
`gradle-wrapper.jar`) isn't committed. Opening the project in Android
Studio will offer to regenerate it automatically. From the command line,
run this once (needs a local Gradle install and network access):
```bash
gradle wrapper --gradle-version 8.9
```
CI doesn't depend on this — it installs Gradle 8.9 directly and invokes
`gradle` rather than `./gradlew`.
